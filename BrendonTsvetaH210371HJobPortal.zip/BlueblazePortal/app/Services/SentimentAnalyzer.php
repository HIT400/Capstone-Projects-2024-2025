<?php
namespace App\Services;

class SentimentAnalyzer
{
    protected $negativeWords = [
        'lazy', 'unmotivated', 'procrastinate', 'hate', 'annoyed', 'depressed', 'rude', 'hostile',
        'worthless', 'fail', 'failures', 'impatient', 'disorganized', 'quit', 'inefficient',
        'angry', 'sad', 'frustrated', 'hopeless', 'irresponsible', 'blame', 'critical', 'self-doubt',
        'worried', 'negative', 'weak', 'poor', 'uncertain', 'insecure', 'confused', 'lost'
    ];

    public function analyze(string $text): array
    {
        $text = strtolower($text);
        $matches = [];

        foreach ($this->negativeWords as $word) {
            if (str_contains($text, $word)) {
                $matches[] = $word;
            }
        }

        return array_unique($matches);
    }
    public function highlightNegativeWords(string $text): string
    {
        foreach ($this->negativeWords as $word) {
            $text = preg_replace(
                "/\b(" . preg_quote($word, '/') . ")\b/i",
                '<span style="background-color: #f8d7da; color: #721c24;">$1</span>',
                $text
            );
        }
    
        return nl2br($text, false); // Removed e() to allow <span> rendering
    }
    
}
