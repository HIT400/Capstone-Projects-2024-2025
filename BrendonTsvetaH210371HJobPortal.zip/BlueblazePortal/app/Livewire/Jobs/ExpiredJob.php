<?php

namespace App\Livewire\Jobs;

use Livewire\Component;

class ExpiredJob extends Component
{
    public function render()
    {
        return view('livewire.jobs.expired-job');
    }
}
