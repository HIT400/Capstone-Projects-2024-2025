<?php

namespace App\Livewire\Jobs;

use Livewire\Component;

class ActiveJob extends Component
{
    public function render()
    {
        return view('livewire.jobs.active-job');
    }
}
