<?php

namespace App\Livewire\Jobs;

use Livewire\Component;

class ApprovedJob extends Component
{
    public function render()
    {
        return view('livewire.jobs.approved-job');
    }
}
