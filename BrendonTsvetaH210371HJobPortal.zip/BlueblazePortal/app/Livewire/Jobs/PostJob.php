<?php

namespace App\Livewire\Jobs;

use Livewire\Component;

class PostJob extends Component
{
    public function render()
    {
        return view('livewire.jobs.post-job');
    }
}
