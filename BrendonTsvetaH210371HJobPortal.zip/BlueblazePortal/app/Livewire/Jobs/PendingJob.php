<?php

namespace App\Livewire\Jobs;

use Livewire\Component;

class PendingJob extends Component
{
    public function render()
    {
        return view('livewire.jobs.pending-job');
    }
}
