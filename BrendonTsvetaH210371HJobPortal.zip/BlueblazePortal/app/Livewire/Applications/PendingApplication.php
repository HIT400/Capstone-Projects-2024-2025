<?php

namespace App\Livewire\Applications;

use Livewire\Component;

class PendingApplication extends Component
{
    public function render()
    {
        return view('livewire.applications.pending-application');
    }
}
