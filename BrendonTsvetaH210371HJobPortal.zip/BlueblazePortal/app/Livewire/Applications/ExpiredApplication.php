<?php

namespace App\Livewire\Applications;

use Livewire\Component;

class ExpiredApplication extends Component
{
    public function render()
    {
        return view('livewire.applications.expired-application');
    }
}
