<?php

namespace App\Livewire\Applications;

use Livewire\Component;

class RejectedApplication extends Component
{
    public function render()
    {
        return view('livewire.applications.rejected-application');
    }
}
