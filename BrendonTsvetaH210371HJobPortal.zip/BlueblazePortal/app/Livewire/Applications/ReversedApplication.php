<?php

namespace App\Livewire\Applications;

use Livewire\Component;

class ReversedApplication extends Component
{
    public function render()
    {
        return view('livewire.applications.reversed-application');
    }
}
