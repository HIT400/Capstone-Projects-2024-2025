/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_4137419780")

  // remove field
  collection.fields.removeById("relation2562510252")

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_4137419780")

  // add field
  collection.fields.addAt(4, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_37542366742",
    "hidden": false,
    "id": "relation2562510252",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "performedBy",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
})
