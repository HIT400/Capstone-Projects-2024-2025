/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_933273423")

  // update collection data
  unmarshal({
    "name": "degreeTitles"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_933273423")

  // update collection data
  unmarshal({
    "name": "degreeTitle"
  }, collection)

  return app.save(collection)
})
