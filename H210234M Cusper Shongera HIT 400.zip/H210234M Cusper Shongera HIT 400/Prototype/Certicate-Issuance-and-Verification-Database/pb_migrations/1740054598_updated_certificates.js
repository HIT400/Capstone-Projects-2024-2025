/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // add field
  collection.fields.addAt(14, new Field({
    "hidden": false,
    "id": "file2768184300",
    "maxSelect": 1,
    "maxSize": 0,
    "mimeTypes": [],
    "name": "qrcode",
    "presentable": false,
    "protected": false,
    "required": false,
    "system": false,
    "thumbs": [],
    "type": "file"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // remove field
  collection.fields.removeById("file2768184300")

  return app.save(collection)
})
