/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2853987811")

  // update collection data
  unmarshal({
    "name": "reasons"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2853987811")

  // update collection data
  unmarshal({
    "name": "flaggingReasons"
  }, collection)

  return app.save(collection)
})
