/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // add field
  collection.fields.addAt(3, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3754236674",
    "hidden": false,
    "id": "relation4150289842",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "institutionId",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(5, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3117880881",
    "hidden": false,
    "id": "relation3278443128",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "fieldOfStudy",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(6, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_852460463",
    "hidden": false,
    "id": "relation1499115060",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "grade",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(7, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3838510748",
    "hidden": false,
    "id": "relation444282380",
    "maxSelect": 999,
    "minSelect": 0,
    "name": "signatures",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(8, new Field({
    "hidden": false,
    "id": "date1639782455",
    "max": "",
    "min": "",
    "name": "dateOfAward",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "date"
  }))

  // add field
  collection.fields.addAt(9, new Field({
    "hidden": false,
    "id": "number3145888567",
    "max": null,
    "min": null,
    "name": "year",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(10, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_2125759099",
    "hidden": false,
    "id": "relation395731011",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "faculty",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(11, new Field({
    "hidden": false,
    "id": "select2063623452",
    "maxSelect": 1,
    "name": "status",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "select",
    "values": [
      "Valid",
      "Held",
      "Revoked"
    ]
  }))

  // add field
  collection.fields.addAt(12, new Field({
    "autogeneratePattern": "",
    "hidden": false,
    "id": "text3518522040",
    "max": 0,
    "min": 0,
    "name": "hash",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(13, new Field({
    "autogeneratePattern": "",
    "hidden": false,
    "id": "text3796675911",
    "max": 0,
    "min": 0,
    "name": "digitalSignature",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // remove field
  collection.fields.removeById("relation4150289842")

  // remove field
  collection.fields.removeById("relation3278443128")

  // remove field
  collection.fields.removeById("relation1499115060")

  // remove field
  collection.fields.removeById("relation444282380")

  // remove field
  collection.fields.removeById("date1639782455")

  // remove field
  collection.fields.removeById("number3145888567")

  // remove field
  collection.fields.removeById("relation395731011")

  // remove field
  collection.fields.removeById("select2063623452")

  // remove field
  collection.fields.removeById("text3518522040")

  // remove field
  collection.fields.removeById("text3796675911")

  return app.save(collection)
})
