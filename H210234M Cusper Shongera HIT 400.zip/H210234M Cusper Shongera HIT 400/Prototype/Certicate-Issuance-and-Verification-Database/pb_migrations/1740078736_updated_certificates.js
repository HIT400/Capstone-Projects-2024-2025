/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // remove field
  collection.fields.removeById("file2768184300")

  // add field
  collection.fields.addAt(14, new Field({
    "autogeneratePattern": "",
    "hidden": false,
    "id": "text223244161",
    "max": 0,
    "min": 0,
    "name": "address",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3669933913")

  // add field
  collection.fields.addAt(14, new Field({
    "hidden": false,
    "id": "file2768184300",
    "maxSelect": 1,
    "maxSize": 0,
    "mimeTypes": [],
    "name": "qrcode",
    "presentable": false,
    "protected": false,
    "required": false,
    "system": false,
    "thumbs": [],
    "type": "file"
  }))

  // remove field
  collection.fields.removeById("text223244161")

  return app.save(collection)
})
