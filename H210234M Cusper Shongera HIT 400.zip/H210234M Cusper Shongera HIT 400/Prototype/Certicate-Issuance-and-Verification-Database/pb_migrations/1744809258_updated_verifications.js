/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1706220087")

  // remove field
  collection.fields.removeById("select325763347")

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1706220087")

  // add field
  collection.fields.addAt(3, new Field({
    "hidden": false,
    "id": "select325763347",
    "maxSelect": 1,
    "name": "result",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "select",
    "values": [
      "valid",
      "invalid"
    ]
  }))

  return app.save(collection)
})
