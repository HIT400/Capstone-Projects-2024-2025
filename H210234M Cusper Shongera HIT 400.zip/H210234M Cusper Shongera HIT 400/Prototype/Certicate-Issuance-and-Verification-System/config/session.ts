import { SessionOptions } from "iron-session";

export interface SessionData {
  userId?: string;
  institutionId?: string;
  walletAddress?: string;
  institutionName?: string;
  email?: string;
  phone?: string;
  abbreviation?: string;
  institutionType?: string;
  physicalAddress?: string;
  logo?: string;
  role?: string;
  isActive: boolean;
  isLoggedIn: boolean;
}

export const defaultSession: SessionData = {
  isLoggedIn: false,
  isActive: true,
};

export const sessionOptions: SessionOptions = {
  password: process.env.NEXT_PUBLIC_APP_SECRET_KEY!,
  cookieName: "c2ccms-session",
  cookieOptions: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24,
  },
};
