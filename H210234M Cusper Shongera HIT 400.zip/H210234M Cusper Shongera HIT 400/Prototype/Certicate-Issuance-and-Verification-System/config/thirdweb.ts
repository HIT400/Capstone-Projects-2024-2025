import { createThirdwebClient, defineChain, getContract } from "thirdweb";

const clientId = process.env.NEXT_PUBLIC_THIRDWEB_CLIENT_ID!;
const secretKey = process.env.THIRDWEB_SECRET_KEY;

export const client = createThirdwebClient(
  secretKey
    ? { secretKey }
    : {
        clientId,
      }
);

export const certificateFactoryContract = getContract({
  client,
  chain: defineChain(11155111),
  address: "0xA4C23b753659De06d1F5deC1dD0d774686379FFb",
});
