import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getIronSession } from "iron-session";
import { sessionOptions, SessionData } from "@/config/session";
import { cookies } from "next/headers";

const protectedRoutes = [
  { path: "/admin", roles: ["admin"] },
  { path: "/institution", roles: ["admin", "user"] },
];

export async function middleware(request: NextRequest) {
  const session = await getIronSession<SessionData>(
    await cookies(),
    sessionOptions
  );

  // Redirect logged-in users away from the /sign-in page
  if (request.nextUrl.pathname.startsWith("/sign-in")) {
    if (session.isLoggedIn && session.isActive) {
      if (session.role === "admin") {
        return NextResponse.redirect(new URL("/admin", request.url));
      } else {
        return NextResponse.redirect(new URL("/institution", request.url));
      }
    }
    return NextResponse.next();
  }

  // Protect routes that require authentication
  if (!session.isLoggedIn) {
    console.error("User is not logged in. Redirecting to sign-in page.");
    return NextResponse.redirect(new URL("/sign-in", request.url));
  }

  if (!session.isActive) {
    return NextResponse.redirect(new URL("/sign-in", request.url));
  }

  const matchedRoute = protectedRoutes.find((route) =>
    request.nextUrl.pathname.startsWith(route.path)
  );

  if (matchedRoute) {
    if (!matchedRoute.roles.includes(session.role!)) {
      if (session.role === "admin") {
        return NextResponse.redirect(new URL("/admin", request.url));
      } else {
        return NextResponse.redirect(new URL("/institution", request.url));
      }
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/institution/:path*", "/sign-in"],
};
