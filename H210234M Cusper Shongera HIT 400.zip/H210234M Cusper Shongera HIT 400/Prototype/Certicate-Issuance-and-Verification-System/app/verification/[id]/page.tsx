"use client";

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import React, { useRef, useState } from "react";
import { readContract } from "thirdweb";
import { certificateFactoryContract } from "@/config/thirdweb";
import { verifyCertificate } from "@/app/lib/actions/certificates";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Flag, Printer } from "lucide-react";
import CertificateTemplate from "@/components/certificate-template";
import { useReactToPrint } from "react-to-print";
import { LoadingSpinner } from "@/components/spinner";
import FormDialog from "@/components/dialog/forms-dialog";
import ReportValidCertificateForm from "@/components/forms/report-valid-certificate-form";
import ReportInvalidCertificateForm from "@/components/forms/report-invalid-certificate-form";
import CertificateDetailsSection from "@/components/certificate-display";
import Link from "next/link";

const Verification = () => {
  const { id: address } = useParams();
  const contentRef = useRef<HTMLDivElement>(null);
  const [showFormDialog, setShowFormDialog] = useState(false);
  const [showInvalidReportFormDialog, setShowInvalidReportFormDialog] =
    useState(false);

  const fetchCertificateFromBlockchain = async () => {
    if (!address) {
      throw new Error("Address is required");
    }
    try {
      const details = await readContract({
        contract: certificateFactoryContract,
        method:
          "function getCertificateDetails(address _certificateAddress) view returns (string, string, string, string)",
        params: [address as string],
      });

      console.log(details);

      return {
        institutionWalletAddress: details[0],
        hash: details[1],
        digitalSignature: details[2],
        status: details[3],
      };
    } catch (error) {
      throw error;
    }
  };

  const {
    data: certificate,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["verify-certificate", address],
    queryFn: async () => {
      const blockchainDetails: {
        institutionWalletAddress: string;
        hash: string;
        digitalSignature: string;
        status: string;
      } = await fetchCertificateFromBlockchain();

      const response = await verifyCertificate(
        address as string,
        blockchainDetails.institutionWalletAddress,
        blockchainDetails.hash,
        blockchainDetails.digitalSignature,
        blockchainDetails.status
      );

      return response;
    },
    enabled: !!address,
    refetchOnWindowFocus: false,
  });

  const reactToPrintFn = useReactToPrint({
    contentRef,
    documentTitle: certificate
      ? `${certificate.studentFullName}-${certificate.id}`
      : "certificate",
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-row justify-center items-center space-x-2">
        <LoadingSpinner className="text-primary" />
        <span>Verifying Certificate...</span>
      </div>
    );
  }

  if (error) {
    return (
      <>
        <div className="min-h-screen flex flex-col justify-center items-center bg-destructive space-y-4 p-4 ">
          <h2 className="text-xl font-semibold text-white">
            Certificate Verification Failed!
          </h2>
          <p className="text-center max-w-lg text-white">
            The certificate could not be verified. Please ensure that the QR
            code is clear and unobstructed and try again.
          </p>
          <p className="text-center max-w-lg text-white mt-4">
            If the issue persists, it may indicate tampering or other
            discrepancies. In such cases, please report the certificate to the
            institution for further investigation.
          </p>
          <Button
            variant="outline"
            onClick={() => setShowInvalidReportFormDialog(true)}
            className="flex justify-center items-center"
          >
            <Flag />
            <span className="ml-1 whitespace-nowrap">Report Case</span>
          </Button>
        </div>
        <FormDialog
          isOpen={showInvalidReportFormDialog}
          onClose={() => setShowInvalidReportFormDialog(false)}
          title="Report Case"
        >
          <ReportInvalidCertificateForm
            onClose={() => setShowInvalidReportFormDialog(false)}
          />
        </FormDialog>
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen w-screen flex flex-col lg:flex-row m-auto overflow-hidden">
        <div className="w-full lg:w-[60%] p-10 overflow-hidden">
          <div className="absolute top-2 left-10 p-1 shadow rounded-lg bg-background/80 flex flex-col gap-1 group">
            <Button
              asChild
              variant="outline"
              size="sm"
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Link href="/institution/certificates">
                <ArrowLeft />
                <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                  Certificates
                </span>
              </Link>
            </Button>
          </div>
          {certificate ? (
            <CertificateDetailsSection data={certificate} />
          ) : (
            <p>No certificate found.</p>
          )}
        </div>

        <div className="w-full lg:w-[40%] flex items-center justify-center p-3 min-h-screen border-l overflow-hidden relative">
          <div className="absolute top-2 left-2 p-1 shadow rounded-lg bg-background/80 flex flex-col gap-1 group">
            <Button
              variant="outline"
              size="sm"
              onClick={() => reactToPrintFn()}
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Printer />
              <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                Print
              </span>
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowFormDialog(true)}
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Flag />
              <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                Flag
              </span>
            </Button>
          </div>
          <div className="w-[90%] h-full overflow-y-auto flex items-center justify-center">
            <CertificateTemplate
              contentRef={contentRef}
              certificate={certificate}
            />
          </div>
        </div>
      </div>
      <FormDialog
        isOpen={showFormDialog}
        onClose={() => setShowFormDialog(false)}
        title="Flag Certificate"
      >
        <ReportValidCertificateForm
          instituition={certificate?.institutionId as string}
          certificate={certificate?.id as string}
          onClose={() => setShowFormDialog(false)}
        />
      </FormDialog>
    </>
  );
};

export default Verification;
