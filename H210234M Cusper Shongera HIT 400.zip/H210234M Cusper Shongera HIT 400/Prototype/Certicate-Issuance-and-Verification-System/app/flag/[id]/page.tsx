"use client";

import { fetchCertificateDetailsById } from "@/app/lib/actions/certificates";
import {
  changeFlagReadStatus,
  changeFlagSavedStatus,
  fetchFlagById,
} from "@/app/lib/actions/flags";
import CertificateTemplate from "@/components/certificate-template";
import FlagDetailsSection from "@/components/flag-details";
import { LoadingSpinner } from "@/components/spinner";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link2 } from "lucide-react";
import Link from "next/link";
import { useParams, useSearchParams } from "next/navigation";
import React, { useRef } from "react";

const FlagDetailsPage = () => {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const certificateId = searchParams.get("certificateId");
  const contentRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const {
    data: flag,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["flag-details", id],
    queryFn: () => fetchFlagById(id as string),
    enabled: !!id,
  });

  console.log("flag", flag);

  const {
    data: certificate,
    isLoading: isLoadingCertificate,
    error: certificateError,
  } = useQuery({
    queryKey: ["certificate", certificateId],
    queryFn: () => fetchCertificateDetailsById(certificateId as string),
    enabled: !!certificateId,
  });

  console.log("certificate", certificate);

  const readChangeMutation = useMutation({
    mutationFn: (status: boolean) => {
      return changeFlagReadStatus(flag?.id as string, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["flag-details"] });
    },
    onError: (error: any) => {
      console.log("error", error);
      toast({
        variant: "destructive",
        title: "Oops! Something went wrong.",
        description: "Failed to update read status",
      });
    },
  });

  const savedChangeMutation = useMutation({
    mutationFn: (status: boolean) => {
      return changeFlagSavedStatus(flag?.id as string, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["flag-details"] });
    },
    onError: (error: any) => {
      console.log("error", error);
      toast({
        variant: "destructive",
        title: "Oops! Something went wrong.",
        description: "Failed to update bookmarked status",
      });
    },
  });

  if (isLoading || isLoadingCertificate) {
    return (
      <div className="min-h-screen flex justify-center items-center space-x-2">
        <LoadingSpinner className="text-primary" />{" "}
        <span>Loading Certificate</span>
      </div>
    );
  }

  if (error || certificateError) {
    return (
      <div className="min-h-screen flex justify-center items-center text-destructive">
        Error fetching certificate
      </div>
    );
  }

  const handleToggleSaved = () => {
    if (flag?.saved === "saved") {
      savedChangeMutation.mutate(false);
    } else {
      savedChangeMutation.mutate(true);
    }
  };

  const handleToggleRead = () => {
    if (flag?.read === "read") {
      readChangeMutation.mutate(false);
    } else {
      readChangeMutation.mutate(true);
    }
  };

  return (
    <div
      className={`min-h-screen w-screen flex overflow-hidden ${
        certificate ? "flex-row" : "flex-col "
      }`}
    >
      <div
        className={`w-full ${
          certificate ? "md:w-[60%]" : "md:w-[80%] self-center"
        } p-10 overflow-hidden`}
      >
        {flag && (
          <FlagDetailsSection
            data={flag}
            onToggleSaved={handleToggleSaved}
            onToggleRead={handleToggleRead}
          />
        )}
      </div>

      {certificate && (
        <div className="w-full md:w-[40%] flex flex-col items-center justify-center py-10 px-4 min-h-screen border-l overflow-hidden relative">
          <div className="text-center space-y-3">
            <Link
              href={`/certificate/${certificateId}`}
              className="w-[160px] truncate text-lg font-semibold hover:underline underline-offset-2 tabular-nums group"
            >
              <Link2 className="mr-1 h-4 w-4  hidden group-hover:inline transition-opacity" />
              Associated Certificate{" "}
            </Link>
          </div>
          <div className="w-[78%] h-full overflow-y-auto flex items-center justify-center">
            <CertificateTemplate
              contentRef={contentRef}
              certificate={certificate}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default FlagDetailsPage;
