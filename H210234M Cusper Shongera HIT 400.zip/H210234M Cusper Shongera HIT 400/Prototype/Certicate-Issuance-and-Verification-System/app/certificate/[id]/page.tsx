"use client";

import {
  fetchCertificateDetailsById,
  sendCertificate,
} from "@/app/lib/actions/certificates";
import CertificateDetailsSection from "@/components/certificate-display";
import CertificateTemplate from "@/components/certificate-template";
import FormDialog from "@/components/dialog/forms-dialog";
import { LoadingSpinner } from "@/components/spinner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Printer, Share2Icon } from "lucide-react";
import { useParams } from "next/navigation";
import React, { useRef } from "react";
import { useReactToPrint } from "react-to-print";
import SubmitButton from "@/components/buttons/submit-button";
import { pdf } from "@react-pdf/renderer";
import { useToast } from "@/hooks/use-toast";
import { CertificatePDF } from "@/components/certificate-pdf";
import { CertificateDetailsSchema } from "@/lib/validation";
import Link from "next/link";

const CertificateDetailsPage = () => {
  const { id } = useParams();
  const contentRef = useRef<HTMLDivElement>(null);
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [recipientEmail, setRecipientEmail] = React.useState("");
  const [isSending, setIsSending] = React.useState(false);
  const { toast } = useToast();

  const {
    data: certificate,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["certificate", id],
    queryFn: () => fetchCertificateDetailsById(id as string),
    enabled: !!id,
  });

  const reactToPrintFn = useReactToPrint({
    contentRef,
    documentTitle: certificate
      ? `${certificate.studentFullName}-${certificate.id}`
      : "certificate",
  });

  const handleShare = async () => {
    setIsSending(true);

    try {
      const pdfBlob = await pdf(
        <CertificatePDF
          certificate={CertificateDetailsSchema.parse(certificate)}
        />
      ).toBlob();

      if (recipientEmail) {
        await sendCertificate(certificate, pdfBlob, recipientEmail);
        // Show success toast
        toast({
          title: "Success",
          description: "Certificate sent successfully.",
          variant: "default",
        });
      }
    } catch (error) {
      console.log("Error sending certificate", error);
      toast({
        title: "Error",
        description: "Failed to send the certificate.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleDialogSubmit = () => {
    setIsSending(true);
    handleShare();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center space-x-2">
        <LoadingSpinner className="text-primary" />{" "}
        <span>Loading Certificate</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex justify-center items-center text-destructive">
        Error fetching certificate
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen w-screen flex m-auto overflow-hidden">
        <div className="w-full md:w-[60%] p-10 overflow-hidden relative">
          <div className="absolute top-2 left-10 p-1 shadow rounded-lg bg-background/80 flex flex-col gap-1 group">
            <Button
              asChild
              variant="outline"
              size="sm"
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Link href="/institution/certificates">
                <ArrowLeft />
                <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                  Back to Certificates
                </span>
              </Link>
            </Button>
          </div>
          {certificate ? (
            <CertificateDetailsSection data={certificate} />
          ) : (
            <p>No certificate found.</p>
          )}
        </div>

        <div className="w-full md:w-[40%] flex items-center justify-center p-3 min-h-screen border-l overflow-hidden relative">
          <div className="absolute top-2 left-2 p-1 shadow rounded-lg bg-background/80 flex flex-col gap-1 group">
            <Button
              variant="outline"
              size="sm"
              onClick={() => reactToPrintFn()}
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Printer />
              <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                Print
              </span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsDialogOpen(true)}
              className="w-fit group-hover:w-auto transition-all duration-200 overflow-hidden flex justify-center items-center group-hover:justify-start"
            >
              <Share2Icon />
              <span className="ml-1 hidden group-hover:block whitespace-nowrap">
                Share
              </span>
            </Button>
          </div>
          <div className="w-[90%] h-full overflow-y-auto flex items-center justify-center">
            <CertificateTemplate
              contentRef={contentRef}
              certificate={certificate}
            />
          </div>
        </div>
      </div>
      <FormDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        title="Flag Certificate"
      >
        <div className="flex flex-col gap-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleDialogSubmit();
            }}
            className="flex flex-col gap-4"
          >
            <label htmlFor="recipientEmail" className="text-sm font-medium">
              Recipient Email:
            </label>
            <Input
              type="email"
              id="recipientEmail"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              className="border rounded-md p-2"
              placeholder="Enter recipient's email"
              required
            />
            <SubmitButton
              isLoading={isSending}
              loadingLabel="Sending..."
              className="w-full"
            >
              Send
            </SubmitButton>
          </form>
        </div>
      </FormDialog>
    </>
  );
};

export default CertificateDetailsPage;
