"use client";

import { fetchAllTemplates } from "@/app/lib/actions/templates";
import { DataTable } from "@/components/data-table";
import { LoadingSpinner } from "@/components/spinner";
import { CertificateTemplatesColumns } from "@/components/table-components/columns/certificate-templates";
import { useQuery } from "@tanstack/react-query";

const CertificateTemplates = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["certificate-templates-table"],
    queryFn: fetchAllTemplates,
  });

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0 ">
      <div className="flex items-center justify-between space-y-1">
        <div>
          <h2 className="text-xl font-bold tracking-tight">
            Certificate Templates
          </h2>
        </div>
      </div>
      {isLoading ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <LoadingSpinner className="text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>Failed to retrieve records: {error.message}</span>
        </div>
      ) : data ? (
        <DataTable
          data={data}
          columns={CertificateTemplatesColumns}
          tableName="certificateTemplates"
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>No records found</span>
        </div>
      )}
    </div>
  );
};

export default CertificateTemplates;
