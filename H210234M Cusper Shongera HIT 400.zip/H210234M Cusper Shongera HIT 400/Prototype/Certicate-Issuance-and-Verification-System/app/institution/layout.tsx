"use client";

import { AppSidebar } from "@/components/app-sidebar";
import NavHeader from "@/components/nav-header";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { InstitutionSidebarItems, CurrentUser } from "@/lib/constants";
import React from "react";
import { getUserDetails } from "../lib/actions/auth";
import { useQuery } from "@tanstack/react-query";

const InstitutionLayout = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  const {
    data: user,
    isLoading,
    error,
  } = useQuery<CurrentUser>({
    queryKey: ["currentUser"],
    queryFn: async () => {
      const userData = await getUserDetails();
      console.log(userData);
      return {
        name: userData.institutionName as string,
        emailAddress: userData.email as string,
        logo: userData.logo as string,
        role: userData.role as string,
      };
    },
  });

  if (error) {
    console.error("Failed to fetch user details", error);
  }

  return (
    <SidebarProvider>
      <AppSidebar
        menuItems={InstitutionSidebarItems}
        currentUser={user ?? { name: "", emailAddress: "", role: "" }}
        loading={isLoading}
      />
      <SidebarInset>
        <NavHeader />
        {children}
      </SidebarInset>
    </SidebarProvider>
  );
};

export default InstitutionLayout;
