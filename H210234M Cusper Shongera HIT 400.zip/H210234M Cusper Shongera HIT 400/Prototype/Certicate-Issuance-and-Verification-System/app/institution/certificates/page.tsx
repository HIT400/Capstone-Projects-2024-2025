"use client";

import { fetchAllCertificates } from "@/app/lib/actions/certificates";
import { DataTable } from "@/components/data-table";
import { LoadingSpinner } from "@/components/spinner";
import { certificatesColumns } from "@/components/table-components/columns/certificates";
import { useQuery } from "@tanstack/react-query";

const Certificates = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["certificates-table"],
    queryFn: fetchAllCertificates,
  });

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0 ">
      <div className="flex items-center justify-between space-y-1">
        <div>
          <h2 className="text-xl font-bold">Certificates</h2>
        </div>
      </div>
      {isLoading ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <LoadingSpinner className="text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>Failed to retrieve records: {error.message}</span>
        </div>
      ) : data ? (
        <DataTable
          data={data}
          columns={certificatesColumns}
          tableName="certificates"
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>No records found</span>
        </div>
      )}
    </div>
  );
};

export default Certificates;
