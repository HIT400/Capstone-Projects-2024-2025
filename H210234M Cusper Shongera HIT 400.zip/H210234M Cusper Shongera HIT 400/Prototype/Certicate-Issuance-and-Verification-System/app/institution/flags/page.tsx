"use client";

import { fetchFlagsByInstitutionId } from "@/app/lib/actions/flags";
import { DataTable } from "@/components/data-table";
import { LoadingSpinner } from "@/components/spinner";
import { FlagsColumns } from "@/components/table-components/columns/flags";
import { useQuery } from "@tanstack/react-query";

const Flags = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["flags-table"],
    queryFn: fetchFlagsByInstitutionId,
  });

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0 ">
      <div className="flex items-center justify-between space-y-1">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Flags</h2>
        </div>
      </div>
      {isLoading ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <LoadingSpinner className="text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>Failed to retrieve records: {error.message}</span>
        </div>
      ) : data ? (
        <DataTable data={data} columns={FlagsColumns} tableName="flags" />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>No records found</span>
        </div>
      )}
    </div>
  );
};

export default Flags;
