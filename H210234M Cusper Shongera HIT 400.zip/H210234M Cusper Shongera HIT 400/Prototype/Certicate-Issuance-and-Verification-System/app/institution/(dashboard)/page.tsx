import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Overview } from "@/components/dashboard-components/overview";

import { Award, Flag, ShieldQuestion } from "lucide-react";
import { getUserDetails } from "@/app/lib/actions/auth";
import {
  fetchCertificates,
  fetchFlags,
  fetchVerifications,
  fetchFlagsPerMonth,
  fetchVerificationsPerMonth,
} from "@/app/lib/actions/institution-stats";

export default async function DashboardPage() {
  const accountDetails = await getUserDetails();
  const totalCertificates = await fetchCertificates(
    accountDetails.institutionId as string
  );
  const totalVerifications = await fetchVerifications(
    accountDetails.institutionId as string
  );
  const totalFlags = await fetchFlags(accountDetails.institutionId as string);
  const verificationsPerMonth = await fetchVerificationsPerMonth(
    accountDetails.institutionId as string
  );
  const flagsPerMonth = await fetchFlagsPerMonth(
    accountDetails.institutionId as string
  );

  return (
    <>
      <div className="hidden flex-col md:flex">
        <div className="flex-1 space-y-4 px-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-xl font-bold tracking-tight">Dashboard</h2>
          </div>
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Certificates
                    </CardTitle>
                    <Award className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalCertificates}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Verifications
                    </CardTitle>
                    <ShieldQuestion className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalVerifications}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Flags</CardTitle>
                    <Flag className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{totalFlags}</div>
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-8">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Verifications Per Month</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <Overview data={verificationsPerMonth} />
                  </CardContent>
                </Card>
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Flags Per Month</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <Overview data={flagsPerMonth} />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
