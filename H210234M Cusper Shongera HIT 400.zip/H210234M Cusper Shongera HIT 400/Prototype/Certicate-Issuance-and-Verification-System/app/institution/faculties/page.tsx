"use client";

import { fetchAllFaculties } from "@/app/lib/actions/faculties";
import { DataTable } from "@/components/data-table";
import { LoadingSpinner } from "@/components/spinner";
import { FacultiesColumns } from "@/components/table-components/columns/faculties";
import { useQuery } from "@tanstack/react-query";

const Faculties = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["faculties-table"],
    queryFn: fetchAllFaculties,
  });

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0 ">
      <div className="flex items-center justify-between space-y-1">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Faculties</h2>
        </div>
      </div>
      {isLoading ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <LoadingSpinner className="text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>Failed to retrieve records: {error.message}</span>
        </div>
      ) : data ? (
        <DataTable
          data={data}
          columns={FacultiesColumns}
          tableName="faculties"
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>No records found</span>
        </div>
      )}
    </div>
  );
};

export default Faculties;
