"use client";

import { fetchAuditTrail } from "@/app/lib/actions/audit-trail";
import { DataTable } from "@/components/data-table";
import { LoadingSpinner } from "@/components/spinner";
import { AuditTrailColumns } from "@/components/table-components/columns/audit-trail";
import { useQuery } from "@tanstack/react-query";

const AuditTrail = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["audit-trail-table"],
    queryFn: fetchAuditTrail,
  });

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0 ">
      <div className="flex items-center justify-between space-y-1">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Audit Trail</h2>
        </div>
      </div>
      {isLoading ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <LoadingSpinner className="text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>Failed to retrieve records: {error.message}</span>
        </div>
      ) : data ? (
        <DataTable
          data={data}
          columns={AuditTrailColumns}
          tableName="audit-trail"
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <span>No records found</span>
        </div>
      )}
    </div>
  );
};
export default AuditTrail;
