import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Overview } from "@/components/dashboard-components/overview";
import {
  fetchCertificates,
  fetchFlags,
  fetchFlagsPerMonth,
  fetchInstitutions,
  fetchVerifcations,
  fetchVerificationsPerMonth,
} from "@/app/lib/actions/admin-stats";
import { Award, Building2Icon, Flag, ShieldQuestion } from "lucide-react";

export default async function DashboardPage() {
  const totalInstitutions = await fetchInstitutions();
  const totalCertificates = await fetchCertificates();
  const totalVerifications = await fetchVerifcations();
  
  const totalFlags = await fetchFlags();
  const verificationsPerMonth = await fetchVerificationsPerMonth();
  const flagsPerMonth = await fetchFlagsPerMonth();

  return (
    <>
      <div className="hidden flex-col md:flex">
        <div className="flex-1 space-y-4 px-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-xl font-bold tracking-tight">Dashboard</h2>
          </div>
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Institutions
                    </CardTitle>
                    <Building2Icon className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalInstitutions}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Certificates
                    </CardTitle>
                    <Award className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalCertificates}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Verifications
                    </CardTitle>
                    <ShieldQuestion className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalVerifications}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Flags</CardTitle>
                    <Flag className="size-5 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{totalFlags}</div>
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-8">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Verifications Per Month</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <Overview data={verificationsPerMonth} />
                  </CardContent>
                </Card>
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Flags Per Month</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <Overview data={flagsPerMonth} />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
