"use server";

import { VerifyLoginPayloadParams, createAuth } from "thirdweb/auth";
import { privateKeyToAccount } from "thirdweb/wallets";
import { client } from "@/config/thirdweb";
import { fetchInstitutionByWalletAddress } from "./institutions";
import { getIronSession } from "iron-session";
import { SessionData, sessionOptions, defaultSession } from "@/config/session";
import { cookies } from "next/headers";
import { checkAccountStatus, fetchUserByWalletAddress } from "./users";
import { redirect } from "next/navigation";

const privateKey = process.env.THIRDWEB_ADMIN_PRIVATE_KEY as string;

if (!privateKey) {
  throw new Error("Missing THIRDWEB_ADMIN_PRIVATE_KEY in .env file.");
}

const thirdwebAuth = createAuth({
  domain: process.env.NEXT_PUBLIC_THIRDWEB_AUTH_DOMAIN as string,
  adminAccount: privateKeyToAccount({ client, privateKey }),
});

export const getUserDetails = async () => {
  const session = await getIronSession<SessionData>(
    await cookies(),
    sessionOptions
  );

  if (!session.isLoggedIn) {
    session.isLoggedIn = defaultSession.isLoggedIn;
  }

  session.isActive = session.userId
    ? await checkAccountStatus(session.userId)
    : false;

  // Return a plain object without any non-serializable properties
  return {
    isLoggedIn: session.isLoggedIn,
    institutionId: session.institutionId,
    isActive: session.isActive,
    userId: session.userId,
    institutionName: session.institutionName,
    email: session.email,
    logo: session.logo,
    phone: session.phone,
    abbreviation: session.abbreviation,
    institutionType: session.institutionType,
    role: session.role,
    physicalAddress: session.physicalAddress,
  };
};

export const getSession = async () => {
  const session = await getIronSession<SessionData>(
    await cookies(),
    sessionOptions
  );

  if (!session.isLoggedIn) {
    session.isLoggedIn = defaultSession.isLoggedIn;
  }

  session.isActive = session.userId
    ? await checkAccountStatus(session.userId)
    : false;

  return session;
};

export const generatePayload = thirdwebAuth.generatePayload;

export async function signIn(payload: VerifyLoginPayloadParams) {
  const verifiedPayload = await thirdwebAuth.verifyPayload(payload);

  if (verifiedPayload.valid) {
    const session = await getSession();

    const walletAddress = payload.payload.address;

    const user = await fetchUserByWalletAddress(walletAddress);

    if (!user) {
      return {
        error:
          "This wallet is not registered with any account. Please contact the admin for registration.",
      };
    }

    console.log(user);

    if (user.status !== "Active") {
      return {
        error:
          "This account is either suspended or banned. Please contact the admin for futher assistance.",
      };
    }

    const institution = await fetchInstitutionByWalletAddress(walletAddress);

    if (institution) {
      session.userId = user.id;
      session.institutionId = institution.id;
      session.institutionName = institution.institutionName;
      session.email = institution.email;
      session.logo = institution.logo;
      session.phone = institution.phone;
      session.abbreviation = institution.abbreviation;
      session.institutionType = institution.institutionType;
      session.role = user.role;
      session.physicalAddress = institution.physicalAddress;
      session.isLoggedIn = true;
      session.isActive = true;
    } else {
      return {
        error:
          "This wallet is not registered with any account. Please contact the admin for registration. ",
      };
    }

    await session.save();

    if (user.role === "admin") {
      return redirect("/admin");
    }
    return redirect("/institution");
  }
}

export const signOut = async () => {
  const session = await getIronSession<SessionData>(
    await cookies(),
    sessionOptions
  );

  if (session && session.isLoggedIn) {
    session.destroy();
  }
};
