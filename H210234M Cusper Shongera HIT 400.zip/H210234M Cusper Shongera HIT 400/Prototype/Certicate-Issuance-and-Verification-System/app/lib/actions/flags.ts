"use server";

import { pb } from "@/config/pocketbase";
import { Flag } from "@/lib/validation";
import { getUserDetails } from "./auth";

// Fetch a paginated list of flags
export async function fetchFlags(page = 1, pageSize = 50) {
  try {
    const resultList = await pb.collection("flags").getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching flags:", error);
    throw new Error("Could not fetch flags");
  }
}

// Fetch all flags
export async function fetchAllFlags() {
  try {
    const records = await pb.collection("flags").getFullList({
      sort: "-created",
      expand: "institution,certificate,reason",
    });
    const formattedRecords: Flag[] = records.map((record) => {
      return {
        id: record.id,
        institution: record.expand?.institution?.institutionName || "Unknown",
        certificate: record.expand?.certificate?.id || "",
        reason: record.expand?.reason?.label || "Unknown",
        description: record.description || "No description",
        image: record.image
          ? pb.files.getURL(record, record.image)
          : "/placeholder.svg",
        validity: record.validity || "Unknown",
        date: new Date(record.date).toISOString() || new Date().toISOString(),
        read: record.read == true ? "read" : "unread",
        saved: record.saved == true ? "saved" : "unsaved",
      };
    });

    return formattedRecords;
  } catch (error) {
    console.error("Error fetching flags:", error);
    throw new Error("Could not fetch flags");
  }
}

// Fetch a specific flag by its ID
export async function fetchFlagById(recordId: string) {
  try {
    const record = await pb.collection("flags").getOne(recordId, {
      expand: "institution,certificate,reason",
    });
    const formattedRecord: Flag = {
      id: record.id,
      institution: record.expand?.institution?.institutionName || "Unknown",
      certificate: record.expand?.certificate?.id || "Unknown",
      reason: record.expand?.reason?.label || "Unknown",
      description: record.description || "No description",
      image: record.image
        ? pb.files.getURL(record, record.image)
        : "/placeholder.svg",
      validity: record.validity || "Unknown",
      date: new Date(record.date).toISOString() || new Date().toISOString(),
      read: record.read == true ? "read" : "unread",
      saved: record.saved == true ? "saved" : "unsaved",
    };
    return formattedRecord;
  } catch (error) {
    console.error("Error fetching flag:", error);
    throw new Error("Could not fetch flag");
  }
}

// Fetch the first flag matching a filter
export async function fetchFlagsByInstitutionId() {
  try {
    const institution = await getUserDetails();

    if (!institution) {
      throw new Error("Institution not found");
    }

    const records = await pb.collection("flags").getFullList({
      filter: `institution="${institution.institutionId}"`,
      sort: "-created",
      expand: "institution,certificate,reason",
    });

    const formattedRecords: Flag[] = records.map((record) => {
      return {
        id: record.id,
        institution: record.expand?.institution?.institutionName || "Unknown",
        certificate: record.expand?.certificate?.id || "",
        reason: record.expand?.reason?.label || "Unknown",
        description: record.description || "No description",
        image: record.image
          ? pb.files.getURL(record, record.image)
          : "/placeholder.svg",
        validity: record.validity || "Unknown",
        date: new Date(record.date).toISOString() || new Date().toISOString(),
        read: record.read == true ? "read" : "unread",
        saved: record.saved == true ? "saved" : "unsaved",
      };
    });

    return formattedRecords;
  } catch (error) {
    console.error("Error fetching flag by field:", error);
    throw new Error("Could not fetch flag");
  }
}

export async function fetchFlagByField(field: string, value: string) {
  try {
    const record = await pb
      .collection("flags")
      .getFirstListItem(`${field}="${value}"`, {
        expand: "institution,certificate,reason",
      });
    const formattedRecord: Flag = {
      id: record.id,
      institution: record.expand?.institution?.institutionName || "Unknown",
      certificate: record.expand?.certificate?.id || "Unknown",
      reason: record.expand?.reason?.label || "Unknown",
      description: record.description || "No description",
      image: record.image
        ? pb.files.getURL(record, record.image)
        : "/placeholder.svg",
      validity: record.validity || "Unknown",
      date: new Date(record.date).toISOString() || new Date().toISOString(),
      read: record.read == true ? "read" : "unread",
      saved: record.saved == true ? "saved" : "unsaved",
    };

    return formattedRecord;
  } catch (error) {
    console.error("Error fetching flag by field:", error);
    throw new Error("Could not fetch flag");
  }
}

// Create a new flag
export async function createFlag(data: Flag) {
  try {
    console.log("Creating flag with data:", data);
    const record = await pb.collection("flags").create(data);
    return record;
  } catch (error) {
    console.error("Error creating flag:", error);
    throw new Error("Could not create flag");
  }
}

// Update an existing flag
export async function updateFlag(recordId: string, data: Flag) {
  try {
    const record = await pb.collection("flags").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating flag:", error);
    throw new Error("Could not update flag");
  }
}

// Delete a flag
export async function deleteFlag(recordId: string) {
  try {
    await pb.collection("flags").delete(recordId);
    return { message: "Flag deleted successfully" };
  } catch (error) {
    console.error("Error deleting flag:", error);
    throw new Error("Could not delete flag");
  }
}

export async function changeFlagSavedStatus(recordId: string, saved: boolean) {
  try {
    await pb.collection("flags").update(recordId, { saved });
    return { message: "Flag status updated successfully!" };
  } catch {
    return {
      error: "An error occurred while updating the flag status.",
    };
  }
}

export async function changeFlagReadStatus(recordId: string, read: boolean) {
  try {
    await pb.collection("flags").update(recordId, { read });
    return { message: "Flag status updated successfully!" };
  } catch {
    return {
      error: "An error occurred while updating the flag status.",
    };
  }
}
