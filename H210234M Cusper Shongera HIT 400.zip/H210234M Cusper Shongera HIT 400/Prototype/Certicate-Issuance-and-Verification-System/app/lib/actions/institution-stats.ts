import { pb } from "@/config/pocketbase";

export async function fetchCertificates(institutionId: string) {
  try {
    const resultList = await pb.collection("certificates").getList(1, 1, {
      filter: `institutionId = "${institutionId}"`,
    });
    return resultList.totalItems;
  } catch (error) {
    console.error("Error fetching certificates", error);
    throw new Error("Could not fetch certificates");
  }
}

export async function fetchVerifications(institutionId: string) {
  try {
    const resultList = await pb.collection("verifications").getList(1, 1, {
      filter: `institution = "${institutionId}"`,
    });
    return resultList.totalItems;
  } catch (error) {
    console.error("Error fetching verifications", error);
    throw new Error("Could not fetch verifications");
  }
}

export async function fetchFlags(institutionId: string) {
  try {
    const resultList = await pb.collection("flags").getList(1, 1, {
      filter: `institution = "${institutionId}"`,
    });
    return resultList.totalItems;
  } catch (error) {
    console.error("Error fetching flags", error);
    throw new Error("Could not fetch flags");
  }
}

export async function fetchVerificationsPerMonth(institutionId: string) {
  try {
    const currentDate = new Date();
    const verificationsPerMonth = [];

    for (let i = 0; i < 12; i++) {
      const startOfMonth = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i,
        1
      );
      const endOfMonth = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i + 1,
        0
      );

      const resultList = await pb.collection("verifications").getList(1, 1, {
        filter: `institution = "${institutionId}" && created >= "${startOfMonth.toISOString()}" && created <= "${endOfMonth.toISOString()}"`,
      });

      verificationsPerMonth.unshift({
        month: startOfMonth.toLocaleString("default", { month: "short" }),
        value: resultList.totalItems,
      });
    }

    return verificationsPerMonth;
  } catch (error) {
    console.error("Error fetching verifications per month:", error);
    throw new Error("Could not fetch verifications per month");
  }
}

export async function fetchFlagsPerMonth(institutionId: string) {
  try {
    const currentDate = new Date();
    const flagsPerMonth = [];

    for (let i = 0; i < 12; i++) {
      const startOfMonth = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i,
        1
      );
      const endOfMonth = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i + 1,
        0
      );

      const resultList = await pb.collection("flags").getList(1, 1, {
        filter: `institution = "${institutionId}" && created >= "${startOfMonth.toISOString()}" && created <= "${endOfMonth.toISOString()}"`,
      });

      flagsPerMonth.unshift({
        month: startOfMonth.toLocaleString("default", { month: "short" }),
        value: resultList.totalItems,
      });
    }

    return flagsPerMonth;
  } catch (error) {
    console.error("Error fetching flags per month:", error);
    throw new Error("Could not fetch flags per month");
  }
}
