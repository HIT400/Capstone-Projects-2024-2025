"use server";

import { pb } from "@/config/pocketbase";
import { User, UserWithName } from "@/lib/validation";
// Fetch a paginated list of users
export async function fetchUsers(page = 1, pageSize = 50) {
  try {
    const resultList = await pb.collection("users").getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching users:", error);
    throw new Error("Could not fetch users");
  }
}

// Fetch all users
export async function fetchAllUsers() {
  try {
    const records = await pb.collection("users").getFullList({
      sort: "institutionId", // Assuming sorting by institutionId
      expand: "institutionId", // Expand institution relation
    });

    // Map to ensure each user has institutionName
    const usersWithInstitutions: UserWithName[] = records.map((user) => ({
      id: user.id,
      walletAddress: user.walletAddress, // Ensure this field exists in your PocketBase schema
      role: user.role,
      status: user.status, // Make sure `status` exists in the PocketBase schema
      institutionId: user.institutionId,
      institutionName: user.expand?.institutionId?.institutionName,
    }));

    return usersWithInstitutions;
  } catch (error) {
    console.error("Error fetching all users:", error);
    throw new Error("Could not fetch users");
  }
}

// Fetch a specific user by ID
export async function fetchUserById(recordId: string) {
  try {
    return await pb.collection("users").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching user by ID:", error);
    throw new Error("Could not fetch user");
  }
}

export async function checkAccountStatus(recordId: string) {
  try {
    const user = await pb.collection("users").getOne(recordId);
    return user ? user.status === "Active" : false;
  } catch {
    return false;
  }
}

export async function changeAccountStatus(recordId: string, status: string) {
  try {
    await pb.collection("users").update(recordId, { status });
    return { message: "Account status changed successfully" };
  } catch (error) {
    console.error("Error changing account status:", error);
    throw new Error("Could not change account status");
  }
}

export async function changeUserRole(recordId: string, role: string) {
  try {
    await pb.collection("users").update(recordId, { role });
    return { message: "User role changed successfully" };
  } catch (error) {
    console.error("Error changing user role:", error);
    throw new Error("Could not change user role");
  }
}

export async function fetchUserByWalletAddress(walletAddress: string) {
  try {
    return await pb
      .collection("users")
      .getFirstListItem(`walletAddress="${walletAddress}"`);
  } catch (error) {
    console.error("Error fetching user:", error);
    throw new Error("Could not fetch user");
  }
}

// Create a new user
export async function createUser(data: User) {
  try {
    const record = await pb.collection("users").create(data);
    return record;
  } catch (error) {
    console.error("Error creating user:", error);
    throw new Error("Could not create user");
  }
}

// Update an existing user
export async function updateUser(recordId: string, data: User) {
  try {
    const record = await pb.collection("users").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating user:", error);
    throw new Error("Could not update user");
  }
}

// Delete a user
export async function deleteUser(recordId: string) {
  try {
    await pb.collection("users").delete(recordId);
    return { message: "User deleted successfully" };
  } catch (error) {
    console.error("Error deleting user:", error);
    throw new Error("Could not delete user");
  }
}
