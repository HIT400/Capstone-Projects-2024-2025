"use server";

import { pb } from "@/config/pocketbase";
import { Signature } from "@/lib/validation";
import { getSession } from "./auth";

// Fetch a paginated list of signatures
export async function fetchSignatures(page = 1, pageSize = 50) {
  try {
    const resultList = await pb
      .collection("signatures")
      .getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching signatures:", error);
    throw new Error("Could not fetch signatures");
  }
}

// Fetch all signatures
export async function fetchAllSignatures() {
  try {
    const records: Signature[] = await pb.collection("signatures").getFullList({
      sort: "-fullName",
    });

    const signatures = records.map((record) => {
      const signatureImageUrl = pb.files.getURL(
        record,
        record.signatureImage as string
      );
      return {
        ...record,
        signatureImage: signatureImageUrl,
      };
    });

    return signatures;
  } catch (error) {
    console.error("Error fetching all signatures:", error);
    throw new Error("Could not fetch signatures");
  }
}

export async function fetchCurrentUserSignatures() {
  try {
    const session = await getSession();
    if (!session?.institutionId) {
      throw new Error("No institution ID found in session");
    }

    const resultList: Signature[] = await pb
      .collection("signatures")
      .getFullList({
        filter: `institutionId = "${session.institutionId}"`,
      });

    return resultList;
  } catch (error) {
    console.error("Error fetching signatures list:", error);
    throw new Error("Could not fetch signatures list");
  }
}

// Fetch a specific signature by its ID
export async function fetchSignatureById(recordId: string) {
  try {
    return await pb.collection("signatures").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching signature by ID:", error);
    throw new Error("Could not fetch signature");
  }
}

// Create a new signature
export async function createSignature(data: Signature) {
  try {
    const record = await pb.collection("signatures").create(data);
    return record;
  } catch (error) {
    console.error("Error creating signature:", error);
    throw new Error("Could not create signature");
  }
}

// Update an existing signature
export async function updateSignature(recordId: string, data: Signature) {
  try {
    const record = await pb.collection("signatures").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating signature:", error);
    throw new Error("Could not update signature");
  }
}

// Delete a signature
export async function deleteSignature(recordId: string) {
  try {
    await pb.collection("signatures").delete(recordId);
    return { message: "Signature deleted successfully" };
  } catch (error) {
    console.error("Error deleting signature:", error);
    throw new Error("Could not delete signature");
  }
}
