"use server";

import { pb } from "@/config/pocketbase";
import { Certificate, CertificateDetails } from "@/lib/validation";
import { verifySignature } from "thirdweb/auth";
import { hashMessage } from "thirdweb/utils";
import nodemailer from "nodemailer";

async function fetchAllCertificates() {
  try {
    const records = await pb.collection("certificates").getFullList({
      sort: "studentFullName",
      expand: "institutionId,degreeTitle,fieldOfStudy,signatures,faculty",
    });

    const formattedRecords: Certificate[] = records.map((record) => {
      return {
        id: record.id,
        studentFullName: record.studentFullName as string,
        institutionId:
          record.expand?.institutionId?.institutionName ||
          "Unknown Institution ID",
        degreeTitle: record.expand?.degreeTitle?.name || "Unknown Degree",
        fieldOfStudy: record.expand?.fieldOfStudy?.name || "Unknown Field",
        grade: record.grade || "Unknown Grade",
        status: record.status || "Unknown Status",
        signatures: (record.expand?.signatures?.map(
          (sig: any) => sig.fullName
        ) || []) as [string, ...string[]],
        dateOfAward: record.dateOfAward || new Date().toISOString(),
        faculty: record.expand?.faculty?.name || "Unknown Faculty",
        studentId: record.studentId || "Unknown Student ID",
        year: record.year,
        address: record.address,
      };
    });

    return formattedRecords;
  } catch (error) {
    console.error("Error fetching all certificates:", error);
    throw new Error("Could not fetch certificates");
  }
}

export async function fetchCertificateDetailsById(recordId: string) {
  try {
    const record = await pb.collection("certificates").getOne(recordId, {
      expand: "institutionId,degreeTitle,fieldOfStudy,signatures,faculty",
    });

    // Format the record properly
    const formattedRecord: CertificateDetails = {
      id: record.id,
      studentFullName: record.studentFullName as string,
      institutionId: record.institutionId,
      institutionName:
        record.expand?.institutionId?.institutionName || "Unknown Institution",
      institutionLogo: record.expand?.institutionId?.logo
        ? `${process.env.NEXT_PUBLIC_POCKETBASE_URL}/api/files/${record.expand.institutionId.collectionId}/${record.expand.institutionId.id}/${record.expand.institutionId.logo}`
        : "Unknown Institution",
      degreeTitle: record.expand?.degreeTitle?.name || "Unknown Degree",
      fieldOfStudy: record.expand?.fieldOfStudy?.name || "Unknown Field",
      grade: record.grade || "Unknown Grade",
      status: record.status || "Unknown Status",
      signatures: record.expand?.signatures
        ? record.expand.signatures.map((sig: any) => ({
            id: sig.id,
            position: sig.position,
            fullName: sig.fullName,
            institutionId: sig.institutionId,
            signatureImage: sig.signatureImage
              ? pb.files.getURL(sig, sig.signatureImage)
              : "Unknown Signature",
          }))
        : [],
      dateOfAward: record.dateOfAward || new Date().toISOString(),
      faculty: record.expand?.faculty?.name || "Unknown Faculty",
      studentId: record.studentId || "Unknown Student ID",
      year: record.year,
      address: record.address,
      qrcode: record.qrcode,
    };

    return formattedRecord;
  } catch (error) {
    console.error("Error fetching certificate by ID:", error);
    throw new Error("Could not fetch certificate");
  }
}

export async function verifyCertificate(
  address: string,
  institutionWalletAddress: string,
  hash: string,
  digitalSignature: string,
  status: string
) {
  console.log(institutionWalletAddress, hash, digitalSignature, status);

  try {
    // Fetch the certificate record from PocketBase
    const record = await pb
      .collection("certificates")
      .getFirstListItem(`address="${address}"`, {
        expand: "institutionId,degreeTitle,fieldOfStudy,signatures,faculty",
      });

    // Extract the relevant fields for hashing (same as when creating the hash)
    const valuesWithoutStatus = {
      institutionId: record.institutionId,
      studentId: record.studentId,
      studentFullName: record.studentFullName,
      faculty: record.expand?.faculty?.id, // Use the faculty ID
      degreeTitle: record.expand?.degreeTitle?.id, // Use the degree title ID
      fieldOfStudy: record.expand?.fieldOfStudy?.id, // Use the field of study ID
      grade: record.grade,
      dateOfAward: new Date(record.dateOfAward).toISOString(), // Ensure correct format
      signatures: record.signatures,
    };

    // Stringify the object and hash it
    const message = JSON.stringify(valuesWithoutStatus);
    const generatedHash = hashMessage(message, "hex");

    // Verify the hash
    if (generatedHash !== hash) {
      throw new Error("Certificate data has been tampered with");
    }
    if (
      institutionWalletAddress === record.expand?.institutionId?.walletAddress
    ) {
      // Verify the digital signature
      const isSignatureValid = verifySignature({
        message: generatedHash, // Use the generated hash as the message
        signature: digitalSignature, // The provided digital signature
        address: institutionWalletAddress, // The institution's wallet address
      });

      if (!isSignatureValid) {
        throw new Error("Digital signature verification failed");
      }
    } else {
      throw new Error("Digital signature verification failed");
    }

    // Format the record for the final output
    const formattedRecord: CertificateDetails = {
      id: record.id,
      studentFullName: record.studentFullName as string,
      institutionId: record.institutionId,
      institutionName:
        record.expand?.institutionId?.institutionName || "Unknown Institution",
      institutionLogo: record.expand?.institutionId?.logo
        ? `${process.env.NEXT_PUBLIC_POCKETBASE_URL}/api/files/${record.expand.institutionId.collectionId}/${record.expand.institutionId.id}/${record.expand.institutionId.logo}`
        : "Unknown Institution",
      degreeTitle: record.expand?.degreeTitle?.name || "Unknown Degree",
      fieldOfStudy: record.expand?.fieldOfStudy?.name || "Unknown Field",
      grade: record.grade || "Unknown Grade",
      status: record.status || "Unknown Status",
      signatures: record.expand?.signatures
        ? record.expand.signatures.map((sig: any) => ({
            id: sig.id,
            position: sig.position,
            fullName: sig.fullName,
            institutionId: sig.institutionId,
            signatureImage: sig.signatureImage
              ? pb.files.getURL(sig, sig.signatureImage)
              : "Unknown Signature",
          }))
        : [],
      dateOfAward: record.dateOfAward || new Date().toISOString(),
      faculty: record.expand?.faculty?.name || "Unknown Faculty",
      studentId: record.studentId || "Unknown Student ID",
      year: record.year,
      address: record.address,
      qrcode: record.qrcode,
    };

    await pb.collection("verifications").create({
      certificate: formattedRecord.id,
      institution: formattedRecord.institutionId,
    });

    return formattedRecord;
  } catch (error) {
    console.error("Error verifying certificate:", error);
    throw new Error("Certificate verification failed");
  }
}

export async function fetchCertificateById(recordId: string) {
  try {
    const record: Certificate = await pb
      .collection("certificates")
      .getOne(recordId);
    return record;
  } catch (error) {
    console.error("Error fetching certificate by ID:", error);
    throw new Error("Could not fetch certificate");
  }
}

async function createCertificate(data: Certificate) {
  try {
    console.log(data);
    const record = await pb.collection("certificates").create(data);
    return record;
  } catch (error) {
    console.error("Error creating certificate:", error);
    throw new Error("Could not create certificate");
  }
}

async function updateCertificate(recordId: string, data: Certificate) {
  try {
    const record = await pb.collection("certificates").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating certificate:", error);
    throw new Error("Could not update certificate");
  }
}

async function deleteCertificate(recordId: string) {
  try {
    await pb.collection("certificates").delete(recordId);
    return { message: "Certificate deleted successfully" };
  } catch {
    return { error: "An error occurred while deleting certificate." };
  }
}

async function changeCertificateStatus(recordId: string, status: string) {
  try {
    await pb.collection("certificates").update(recordId, { status });
    return { message: "Certificate status updated successfully!" };
  } catch {
    return {
      error: "An error occurred while updating the certificate status.",
    };
  }
}

export {
  deleteCertificate,
  updateCertificate,
  createCertificate,
  fetchAllCertificates,
  changeCertificateStatus,
};

export const sendCertificate = async (
  certificate: any,
  pdfBlob: Blob,
  recipientEmail: string
) => {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.NEXT_PUBLIC_APP_EMAIL,
        pass: process.env.NEXT_PUBLIC_APP_EMAIL_PASSWORD,
      },
    });

    const mailOptions = {
      from: process.env.NEXT_PUBLIC_APP_EMAIL, // sender address
      to: recipientEmail,
      subject: "Certificate Issuance Notification", // Subject line
      text: `Dear ${certificate?.studentFullName},\n\nPlease find attached the certificate for your reference.\n\nBest regards,\n${certificate?.institutionName}`, // Plain text body
      html: `<p>Dear ${certificate?.studentFullName},</p><p>Please find attached the certificate for your reference.</p><p>Best regards,<br/>${certificate?.institutionName}</p>`, // HTML body
      attachments: [
        {
          filename: `${certificate?.studentFullName}-${certificate?.id}.pdf`,
          content: Buffer.from(await pdfBlob.arrayBuffer()),
          contentType: "application/pdf",
        },
      ],
    };
    await transporter.sendMail(mailOptions);
    return;
  } catch (error) {
    console.error("Error sending email:", error);
  }
};
