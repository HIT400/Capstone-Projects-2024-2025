"use server";

import { pb } from "@/config/pocketbase";
import { DegreeTitle } from "@/lib/validation";
import { getSession } from "./auth";

// Fetch a paginated list of degree titles
export async function fetchDegreeTitles(page = 1, pageSize = 50) {
  try {
    const resultList = await pb
      .collection("degreeTitles")
      .getList(page, pageSize, {
        filter: "someField1 != someField2",
      });
    return resultList;
  } catch (error) {
    console.error("Error fetching degree titles list:", error);
    throw new Error("Could not fetch degree titles list");
  }
}

export async function fetchCurrentUserDegreeTitles() {
  try {
    const session = await getSession();
    if (!session?.institutionId) {
      throw new Error("No institution ID found in session");
    }

    const resultList: DegreeTitle[] = await pb.collection("degreeTitles").getFullList({
      filter: `institutionId = "${session.institutionId}"`,
    });

    return resultList;
  } catch (error) {
    console.error("Error fetching degree titles list:", error);
    throw new Error("Could not fetch degree titles list");
  }
}

// Fetch all degree titles
export async function fetchAllDegreeTitles() {
  try {
    const records: DegreeTitle[] = await pb.collection("degreeTitles").getFullList({
      sort: "-name",
    });
    return records;
  } catch (error) {
    console.error("Error fetching all degree titles:", error);
    throw new Error("Could not fetch degree titles");
  }
}

export async function fetchDegreeTitleById(recordId: string) {
  try {
    return await pb.collection("degreeTitles").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching degree title by ID:", error);
    throw new Error("Could not fetch degree title");
  }
}

// Create a new degree title
export async function createDegreeTitle(data: DegreeTitle) {
  try {
    const record = await pb.collection("degreeTitles").create(data);
    return record;
  } catch (error) {
    console.error("Error creating degree title:", error);
    throw new Error("Could not create degree title");
  }
}

// Update an existing degree title
export async function updateDegreeTitle(recordId: string, data: DegreeTitle) {
  try {
    const record = await pb.collection("degreeTitles").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating degree title:", error);
    throw new Error("Could not update degree title");
  }
}

// Delete a degree title
export async function deleteDegreeTitle(recordId: string) {
  try {
    await pb.collection("degreeTitles").delete(recordId);
    return { message: "Degree title deleted successfully" };
  } catch (error) {
    console.error("Error deleting degree title:", error);
    throw new Error("Could not delete degree title");
  }
}
