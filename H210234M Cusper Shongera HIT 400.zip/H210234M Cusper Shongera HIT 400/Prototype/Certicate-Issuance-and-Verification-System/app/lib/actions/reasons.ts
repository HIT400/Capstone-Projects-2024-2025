"use server";

import { pb } from "@/config/pocketbase";
import { Reason } from "@/lib/validation";

export async function fetchAllReasons() {
  try {
    const records: Reason[] = await pb.collection("reasons").getFullList({
      sort: "value",
    });

    return records;
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error fetching reasons", error.message);
    } else {
      console.error("Error fetching reasons", error);
    }
    throw new Error("Could not fetch reasons");
  }
}
