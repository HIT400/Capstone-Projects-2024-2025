"use server";

import { pb } from "@/config/pocketbase";
import { Faculty } from "@/lib/validation";
import { getSession } from "./auth";

// Fetch a paginated list of faculties
export async function fetchFaculties(page = 1, pageSize = 50) {
  try {
    const resultList = await pb.collection("faculties").getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching faculties:", error);
    throw new Error("Could not fetch faculties");
  }
}

// Fetch all faculties
export async function fetchAllFaculties() {
  try {
    const records: Faculty[] = await pb.collection("faculties").getFullList({
      sort: "-name",
    });
    return records;
  } catch (error) {
    console.error("Error fetching all faculties:", error);
    throw new Error("Could not fetch faculties");
  }
}

export async function fetchCurrentUserFaculties() {
  try {
    const session = await getSession();
    if (!session.institutionId) {
      throw new Error("No institution ID found in session");
    }

    const resultList: Faculty[] = await pb.collection("faculties").getFullList({
      filter: `institutionId = "${session.institutionId}"`,
    });

    return resultList;
  } catch (error) {
    console.error("Error fetching faculties list:", error);
    throw new Error("Could not fetch faculties list");
  }
}

export async function fetchFacultyById(recordId: string) {
  try {
    return await pb.collection("faculties").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching faculty by ID:", error);
    throw new Error("Could not fetch faculty");
  }
}

// Create a new faculty
export async function createFaculty(data: Faculty) {
  try {
    const record = await pb.collection("faculties").create(data);
    return record;
  } catch (error) {
    console.error("Error creating faculty:", error);
    throw new Error("Could not create faculty");
  }
}

// Update an existing faculty
export async function updateFaculty(recordId: string, data: Faculty) {
  try {
    const record = await pb.collection("faculties").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating faculty:", error);
    throw new Error("Could not update faculty");
  }
}

// Delete a faculty
export async function deleteFaculty(recordId: string) {
  try {
    await pb.collection("faculties").delete(recordId);
    return { message: "Faculty deleted successfully" };
  } catch (error) {
    console.error("Error deleting faculty:", error);
    throw new Error("Could not delete faculty");
  }
}
