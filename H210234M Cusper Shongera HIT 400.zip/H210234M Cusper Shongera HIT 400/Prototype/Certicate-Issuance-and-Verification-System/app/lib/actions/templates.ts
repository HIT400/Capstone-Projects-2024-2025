"use server";

import { pb } from "@/config/pocketbase";
import { Template } from "@/lib/validation";
import { getSession } from "./auth";

// Fetch a paginated list of templates
export async function fetchTemplates(page = 1, pageSize = 50) {
  try {
    const resultList = await pb.collection("templates").getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching templates:", error);
    throw new Error("Could not fetch templates");
  }
}

// Fetch all templates
export async function fetchAllTemplates() {
  try {
    const records: Template[] = await pb.collection("templates").getFullList({
      sort: "-name",
    });

    const templates = records.map((record) => {
      const templateImageUrl = pb.files.getURL(record, record.templateImage as string);
      return {
        ...record,
        templateImage: templateImageUrl, // Replace 'logo' with its URL
      };
    });

    return templates;
  } catch (error) {
    console.error("Error fetching all templates:", error);
    throw new Error("Could not fetch templates");
  }
}

export async function fetchCurrentUserTemplates() {
  try {
    const session = await getSession();
    if (!session?.institutionId) {
      throw new Error("No institution ID found in session");
    }

    const resultList = await pb.collection("templates").getFullList({
      filter: `institutionId === "${session.institutionId}"`,
    });

    return resultList;
  } catch (error) {
    console.error("Error fetching templates list:", error);
    throw new Error("Could not fetch templates list");
  }
}

// Fetch a specific template by its ID
export async function fetchTemplateById(recordId: string) {
  try {
    return await pb.collection("templates").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching template by ID:", error);
    throw new Error("Could not fetch template");
  }
}

// Create a new template
export async function createTemplate(data: Template) {
  try {
    const record = await pb.collection("templates").create(data);
    return record;
  } catch (error) {
    console.error("Error creating template:", error);
    throw new Error("Could not create template");
  }
}

// Update an existing template
export async function updateTemplate(recordId: string, data: Template) {
  try {
    const record = await pb.collection("templates").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error updating template:", error);
    throw new Error("Could not update template");
  }
}

// Delete a template
export async function deleteTemplate(recordId: string) {
  try {
    await pb.collection("templates").delete(recordId);
    return { message: "Template deleted successfully" };
  } catch (error) {
    console.error("Error deleting template:", error);
    throw new Error("Could not delete template");
  }
}
