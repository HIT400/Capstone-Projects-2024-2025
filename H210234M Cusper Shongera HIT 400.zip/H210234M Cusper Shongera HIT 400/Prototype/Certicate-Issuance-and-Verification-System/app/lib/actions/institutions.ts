"use server";

import { pb } from "@/config/pocketbase";
import { Institution } from "@/lib/validation";

// Fetch a paginated list of institutions
export async function fetchInstitutions(page = 1, pageSize = 50) {
  try {
    const resultList = await pb
      .collection("institutions")
      .getList(page, pageSize);
    return resultList;
  } catch (error) {
    console.error("Error fetching institutions:", error);
    throw new Error("Could not fetch institutions");
  }
}

// Fetch all institutions
export async function fetchAllInstitutions() {
  try {
    const records: Institution[] = await pb
      .collection("institutions")
      .getFullList({
        sort: "institutionName",
        filter: `institutionName != "Admin"`,
      });

    // Map through the records to replace the 'logo' field with its URL
    const institutions = records.map((record) => {
      const logoUrl = pb.files.getURL(record, record.logo as string);
      return {
        ...record,
        logo: logoUrl, // Replace 'logo' with its URL
      };
    });

    return institutions;
  } catch (error) {
    console.error("Error fetching institutions", error);
    throw new Error("Could not fetch institutions");
  }
}

// Fetch a specific institution by its ID
export async function fetchInstitutionById(recordId: string) {
  try {
    const record: Institution = await pb
      .collection("institutions")
      .getOne(recordId);
    return { record };
  } catch (error) {
    console.error("Error fetching institutions", error);
    throw new Error("Could not fetch institutions");
  }
}

export async function fetchInstitutionByWalletAddress(walletAddress: string) {
  try {
    const record: Institution = await pb
      .collection("institutions")
      .getFirstListItem(`walletAddress="${walletAddress}"`);

    const logoUrl = pb.files.getURL(record, record.logo as string);
    return {
      ...record,
      logo: logoUrl,
    };
  } catch (error) {
    console.error("Error fetching institution by wallet address:", error);
    throw new Error("Could not fetch institution");
  }
}

// Create a new institution
export async function createInstitution(data: Institution) {
  try {
    // 1. Check if user already exists
    const existingUser = await pb.collection("users").getList(1, 1, {
      filter: `walletAddress = "${data.walletAddress}"`,
    });

    if (existingUser.items.length > 0) {
      throw new Error("User with this wallet address already exists.");
    }

    // 2. Create institution (first part of transaction)
    const institution = await pb.collection("institutions").create(data);

    try {
      // 3. Create user (second part of transaction)
      await pb.collection("users").create({
        walletAddress: data.walletAddress,
        role: "user",
        institutionId: institution.id,
        status: "Active",
      });

      return { record: institution };
    } catch (userError) {
      // Rollback institution creation if user creation fails
      await pb.collection("institutions").delete(institution.id);

      console.error(
        "Failed to create user. Institution creation rolled back.",
        userError
      );
      throw new Error(
        "Failed to create user. Institution creation rolled back."
      );
    }
  } catch (error) {
    console.error("An error occurred while creating institution:", error);
    throw new Error("An error occurred while creating institution");
  }
}

// Update an existing institution
export async function updateInstitution(recordId: string, data: Institution) {
  try {
    const record = await pb.collection("institutions").update(recordId, data);
    return record;
  } catch (error) {
    console.error("Error fetching institution by wallet address:", error);
    throw new Error("Could not fetch institution");
  }
}

// Delete an institution
export async function deleteInstitution(recordId: string) {
  try {
    await pb.collection("institutions").delete(recordId);
    return { message: "Institution deleted successfully" };
  } catch (error) {
    console.error("Error deleting institution.", error);
    throw new Error("Could not fetch institution");
  }
}
