"use server";

import { pb } from "@/config/pocketbase";
import { getSession } from "./auth";
import { FieldOfStudy } from "@/lib/validation";

// Fetch a paginated list of fields of study
export async function fetchFieldsOfStudy(
  page = 1,
  pageSize = 50,
  filter?: string
) {
  try {
    return await pb.collection("fieldsOfStudy").getList(page, pageSize, {
      filter: filter ? filter : undefined,
    });
  } catch (error) {
    console.error("Error fetching fields of study:", error);
    throw new Error("Could not fetch fields of study");
  }
}

// Fetch all fields of study
export async function fetchAllFieldsOfStudy() {
  try {
    const response : FieldOfStudy[] = await pb.collection("fieldsOfStudy").getFullList({
      sort: "-name",
    });
    return response
  } catch (error) {
    console.error("Error fetching all fields of study:", error);
    throw new Error("Could not fetch fields of study");
  }
}

// Fetch a single field of study by filter
export async function fetchFieldOfStudyByFilter(filter: string) {
  try {
    return await pb.collection("fieldsOfStudy").getFirstListItem(filter, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching field of study by filter:", error);
    throw new Error("Could not fetch field of study");
  }
}

export async function fetchCurrentUserFieldsOfStudy() {
  try {
    const session = await getSession();
    if (!session?.institutionId) {
      throw new Error("No institution ID found in session");
    }

    const resultList: FieldOfStudy[] = await pb.collection("fieldsOfStudy").getFullList({
      filter: `institutionId = "${session.institutionId}"`,
    });

    return resultList;
  } catch (error) {
    console.error("Error fetching fields of study list:", error);
    throw new Error("Could not fetch fields of study list");
  }
}

// Fetch a single field of study by ID
export async function fetchFieldOfStudyById(recordId: string) {
  try {
    return await pb.collection("fieldsOfStudy").getOne(recordId, {
      expand: "relField1,relField2.subRelField",
    });
  } catch (error) {
    console.error("Error fetching field of study by ID:", error);
    throw new Error("Could not fetch field of study");
  }
}

// Create a new field of study
export async function createFieldOfStudy(data: FieldOfStudy) {
  try {
    return await pb.collection("fieldsOfStudy").create(data);
  } catch (error) {
    console.error("Error creating field of study:", error);
    throw new Error("Could not create field of study");
  }
}

// Update an existing field of study
export async function updateFieldOfStudy(
  recordId: string,
  data: FieldOfStudy
) {
  try {
    return await pb.collection("fieldsOfStudy").update(recordId, data);
  } catch (error) {
    console.error("Error updating field of study:", error);
    throw new Error("Could not update field of study");
  }
}

// Delete a field of study
export async function deleteFieldOfStudy(recordId: string) {
  try {
    await pb.collection("fieldsOfStudy").delete(recordId);
    return { message: "Field of study deleted successfully" };
  } catch (error) {
    console.error("Error deleting field of study:", error);
    throw new Error("Could not delete field of study");
  }
}
