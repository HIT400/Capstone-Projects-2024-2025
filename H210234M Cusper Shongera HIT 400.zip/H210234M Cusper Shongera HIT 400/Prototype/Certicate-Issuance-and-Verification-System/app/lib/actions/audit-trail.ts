"use server";

import { pb } from "@/config/pocketbase";
import { AuditTrailWithName } from "@/lib/validation";

// Fetch a paginated list of degree titles
export async function fetchAuditTrail() {
  try {
    const records = await pb.collection("auditTrail").getFullList({
      sort: "timestamp", // Assuming sorting by institutionId
      expand: "performedBy", // Expand institution relation
    });

    // Map to ensure each user has institutionName
    const auditTrailWithInstitutions: AuditTrailWithName[] = records.map(
      (auditTrailWithInstitutions) => ({
        id: auditTrailWithInstitutions.id,
        timestamp: auditTrailWithInstitutions.timestamp, // Ensure this field exists in your PocketBase schema
        action: auditTrailWithInstitutions.action, // Ensure this field exists in your PocketBase schema
        performedBy: auditTrailWithInstitutions.performedBy,
        details: auditTrailWithInstitutions.details, // Make sure `status` exists in the PocketBase schema
        institutionName:
          auditTrailWithInstitutions.expand?.performedBy?.institutionName,
      })
    );

    return auditTrailWithInstitutions;
  } catch (error) {
    console.error("Error fetching all audit trail:", error);
    throw new Error("Could not fetch audit trail.");
  }
}
