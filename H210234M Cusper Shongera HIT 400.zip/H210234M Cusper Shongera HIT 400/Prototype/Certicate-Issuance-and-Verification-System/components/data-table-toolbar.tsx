"use client";

import { Table } from "@tanstack/react-table";
import { X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DataTableViewOptions } from "./data-table-view-options";

import { DataTableFacetedFilter } from "./data-table-faceted-filter";
import {
  InstitutionTypes,
  AuditTrailActions,
  CertificateStatuses,
  AccountStatuses,
  Roles,
  Positions,
  Grades,
} from "@/lib/constants";
import FormDialog from "./dialog/forms-dialog";
import { useState } from "react";
import CertificateForm from "./forms/certificate-form";
import InstitutionForm from "./forms/institution-form";
import FacultyForm from "./forms/faculty-form";
import DegreeTitleForm from "./forms/degree-title-form";
import FieldsOfStudyForm from "./forms/fields-of-study";
import SignatureForm from "./forms/signatures";
import CertificateTemplateForm from "./forms/certificate-template-form";

interface DataTableToolbarProps<TData> {
  table: Table<TData>;
  tableName?: string;
}

// Mapping table names to corresponding forms
const formComponents: Record<string, React.FC<{ onClose: () => void }>> = {
  certificates: CertificateForm,
  institutions: InstitutionForm,
  faculties: FacultyForm,
  degreeTitles: DegreeTitleForm,
  fieldsOfStudy: FieldsOfStudyForm,
  signatures: SignatureForm,
  certificateTemplates: CertificateTemplateForm,
};

const dialogTitles: Record<string, string> = {
  certificates: "Certificate",
  institutions: "Institution",
  faculties: "Faculty",
  degreeTitles: "Degree Title",
  fieldsOfStudy: "Field of Study",
  signatures: "Signature",
  certificateTemplates: "Certificate Template",
};

export function DataTableToolbar<TData>({
  table,
  tableName,
}: DataTableToolbarProps<TData>) {
  const [showFormDialog, setShowFormDialog] = useState(false);
  const isFiltered = table.getState().columnFilters.length > 0;

  const SelectedForm = tableName ? formComponents[tableName] : null;
  const dialogTitle = tableName ? dialogTitles[tableName] : "Item";
  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-1 items-center space-x-2">
        <Input
          placeholder="Search table..."
          value={table.getState().globalFilter ?? ""}
          onChange={(event) => table.setGlobalFilter(event.target.value)}
          className="h-8 w-[150px] lg:w-[250px]"
        />
        <>
          {(() => {
            switch (tableName) {
              case "institutions":
                return (
                  <>
                    {table.getColumn("institutionType") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("institutionType")}
                        title="Inst. Type"
                        options={InstitutionTypes}
                      />
                    )}
                  </>
                );
              case "applications":
                return (
                  <>
                    {table.getColumn("institutionType") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("institutionType")}
                        title="Inst. Type"
                        options={InstitutionTypes}
                      />
                    )}
                  </>
                );
              case "audit-trail":
                return (
                  <>
                    {table.getColumn("action") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("action")}
                        title="Action"
                        options={AuditTrailActions}
                      />
                    )}
                  </>
                );
              case "certificates":
                return (
                  <>
                    {table.getColumn("status") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("status")}
                        title="Status"
                        options={CertificateStatuses}
                      />
                    )}
                    {table.getColumn("grade") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("grade")}
                        title="Grade"
                        options={Grades}
                      />
                    )}
                  </>
                );
              case "signatures":
                return (
                  <>
                    {table.getColumn("position") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("position")}
                        title="Position"
                        options={Positions}
                      />
                    )}
                  </>
                );
              case "users":
                return (
                  <>
                    {table.getColumn("status") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("status")}
                        title="Status"
                        options={AccountStatuses}
                      />
                    )}
                    {table.getColumn("role") && (
                      <DataTableFacetedFilter
                        column={table.getColumn("role")}
                        title="Role"
                        options={Roles}
                      />
                    )}
                  </>
                );
              default:
                return null;
            }
          })()}
        </>

        {isFiltered && (
          <Button
            variant="ghost"
            onClick={() => table.resetColumnFilters()}
            className="h-8 px-2 lg:px-3"
          >
            Reset
            <X />
          </Button>
        )}
      </div>
      <div className="flex flex-row items-center gap-2">
        <DataTableViewOptions table={table} />
        {tableName != "users" && tableName != "audit-trail" && (
          <Button size="sm" onClick={() => setShowFormDialog(true)}>Add New</Button>
        )}
        <FormDialog
          isOpen={showFormDialog}
          onClose={() => {
            setShowFormDialog(false);
            setTimeout(() => {
              const body = document.querySelector("body");
              if (body) {
                body.style.pointerEvents = "auto";
              }
            }, 500);
          }}
          title={`Add ${dialogTitle}`}
        >
          {SelectedForm && (
            <SelectedForm
              onClose={() => {
                setShowFormDialog(false);
                setTimeout(() => {
                  const body = document.querySelector("body");
                  if (body) {
                    body.style.pointerEvents = "auto";
                  }
                }, 500);
              }}
            />
          )}
        </FormDialog>
      </div>
    </div>
  );
}
