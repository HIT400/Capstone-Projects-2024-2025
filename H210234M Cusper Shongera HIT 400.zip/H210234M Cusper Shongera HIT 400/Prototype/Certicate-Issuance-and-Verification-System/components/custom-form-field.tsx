"use client";

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Control } from "react-hook-form";

import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { E164Number } from "libphonenumber-js";

import { Select, SelectContent, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Checkbox } from "./ui/checkbox";
import { FormFieldType } from "@/lib/constants";
import Link from "next/link";
import { useState } from "react";
import { Button } from "./ui/button";
import { Eye, EyeOff } from "lucide-react";
import { DatePicker } from "./date-picker";

interface CustomFormFieldProps {
  control: Control<any>;
  fieldType: FormFieldType;
  name: string;
  label?: string;
  placeholder?: string;
  iconSrc?: string;
  iconAlt?: string;
  disabled?: boolean;
  dateFormat?: string;
  minDate?: string;
  maxDate?: string;
  showTimeSelect?: boolean;
  startYear?: number;
  endYear?: number;
  children?: React.ReactNode;
  forgotPassword?: boolean;
  renderSkeleton?: (field: any) => React.ReactNode;
}

const RenderField = ({
  field,
  props,
  showPassword,
  setShowPassword,
}: {
  field: any;
  props: CustomFormFieldProps;
  showPassword: boolean;
  setShowPassword: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  const {
    fieldType,
    placeholder,
    dateFormat,
    startYear,
    endYear,
    renderSkeleton,
    children,
    disabled,
    label,
  } = props;

  switch (fieldType) {
    case FormFieldType.INPUT:
      return (
        <FormControl>
          <Input {...field} placeholder={placeholder} />
        </FormControl>
      );
    case FormFieldType.PHONE_INPUT:
      return (
        <FormControl>
          <PhoneInput
            defaultCountry="ZW"
            placeholder={placeholder}
            international
            withCountryCallingCode
            value={(field.value as E164Number) || undefined}
            onChange={field.onChange}
            className="input-phone"
            disabled={disabled}
          />
        </FormControl>
      );
    case FormFieldType.PASSWORD:
      return (
        <FormControl>
          <div className="relative">
            <Input
              {...field}
              placeholder={placeholder}
              type={showPassword ? "text" : "password"}
              disabled={disabled}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute bottom-1 right-1 h-7 w-7"
              onClick={() => setShowPassword(!showPassword)}
            >{showPassword ? <EyeOff className="size-4 text-muted-foreground" /> : <Eye className="size-4 text-muted-foreground" /> }
              
              <span className="sr-only">Toggle password visibility</span>
            </Button>
          </div>
        </FormControl>
      );
    case FormFieldType.DATEPICKER:
      return (
        <DatePicker
          date={field.value ? new Date(field.value) : undefined}
          setDate={(date) => {
            if (date) {
              field.onChange(date);
            }
          }}
          dateFormat={dateFormat}
          endYear={endYear}
          startYear={startYear}
          disabled={disabled}
        />
      );
    case FormFieldType.SKELETON:
      return renderSkeleton ? renderSkeleton(field) : null;
    case FormFieldType.SELECT:
      return (
        <FormControl >
          <Select onValueChange={field.onChange} defaultValue={field.value}>
            <FormControl>
              <SelectTrigger disabled={disabled}>
                <SelectValue placeholder={placeholder} />
              </SelectTrigger>
            </FormControl>
            <SelectContent className="ring-1 ring-ring">
              {children}
            </SelectContent>
          </Select>
        </FormControl>
      );
    case FormFieldType.TEXTAREA:
      return (
        <Textarea {...field} placeholder={placeholder} disabled={disabled} />
      );
    case FormFieldType.CHECKBOX:
      return (
        <div className="flex flex-row items-center space-x-3 space-y-0 rounded-md p-4 ">
          <FormControl>
            <Checkbox checked={field.value} onCheckedChange={field.onChange} disabled={disabled}/>
          </FormControl>
          <div className="space-y-1 leading-none">
            <FormLabel>{label}</FormLabel>
          </div>
        </div>
      );
    default:
      return null;
  }
};

const CustomFormField = (props: CustomFormFieldProps) => {
  const { control, fieldType, name, label, forgotPassword } = props;
  const [showPassword, setShowPassword] = useState(false);
  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem className="flex-1">
          {label && (
            <FormLabel>
              {(() => {
                switch (fieldType) {
                  case FormFieldType.CHECKBOX:
                    return null;
                  case FormFieldType.PASSWORD:
                    return forgotPassword ? (
                      <div className="flex items-center">
                        <span>{label}</span>
                        <Link
                          href="/reset-password"
                          className="ml-auto inline-block text-sm underline-offset-4 hover:underline"
                        >
                          Forgot your password?
                        </Link>
                      </div>
                    ) : (
                      label
                    );
                  default:
                    return label;
                }
              })()}
            </FormLabel>
          )}

          <RenderField
            field={field}
            props={props}
            showPassword={showPassword}
            setShowPassword={setShowPassword}
          />

          <FormMessage className="shad-error text-xs" />
        </FormItem>
      )}
    />
  );
};

export default CustomFormField;
