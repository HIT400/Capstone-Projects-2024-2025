import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { certificateFactoryContract } from "@/config/thirdweb";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useRef, useState } from "react";
import { prepareContractCall } from "thirdweb";
import { TransactionButton } from "thirdweb/react";

interface AlertDialogProps {
  title?: string;
  description?: string;
  isOpen: boolean;
  certificateAddress?: string;
  deleteRecord: () => void;
  onClose: () => void;
}

const DeleteDialog = ({
  title,
  description,
  isOpen,
  deleteRecord,
  certificateAddress,
  onClose,
}: AlertDialogProps) => {
  const cancelButtonRef = useRef<HTMLButtonElement | null>(null);
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isOpen && cancelButtonRef.current) {
      cancelButtonRef.current.focus(); // Moves focus to Cancel button when closing
    }
  }, [isOpen]);

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {title ? title : "Are you absolutely sure?"}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {description
              ? description
              : "This action cannot be undone. This will permanently delete this record from our servers."}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex">
          <Button
            ref={cancelButtonRef}
            variant="secondary"
            onClick={onClose}
            className="basis-1/2"
          >
            Cancel
          </Button>
          {certificateAddress ? (
            <div className="basis-1/2">
              <TransactionButton
                disabled={isLoading}
                className="transaction-button-destructive"
                type="button"
                transaction={() => {
                  setIsLoading(true);
                  return prepareContractCall({
                    contract: certificateFactoryContract,
                    method:
                      "function deleteCertificate(address _certificateAddress)",
                    params: [certificateAddress as string],
                  });
                }}
                onError={() => {
                  setIsLoading(true);
                  toast({
                    variant: "destructive",
                    title: "Transaction Failed",
                    description:
                      "An error occurred while processing the transaction.",
                  });
                }}
                onTransactionConfirmed={async () => {
                  await deleteRecord();
                  setIsLoading(false);
                }}
              >
                Continue
              </TransactionButton>
            </div>
          ) : (
            <Button
              variant="destructive"
              onClick={deleteRecord}
              className="basis-1/2"
            >
              Continue
            </Button>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default DeleteDialog;
