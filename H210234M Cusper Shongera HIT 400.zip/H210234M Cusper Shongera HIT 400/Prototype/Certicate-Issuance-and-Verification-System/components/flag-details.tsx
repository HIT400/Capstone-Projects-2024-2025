import React from "react";
import { Badge } from "./ui/badge";
import { cn } from "@/lib/utils";
import Image from "next/image";
import { Flag } from "@/lib/validation";
import { Button } from "./ui/button";
import { Bookmark, BookmarkCheck, Mail, MailOpen } from "lucide-react";

interface FlagProps {
  data: Flag;
  onToggleSaved?: () => void;
  onToggleRead?: () => void;
}

const FlagDetailsSection: React.FC<FlagProps> = ({
  data,
  onToggleSaved,
  onToggleRead,
}) => {
  return (
    <div className="space-y-8 bg-background">
      {/* Institution Header */}
      <div className="text-center space-y-3">
        <h1 className="text-lg font-semibold text-foreground">
          Report For Flagged Certificate
        </h1>
        <div className="flex justify-center items-center gap-2">
          <Badge
            variant="outline"
            className="text-sm font-medium bg-primary/10 text-foreground"
          >
            Flag ID:{" "}
            <span className="tabular-nums tracking-wider ml-1">{data.id}</span>
          </Badge>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Image Section */}
        {data.image && (
          <div className="space-y-6">
            <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
              <span>Certificate Image</span>
            </h2>
            <div className="relative aspect-[3/4] w-full rounded-md overflow-hidden">
              <Image
                src={data.image as string}
                alt="Flagged Certificate"
                fill
                className="object-contain"
                priority
              />
            </div>
          </div>
        )}

        {/* Details Section */}
        <div className="space-y-6">
          {/* Flag Information */}
          <div className="space-y-6">
            <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
              <span>Flag Details</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Institution</p>
                <p className="text-sm font-medium text-foreground">
                  {data.institution}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Certificate ID</p>
                <p className="text-sm font-medium text-foreground">
                  {data.certificate ? data.certificate : "N/A"}
                </p>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Date Flagged</p>
                <p className="text-sm font-medium text-foreground">
                  {new Date(data.date).toLocaleDateString()}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Reason</p>
                <p className="text-sm font-medium text-foreground">
                  {data.reason}
                </p>
              </div>
              {/* <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Status</p>
                <Badge
                  className={cn("text-sm font-medium", {
                    "bg-green-600 hover:bg-green-600":
                      data.validity === "valid",
                    "bg-destructive hover:bg-destructive":
                      data.validity === "invalid",
                  })}
                >
                  {data.validity}
                </Badge>
              </div> */}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-6">
            <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
              <span>Description</span>
            </h2>
            <div className="space-y-2">
              <p className="text-sm font-medium text-foreground">
                {data.description}
              </p>
            </div>
          </div>
          <div className="space-y-6">
            <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
              <span>Actions</span>
            </h2>
            <div className="flex gap-4 items-center">
              {/* Actionable Read Status */}
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  className={cn("gap-2", {
                    "bg-green-100 hover:bg-green-100/80 text-green-800":
                      data.read === "read",
                    "bg-yellow-100 hover:bg-yellow-100/80 text-yellow-800":
                      data.read === "unread",
                  })}
                  onClick={onToggleRead}
                >
                  {data.read === "read" ? (
                    <MailOpen className="h-4 w-4" />
                  ) : (
                    <Mail className="h-4 w-4" />
                  )}
                  <span className="capitalize">
                    {" "}
                    {data.read === "read" ? "Mark as unread" : "Mark as read"}
                  </span>
                </Button>
              </div>

              {/* Actionable Saved Status */}
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  className={cn("gap-2", {
                    "bg-green-100 hover:bg-green-100/80 text-green-800":
                      data.saved === "saved",
                    "bg-yellow-100 hover:bg-yellow-100/80 text-yellow-800":
                      data.saved === "unsaved",
                  })}
                  onClick={onToggleSaved}
                >
                  {data.saved === "saved" ? (
                    <BookmarkCheck className="h-4 w-4" />
                  ) : (
                    <Bookmark className="h-4 w-4" />
                  )}
                  <span className="capitalize">{data.saved}</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlagDetailsSection;
