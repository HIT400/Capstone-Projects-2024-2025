"use client";

import useDimensions from "@/hooks/useDimensions";
import { cn } from "@/lib/utils";
import { CertificateDetails } from "@/lib/validation";
import Image from "next/image";
import React, { useRef } from "react";

interface CertificateTemplateProps {
  certificate?: CertificateDetails;
  contentRef?: React.Ref<HTMLDivElement>;
}

const CertificateTemplate: React.FC<CertificateTemplateProps> = ({
  certificate,
  contentRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { width } = useDimensions(containerRef as React.RefObject<HTMLElement>);
  console.log(certificate);
  return (
    <div
      className={cn(
        "aspect-[210/297] h-fit w-full bg-[#FAF9F6] text-black border",
        "shadow-lg"
      )}
      ref={containerRef}
    >
      <div
        className={cn(
          "px-12 pt-16 pb-14 h-full flex flex-col justify-between space-y-6", // Increased padding
          !width && "invisible"
        )}
        style={{ zoom: (1 / 794) * width }}
        ref={contentRef}
        id="resumePreviewContent"
      >
        {/* Institution Header */}
        <div className="flex flex-col items-center space-y-4">
          <h1 className="text-3xl font-bold text-gray-900 tracking-wide uppercase font-serif">
            {certificate?.institutionName}
          </h1>
          <div className="border-t-2 border-gray-700 w-24 mx-auto my-4" />
          <Image
            src={
              typeof certificate?.institutionLogo === "string" &&
              certificate.institutionLogo.trim()
                ? certificate.institutionLogo
                : "/placeholder.svg"
            }
            alt="Logo"
            width={260}
            height={80}
            className="my-4 h-auto w-auto object-contain"
          />
        </div>

        {/* Recipient Information */}
        <div className="flex flex-col text-center space-y-6">
          <p className="text-lg text-gray-700">This is to certify that</p>
          <h2 className="text-3xl font-bold text-gray-900 uppercase tracking-wider font-serif">
            {certificate?.studentFullName}
          </h2>
        </div>

        {/* Body Text */}
        <div className="text-center space-y-6 text-gray-700 leading-tight">
          <p className="text-lg">
            having completed the programme of study approved by the Institute
            and having
          </p>
          <p className="text-lg">
            satisfied the Examiners has this day been admitted by the Senate to
            the
          </p>
        </div>

        {/* Degree Information */}
        <div className="flex flex-col items-center space-y-4">
          <h3 className="text-2xl font-bold text-gray-900 uppercase tracking-wide font-serif">
            {certificate?.degreeTitle} Honours Degree
          </h3>
          <h3 className="text-xl font-semibold text-gray-800">
            in {certificate?.fieldOfStudy}
          </h3>
        </div>

        {/* Division */}
        <p className="text-center text-xl font-bold text-gray-900 uppercase tracking-wider">
          IN THE {certificate?.grade} DIVISION
        </p>

        {/* Signatures */}
        <div className="flex justify-between items-end mt-8">
          <div className="flex-1 text-center space-y-2">
            <div className="border-b-2 border-gray-700 w-36 mx-auto mb-2 relative">
              <Image
                src={
                  certificate?.signatures[0].position === "chancellor" ||
                  certificate?.signatures[0].position === "vice chancellor"
                    ? (certificate?.signatures[0].signatureImage as string)
                    : (certificate?.signatures[1].signatureImage as string)
                }
                alt="Seal"
                width={100}
                height={100}
                className="w-28 h-28 absolute -bottom-8 left-2"
              />
            </div>
            <p className="text-sm font-medium text-gray-700 capitalize">
              {certificate?.signatures[0].position === "chancellor" ||
              certificate?.signatures[0].position === "vice chancellor"
                ? certificate?.signatures[0].position
                : certificate?.signatures[1].position}
            </p>
          </div>

          <Image
            src="/red-seal.png"
            alt="Seal"
            width={100}
            height={100}
            className="w-28 h-28"
          />

          <div className="flex-1 text-center space-y-2">
            <div className="border-b-2 border-gray-700 w-36 mx-auto mb-2 relative">
              <Image
                src={
                  certificate?.signatures[0].position === "registrar"
                    ? (certificate?.signatures[0].signatureImage as string)
                    : (certificate?.signatures[1].signatureImage as string)
                }
                alt="Seal"
                width={100}
                height={100}
                className="w-28 h-28 absolute -bottom-8 left-2"
              />
            </div>
            <p className="text-sm font-medium text-gray-700 capitalize">
              {certificate?.signatures[0].position === "registrar"
                ? certificate?.signatures[0].position
                : certificate?.signatures[1].position}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center pt-6 border-t-2 border-gray-200">
          <Image
            src={certificate?.qrcode as string}
            alt="QR Code"
            width={80}
            height={80}
            className="w-20 h-20 border border-gray-300 p-0.5"
          />
          <div className="text-end flex flex-col justify-between">
            <div className="">
              <p className="text-sm font-semibold text-gray-700">
                Certificate Number
              </p>
              <p className="text-lg text-red-700 tracking-widest font-mono font-bold">
                {certificate?.id}
              </p>
            </div>
            <p>
              {new Date(
                certificate?.dateOfAward as string
              ).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateTemplate;
