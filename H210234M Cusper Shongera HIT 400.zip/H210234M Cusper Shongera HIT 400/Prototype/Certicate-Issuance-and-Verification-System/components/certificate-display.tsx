import { CertificateDetails } from "@/lib/validation";
import React from "react";
import { Badge } from "./ui/badge";
import { cn } from "@/lib/utils";

interface CertificateProps {
  data: CertificateDetails;
}

const CertificateDetailsSection: React.FC<CertificateProps> = ({ data }) => {
  return (
    <div className="space-y-8 bg-background">
      {/* Institution Header */}
      <div className="text-center space-y-3">
        <h1 className="text-lg font-semibold text-foreground">
          {data.institutionName}
        </h1>
        <p className="text-sm text-muted-foreground">{data.faculty}</p>
        <div className="flex justify-center items-center">
          <Badge
            variant="outline"
            className="text-sm font-medium bg-primary/10 text-foreground "
          >
            Certificate ID:{" "}
            <span className="tabular-nums tracking-wider ml-1">{data.id}</span>
          </Badge>
        </div>
      </div>

      {/* Student Information */}
      <div className="space-y-6">
        <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
          <span>Student Details</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Full Name</p>
            <p className="text-sm font-medium text-foreground">
              {data.studentFullName}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Student ID</p>
            <p className="text-sm font-medium text-foreground">
              {data.studentId}
            </p>
          </div>
        </div>
      </div>

      {/* Award Details */}
      <div className="space-y-6">
        <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
          <span>Certificate Details</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Degree Title</p>
            <p className="text-sm font-medium text-foreground">
              {data.degreeTitle}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Field of Study</p>
            <p className="text-sm font-medium text-foreground">
              {data.fieldOfStudy}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Grade</p>
            <p className="text-sm font-medium text-foreground">{data.grade}</p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">onChain Address</p>
            <p className="text-sm  font-medium text-foreground break-all">
              {data.address}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Date of Award</p>
            <p className="text-sm font-medium text-foreground">
              {new Date(data.dateOfAward).toLocaleDateString()}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Status</p>
            <Badge
              className={cn("text-sm font-medium", {
                "bg-green-600 hover:bg-green-600": data.status === "Valid",
                "bg-yellow-600 hover:bg-yellow-600": data.status === "Held",
                "bg-destructive hover:bg-destructive":
                  data.status === "Revoked",
              })}
            >
              {data.status}
            </Badge>
          </div>
        </div>
      </div>

      {/* Signatures */}
      <div className="space-y-6">
        <h2 className="font-medium text-base font-bold bg-primary/10 border-b px-2 py-1 flex items-center rounded-sm">
          <span>Signatures Details</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground capitalize">
              {data.signatures[0].position}
            </p>
            <p className="text-sm font-medium text-foreground">
              {data.signatures[0].fullName}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground capitalize">
              {data.signatures[1].position}
            </p>
            <p className="text-sm  font-medium text-foreground">
              {data.signatures[1].fullName}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateDetailsSection;
