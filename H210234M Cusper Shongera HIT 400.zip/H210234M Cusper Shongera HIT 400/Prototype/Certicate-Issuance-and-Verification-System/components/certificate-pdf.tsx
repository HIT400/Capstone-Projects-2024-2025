// components/certificate-pdf.tsx
"use client";

import {
  Document,
  Page,
  View,
  Text,
  Image as PDFImage,
  StyleSheet,
} from "@react-pdf/renderer";
import { CertificateDetails } from "@/lib/validation";

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: "#FAF9F6",
    padding: 40,
    fontFamily: "Helvetica",
    height: "100%",
  },
  container: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "space-between",
  },
  header: {
    alignItems: "center",
    marginBottom: 20,
  },
  institutionName: {
    fontSize: 24,
    fontWeight: "bold",
    textTransform: "uppercase",
    fontFamily: "Times-Roman",
    letterSpacing: 1,
  },
  divider: {
    width: "24mm",
    height: 2,
    backgroundColor: "#333",
    marginVertical: 10,
  },
  logo: {
    width: "65mm",
    height: "20mm",
    marginVertical: 10,
    objectFit: "contain",
  },
  studentInfo: {
    alignItems: "center",
    marginVertical: 15,
  },
  certifyText: {
    fontSize: 14,
    color: "#555",
  },
  studentName: {
    fontSize: 24,
    fontWeight: "bold",
    textTransform: "uppercase",
    fontFamily: "Times-Roman",
    letterSpacing: 2,
    marginVertical: 10,
  },
  bodyText: {
    textAlign: "center",
    fontSize: 14,
    color: "#555",
    lineHeight: 1.5,
    marginVertical: 10,
  },
  degreeInfo: {
    alignItems: "center",
    marginVertical: 15,
  },
  degreeTitle: {
    fontSize: 18,
    fontWeight: "bold",
    textTransform: "uppercase",
    fontFamily: "Times-Roman",
    letterSpacing: 1,
  },
  fieldOfStudy: {
    fontSize: 16,
    color: "#555",
    marginTop: 5,
  },
  divisionText: {
    fontSize: 16,
    fontWeight: "bold",
    textTransform: "uppercase",
    letterSpacing: 2,
    marginVertical: 15,
    textAlign: "center",
  },
  signatures: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 30,
  },
  signatureBox: {
    width: "36mm",
    alignItems: "center",
  },
  signatureLine: {
    width: "36mm",
    height: 1,
    backgroundColor: "#333",
    marginBottom: 20,
  },
  signatureImage: {
    width: "28mm",
    height: "28mm",
    marginBottom: -12,
  },
  signatureText: {
    fontSize: 10,
    color: "#555",
    textTransform: "capitalize",
  },
  sealImage: {
    width: "28mm",
    height: "28mm",
    alignSelf: "center",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#ddd",
    paddingTop: 15,
    marginTop: 20,
  },
  qrCode: {
    width: "20mm",
    height: "20mm",
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 1,
  },
  certificateNumber: {
    alignItems: "flex-end",
  },
  numberLabel: {
    fontSize: 10,
    fontWeight: "bold",
    color: "#555",
  },
  numberValue: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#d00",
    letterSpacing: 2,
    fontFamily: "Courier",
  },
  dateText: {
    fontSize: 12,
    color: "#555",
  },
});

interface CertificatePDFProps {
  certificate: CertificateDetails;
}

export const CertificatePDF = ({ certificate }: CertificatePDFProps) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.container}>
        {/* Institution Header */}
        <View style={styles.header}>
          <Text style={styles.institutionName}>
            {certificate.institutionName}
          </Text>
          <View style={styles.divider} />
          {certificate.institutionLogo && (
            <PDFImage src={certificate.institutionLogo} style={styles.logo} />
          )}
        </View>

        {/* Recipient Information */}
        <View style={styles.studentInfo}>
          <Text style={styles.certifyText}>This is to certify that</Text>
          <Text style={styles.studentName}>{certificate.studentFullName}</Text>
        </View>

        {/* Body Text */}
        <View>
          <Text style={styles.bodyText}>
            having completed the programme of study approved by the Institute
          </Text>
          <Text style={styles.bodyText}>
            and having satisfied the Examiners has this day been admitted by the
            Senate to the
          </Text>
        </View>

        {/* Degree Information */}
        <View style={styles.degreeInfo}>
          <Text style={styles.degreeTitle}>
            {certificate.degreeTitle} Honours Degree
          </Text>
          <Text style={styles.fieldOfStudy}>in {certificate.fieldOfStudy}</Text>
        </View>

        {/* Division */}
        <Text style={styles.divisionText}>
          IN THE {certificate.grade} DIVISION
        </Text>

        {/* Signatures */}
        <View style={styles.signatures}>
          <View style={styles.signatureBox}>
            {certificate.signatures[0] && (
              <>
                <PDFImage
                  src={
                    certificate.signatures[0].position === "chancellor" ||
                    certificate.signatures[0].position === "vice chancellor"
                      ? certificate.signatures[0].signatureImage
                      : certificate.signatures[1].signatureImage
                  }
                  style={styles.signatureImage}
                />
                <View style={styles.signatureLine} />
                <Text style={styles.signatureText}>
                  {certificate.signatures[0].position === "chancellor" ||
                  certificate.signatures[0].position === "vice chancellor"
                    ? certificate.signatures[0].position
                    : certificate.signatures[1].position}
                </Text>
              </>
            )}
          </View>

          <PDFImage src="/red-seal.png" style={styles.sealImage} />

          <View style={styles.signatureBox}>
            {certificate.signatures[0] && (
              <>
                <PDFImage
                  src={
                    certificate.signatures[0].position === "registrar"
                      ? certificate.signatures[0].signatureImage
                      : certificate.signatures[1].signatureImage
                  }
                  style={styles.signatureImage}
                />
                <View style={styles.signatureLine} />
                <Text style={styles.signatureText}>
                  {certificate.signatures[0].position === "registrar"
                    ? certificate.signatures[0].position
                    : certificate.signatures[1].position}
                </Text>
              </>
            )}
          </View>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          {certificate.qrcode && (
            <PDFImage src={certificate.qrcode} style={styles.qrCode} />
          )}
          <View style={styles.certificateNumber}>
            <Text style={styles.numberLabel}>Certificate Number</Text>
            <Text style={styles.numberValue}>{certificate.id}</Text>
            <Text style={styles.dateText}>
              {new Date(certificate.dateOfAward).toLocaleDateString()}
            </Text>
          </View>
        </View>
      </View>
    </Page>
  </Document>
);
