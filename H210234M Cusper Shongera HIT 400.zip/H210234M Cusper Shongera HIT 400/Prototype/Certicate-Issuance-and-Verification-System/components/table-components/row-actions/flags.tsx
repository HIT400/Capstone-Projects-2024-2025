"use client";

import { Row } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { FlagSchema } from "@/lib/validation";

import { useMutation, useQueryClient } from "@tanstack/react-query";

import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import {
  changeFlagReadStatus,
  changeFlagSavedStatus,
  deleteFlag,
} from "@/app/lib/actions/flags";
import DeleteDialog from "@/components/dialog/delete-dialog";

interface FlagsDataTableRowActionsProps<TData> {
  row: Row<TData>;
}

export function FlagsDataTableRowActions<TData>({
  row,
}: FlagsDataTableRowActionsProps<TData>) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const queryClient = useQueryClient();
  const data = FlagSchema.parse(row.original);
  const router = useRouter();
    const { toast } = useToast();

  const deleteMutation = useMutation({
    mutationFn: (id: string) => {
      return deleteFlag(id);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Flag Deleted 🎉",
        description: "The flag has been successfully deleted.",
      });
      queryClient.invalidateQueries({
        queryKey: ["flags-table"],
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Oops! Something went wrong.",
        description: "Failed to delete flag.",
      });
    },
  });

  const readChangeMutation = useMutation({
    mutationFn: (status: boolean) => {
      return changeFlagReadStatus(data.id as string, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["flags-table"] });
    },
    onError: (error: any) => {
      throw error;
    },
  });

  const savedChangeMutation = useMutation({
    mutationFn: (status: boolean) => {
      return changeFlagSavedStatus(data.id as string, status);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Flag Bookmarked Status Changed 🎉",
        description: "The flag has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["flags-table"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Oops! Something went wrong.",
        description: "Failed to update bookmarked status",
      });
    },
  });

  const closeDeleteDialog = () => {
    setShowDeleteDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const handleChangeRead = async () => {
    try {
      if (data.read === "read") {
        readChangeMutation.mutate(false);
      } else {
        readChangeMutation.mutate(true);
      }
      toast({
        variant: "success",
        title: "Flag Read Status Changed 🎉",
        description: "Flag's read status has been successfully updated.",
      });
    } catch {
      toast({
        variant: "destructive",
        title: "Oops! Something went wrong.",
        description: "Failed to update read status",
      });
    }
  };

  const handleChangeSaved = async () => {
    if (data.saved === "saved") {
      savedChangeMutation.mutate(false);
    } else {
      savedChangeMutation.mutate(true);
    }
  };

  const handleDelete = async () => {
    deleteMutation.mutate(data.id as string);
    closeDeleteDialog();
  };

  return (
    <>
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={closeDeleteDialog}
        deleteRecord={() => handleDelete()}
      />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="flex h-8 w-8 p-0 data-[state=open]:bg-muted"
          >
            <MoreHorizontal />
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuItem
            onClick={() => {
              readChangeMutation.mutate(true);
              if (data.certificate) {
                router.push(
                  `/flag/${data.id}?certificateId=${data.certificate}`
                );
              } else {
                router.push(`/flag/${data.id}`);
              }
            }}
          >
            View
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleChangeRead}>
            {data.read === "read" ? "Mark as unread" : "Mark as read"}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleChangeSaved}>
            {data.saved === "saved" ? "Remove Bookmark" : "Bookmark"}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={() => {
              setShowDeleteDialog(true);
            }}
          >
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
