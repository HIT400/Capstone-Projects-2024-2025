"use client";

import { Row } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { UserWithNameSchema } from "@/lib/validation";
import { useState } from "react";
import DeleteDialog from "@/components/dialog/delete-dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  changeAccountStatus,
  changeUserRole,
  deleteUser,
} from "@/app/lib/actions/users";
import { AccountStatuses, Roles } from "@/lib/constants";

interface UsersDataTableRowActionsProps<TData> {
  row: Row<TData>;
}

export function UsersDataTableRowActions<TData>({
  row,
}: UsersDataTableRowActionsProps<TData>) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const data = UserWithNameSchema.parse(row.original);

  const deleteMutation = useMutation({
    mutationFn: (id: string) => {
      return deleteUser(id);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "User Deleted! 🎉",
        description: "The user has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["users-table"] }); // Refresh the table
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to delete user.",
      });
    },
  });

  const statusChangeMutation = useMutation({
    mutationFn: (status: string) => {
      return changeAccountStatus(data.id as string, status);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Status Changed! 🎉",
        description: "The status has been successfully changed.",
      });
      queryClient.invalidateQueries({ queryKey: ["users-table"] }); // Refresh the table
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to change status.",
      });
    },
  });

  const roleChangeMutation = useMutation({
    mutationFn: (role: string) => {
      return changeUserRole(data.id as string, role);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "User Role Changed! 🎉",
        description: "The user role has been successfully changed.",
      });
      queryClient.invalidateQueries({ queryKey: ["users-table"] }); // Refresh the table
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to change user role.",
      });
    },
  });

  const closeDeleteDialog = () => {
    setShowDeleteDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const handleDelete = async () => {
    deleteMutation.mutate(data.id as string);
    closeDeleteDialog();
  };

  const handleChangeStatus = async (value: string) => {
    statusChangeMutation.mutate(value);
  };

  const handleChangeRole = async (value: string) => {
    roleChangeMutation.mutate(value);
  };

  return (
    <>
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={closeDeleteDialog}
        deleteRecord={() => handleDelete()}
      />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="flex h-8 w-8 p-0 data-[state=open]:bg-muted"
          >
            <MoreHorizontal />
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>Status</DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              <DropdownMenuRadioGroup value={data.status}>
                {AccountStatuses.map((option) => (
                  <DropdownMenuRadioItem
                    key={option.value}
                    value={option.value}
                    onClick={() => handleChangeStatus(option.value)}
                  >
                    {option.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
          <DropdownMenuSeparator />
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>Role</DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              <DropdownMenuRadioGroup value={data.role}>
                {Roles.map((option) => (
                  <DropdownMenuRadioItem
                    key={option.value}
                    value={option.value}
                    onClick={() => handleChangeRole(option.value)}
                  >
                    {option.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
          <DropdownMenuSeparator />

          <DropdownMenuItem
            className="text-red-600"
            onSelect={() => {
              setShowDeleteDialog(true);
            }}
          >
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
