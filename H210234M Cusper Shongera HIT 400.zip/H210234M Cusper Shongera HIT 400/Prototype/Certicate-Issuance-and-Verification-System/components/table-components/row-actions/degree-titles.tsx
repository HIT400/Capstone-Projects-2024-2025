"use client";

import { Row } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { DegreeTitleSchema } from "@/lib/validation";
import FormDialog from "@/components/dialog/forms-dialog";
import DeleteDialog from "@/components/dialog/delete-dialog";
import DegreeTitleForm from "@/components/forms/degree-title-form";
import { deleteDegreeTitle } from "@/app/lib/actions/degree-titles";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface DegreeTitlesDataTableRowActionsProps<TData> {
  row: Row<TData>;
}

export function DegreeTitlesDataTableRowActions<TData>({
  row,
}: DegreeTitlesDataTableRowActionsProps<TData>) {
  const [showFormDialog, setShowFormDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const data = DegreeTitleSchema.parse(row.original);

  const deleteMutation = useMutation({
    mutationFn: (id: string) => {
      return deleteDegreeTitle(id);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Degree Title Deleted 🎉",
        description: "The degree title has been successfully deleted.",
      });
      queryClient.invalidateQueries({
        queryKey: ["degree-titles-table"],
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to delete degree title.",
      });
    },
  });

  const closeFormDialog = () => {
    setShowFormDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const closeDeleteDialog = () => {
    setShowDeleteDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const handleDelete = async () => {
    deleteMutation.mutate(data.id as string);
    closeDeleteDialog();
  };

  return (
    <>
      <FormDialog
        isOpen={showFormDialog}
        onClose={closeFormDialog}
        title="Edit Degree Title"
      >
        <DegreeTitleForm defaultValues={data} onClose={closeFormDialog} />
      </FormDialog>
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={closeDeleteDialog}
        deleteRecord={() => handleDelete()}
      />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="flex h-8 w-8 p-0 data-[state=open]:bg-muted"
          >
            <MoreHorizontal />
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuItem
            onClick={() => {
              setShowFormDialog(true);
            }}
          >
            Edit
          </DropdownMenuItem>

          <DropdownMenuItem
            className="text-red-600"
            onSelect={() => {
              setShowDeleteDialog(true);
            }}
          >
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
