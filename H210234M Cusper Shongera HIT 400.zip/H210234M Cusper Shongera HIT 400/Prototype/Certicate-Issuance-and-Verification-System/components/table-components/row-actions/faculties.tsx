"use client";

import { Row } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FacultySchema } from "@/lib/validation";
import FormDialog from "@/components/dialog/forms-dialog";
import { useState } from "react";
import DeleteDialog from "@/components/dialog/delete-dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteFaculty } from "@/app/lib/actions/faculties";
import FacultyForm from "@/components/forms/faculty-form";

interface FacultiesDataTableRowActionsProps<TData> {
  row: Row<TData>;
}

export function FacultiesDataTableRowActions<TData>({
  row,
}: FacultiesDataTableRowActionsProps<TData>) {
  const [showFormDialog, setShowFormDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const data = FacultySchema.parse(row.original);

  const deleteMutation = useMutation({
    mutationFn: (id: string) => {
      return deleteFaculty(id);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Faculty Deleted 🎉",
        description: "The faculty has been successfully deleted.",
      });
      queryClient.invalidateQueries({
        queryKey: ["faculties-table"],
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to delete faculty.",
      });
    },
  });

  const closeFormDialog = () => {
    setShowFormDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const closeDeleteDialog = () => {
    setShowDeleteDialog(false);
    setTimeout(() => {
      const body = document.querySelector("body");
      if (body) {
        body.style.pointerEvents = "auto";
      }
    }, 500);
  };

  const handleDelete = async () => {
    deleteMutation.mutate(data.id as string);
    closeDeleteDialog();
  };

  return (
    <>
      <FormDialog
        isOpen={showFormDialog}
        onClose={closeFormDialog}
        title="Edit Faculty"
      >
        <FacultyForm defaultValues={data} onClose={closeFormDialog} />
      </FormDialog>
      <DeleteDialog
        isOpen={showDeleteDialog}
        onClose={closeDeleteDialog}
        deleteRecord={() => handleDelete()}
      />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="flex h-8 w-8 p-0 data-[state=open]:bg-muted"
          >
            <MoreHorizontal />
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuItem
            onClick={() => {
              setShowFormDialog(true);
            }}
          >
            Edit
          </DropdownMenuItem>

          <DropdownMenuItem
            className="text-red-600"
            onSelect={() => {
              setShowDeleteDialog(true);
            }}
          >
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
