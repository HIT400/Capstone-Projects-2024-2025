"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Checkbox } from "@/components/ui/checkbox";
import { UserWithName } from "@/lib/validation";
import { DataTableColumnHeader } from "../../data-table-column-header";
import { AccountStatuses, Roles } from "@/lib/constants";
import { UsersDataTableRowActions } from "../row-actions/user";

export const UsersColumns: ColumnDef<UserWithName>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
        className="translate-y-[2px]"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
        className="translate-y-[2px]"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "walletAddress",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Wallet" />
    ),
    cell: ({ row }) => (
      <div className="w-[80px] truncate">{row.getValue("walletAddress")}</div>
    ),
  },
  {
    accessorKey: "institutionId",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Institution Id" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("institutionId")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "institutionName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Institution Name" />
    ),
    cell: ({ row }) => (
      <div className="max-w-[500px] truncate">
        {row.getValue("institutionName")}
      </div>
    ),
  },
  {
    accessorKey: "role",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Role" />
    ),
    cell: ({ row }) => {
      const role = Roles.find((i) => i.value === row.getValue("role"));
      if (!role) {
        console.log(row.getValue("role"));
        return null;
      }
      return (
        <div className="flex items-center">
          {role.icon && (
            <role.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="">{role.label}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = AccountStatuses.find(
        (i) => i.value === row.getValue("status")
      );
      if (!status) {
        console.log(row.getValue("status"));
        return null;
      }
      return (
        <div className="flex items-center">
          {status.icon && (
            <status.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="">{row.getValue("status")}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => <UsersDataTableRowActions row={row} />,
  },
];
