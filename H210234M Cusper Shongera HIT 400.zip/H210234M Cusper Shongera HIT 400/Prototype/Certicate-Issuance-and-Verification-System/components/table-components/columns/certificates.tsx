"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Checkbox } from "@/components/ui/checkbox";
import { Certificate } from "@/lib/validation";
import { DataTableColumnHeader } from "../../data-table-column-header";
import { CertificateStatuses } from "@/lib/constants";
import { CertificatesDataTableRowActions } from "../row-actions/certificates";
import { format } from "date-fns";

export const certificatesColumns: ColumnDef<Certificate>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
        className="translate-y-[2px]"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
        className="translate-y-[2px]"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "studentId",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Student ID" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        {" "}
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("studentId")}
        </span>
      </div>
    ),
    enableHiding: false,
  },
  {
    accessorKey: "studentFullName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Name" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("studentFullName")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "faculty",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Faculty" />
    ),
    cell: ({ row }) => (
      <div className="max-w-[160px] truncate">{row.getValue("faculty")}</div>
    ),
  },
  {
    accessorKey: "degreeTitle",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Degree Title" />
    ),
    cell: ({ row }) => (
      <div className="max-w-[160px] truncate">
        {row.getValue("degreeTitle")}
      </div>
    ),
  },
  {
    accessorKey: "fieldOfStudy",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Field" />
    ),
    cell: ({ row }) => (
      <div className="max-w-[160px] truncate">
        {row.getValue("fieldOfStudy")}
      </div>
    ),
  },
  {
    accessorKey: "grade",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Grade" />
    ),
    cell: ({ row }) => (
      <div className="max-w-[140px] truncate">{row.getValue("grade")}</div>
    ),
  },
  {
    accessorKey: "dateOfAward",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Date of Award" />
    ),
    cell: ({ row }) => (
      <div className="w-[100px] truncate">
        {row.getValue("dateOfAward")
          ? format(new Date(row.getValue("dateOfAward")), "dd-MM-yyyy")
          : "N/A"}
      </div>
    ),
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const certificateStatus = CertificateStatuses.find(
        (i) => i.value === row.getValue("status")
      );
      if (!certificateStatus) {
        return null;
      }
      return (
        <div className="flex items-center">
          {certificateStatus.icon && (
            <certificateStatus.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="">{row.getValue("status")}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => <CertificatesDataTableRowActions row={row} />,
  },
];
