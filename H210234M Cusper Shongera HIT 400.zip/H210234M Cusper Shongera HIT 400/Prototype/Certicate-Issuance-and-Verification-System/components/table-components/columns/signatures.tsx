"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Checkbox } from "@/components/ui/checkbox";
import { Signature } from "@/lib/validation";
import { DataTableColumnHeader } from "../../data-table-column-header";
import Image from "next/image";
import { SignaturesDataTableRowActions } from "../row-actions/signatures";
import { Positions } from "@/lib/constants";

export const SignaturesColumns: ColumnDef<Signature>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
        className="translate-y-[2px]"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
        className="translate-y-[2px] "
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  // {
  //   accessorKey: "id",
  //   header: ({ column }) => (
  //     <DataTableColumnHeader column={column} title="ID" />
  //   ),
  //   cell: ({ row }) => (
  //     <div className="flex items-center space-x-2 h-8">
  //       <span className="max-w-[500px] truncate font-medium">
  //         {row.getValue("id")}
  //       </span>
  //     </div>
  //   ),
  // },
  {
    accessorKey: "fullName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Name" />
    ),
    cell: ({ row }) => (
      <div className="flex items-center space-x-2 h-8">
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("fullName")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "position",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Position" />
    ),
    cell: ({ row }) => {
      const position = Positions.find(
        (i) => i.value === row.getValue("position")
      );
      if (!position) {
        console.log(row.getValue("position"));
        return null;
      }
      return (
        <div className="flex items-center">
          {position.icon && (
            <position.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="">{position.label}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: "signatureImage",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Image" />
    ),
    cell: ({ row }) => {
      return (
        <div className="flex items-center">
          <Image
            src={row.getValue("signatureImage")}
            alt={row.getValue("fullName")}
            width={40}
            height={40}
            className="rounded-md"
          />
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => <SignaturesDataTableRowActions row={row} />,
  },
];
