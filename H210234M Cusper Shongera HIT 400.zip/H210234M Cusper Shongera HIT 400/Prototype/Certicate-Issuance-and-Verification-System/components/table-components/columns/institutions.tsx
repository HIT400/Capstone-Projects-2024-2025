"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Institution } from "@/lib/validation";
import { DataTableColumnHeader } from "../../data-table-column-header";
import { InstitutionsDataTableRowActions } from "../row-actions/institutions";
import { InstitutionTypes } from "@/lib/constants";

export const institutionsColumns: ColumnDef<Institution>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
        className="translate-y-[2px]"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
        className="translate-y-[2px]"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "walletAddress",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Wallet" />
    ),
    cell: ({ row }) => (
      <div className="w-[80px] truncate">{row.getValue("walletAddress")}</div>
    ),
  },
  {
    accessorKey: "institutionName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Institution Name" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        <Badge variant="outline">{row.original.abbreviation}</Badge>
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("institutionName")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "registrationNumber",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Reg Number" />
    ),
    cell: ({ row }) => (
      <div className="w-[80px] truncate">
        {row.getValue("registrationNumber")}
      </div>
    ),
  },
  {
    accessorKey: "phone",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Phone Number" />
    ),
    cell: ({ row }) => (
      <div className="w-[120px] truncate">{row.getValue("phone")}</div>
    ),
  },
  {
    accessorKey: "email",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Email" />
    ),
    cell: ({ row }) => (
      <div className="w-[120px] truncate">{row.getValue("email")}</div>
    ),
  },
  {
    accessorKey: "physicalAddress",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Location" />
    ),
    cell: ({ row }) => (
      <div className="w-[120px] truncate">
        {row.getValue("physicalAddress")}
      </div>
    ),
  },
  {
    accessorKey: "institutionType",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Inst. Type" />
    ),
    cell: ({ row }) => {
      const institutionType = InstitutionTypes.find(
        (i) => i.value === row.getValue("institutionType")
      );
      if (!institutionType) {
        console.log(row.getValue("institutionType"));
        return null;
      }
      return (
        <div className="flex items-center">
          {institutionType.icon && (
            <institutionType.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="">{row.getValue("institutionType")}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => <InstitutionsDataTableRowActions row={row} />,
  },
];
