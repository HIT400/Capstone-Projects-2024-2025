"use client";

import { ColumnDef } from "@tanstack/react-table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Checkbox } from "@/components/ui/checkbox";
import { Flag } from "@/lib/validation";
import { DataTableColumnHeader } from "../../data-table-column-header";
import { ValidityStatuses } from "@/lib/constants";
import Link from "next/link";
import { BookmarkCheck, Dot, Link2 } from "lucide-react";
import { FlagsDataTableRowActions } from "../row-actions/flags";

export const FlagsColumns: ColumnDef<Flag>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
        className="translate-y-[2px]"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
        className="translate-y-[2px]"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "institution",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Institution" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("institution")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "certificate",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Certificate" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        {row.getValue("certificate") ? (
          <Link
            href={`/certificate/${row.getValue("certificate")}`}
            className="w-[160px] truncate font-medium hover:underline underline-offset-2 tabular-nums group"
          >
            <Link2 className="mr-1 h-4 w-4  hidden group-hover:inline transition-opacity" />
            {row.getValue("certificate")}
          </Link>
        ) : (
          <span className="max-w-[150px] truncate font-medium">-</span>
        )}
      </div>
    ),
  },
  {
    accessorKey: "reason",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Reason" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2">
        <span className="max-w-[500px] truncate font-medium">
          {row.getValue("reason")}
        </span>
      </div>
    ),
  },
  {
    accessorKey: "description",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Description" />
    ),
    cell: ({ row }) => (
      <div className="flex space-x-2 max-w-sm">
        <TooltipProvider>
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <span className="max-w-[150px] truncate font-medium">
                {row.getValue("description")}
              </span>
            </TooltipTrigger>
            <TooltipContent className="max-w-[300px]">
              <p>{row.getValue("description")}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    ),
  },
  {
    accessorKey: "validity",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Validity" />
    ),
    cell: ({ row }) => {
      const validity = ValidityStatuses.find(
        (i) => i.value === row.getValue("validity")
      );
      if (!validity) {
        console.log(row.getValue("validity"));
        return null;
      }
      return (
        <div className="flex items-center">
          {validity.icon && (
            <validity.icon className="mr-2 h-4 w-4 text-muted-foreground" />
          )}
          <span className="text-muted-foreground capitalize">
            {row.getValue("validity")}
          </span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: "date",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Date" />
    ),
    cell: ({ row }) => {
      const date = new Date(row.getValue("date"));
      const formattedDate = `${String(date.getDate()).padStart(
        2,
        "0"
      )}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;

      const formattedTime = `${String(date.getHours()).padStart(
        2,
        "0"
      )}:${String(date.getMinutes()).padStart(2, "0")}`;

      return (
        <div className="flex flex-col space-y-1">
          <span className="max-w-[500px] truncate font-medium">
            {formattedDate}
          </span>
          <span className="max-w-[500px] truncate text-xs text-muted-foreground font-medium tracking-widest tabular-nums">
            {formattedTime}
          </span>
        </div>
      );
    },
  },
  {
    accessorKey: "read",
    header: ({ column }) => <DataTableColumnHeader column={column} title="" />,
    cell: ({ row }) => (
      <div className="w-fit flex items-center justify-center">
        {row.getValue("read") === "unread" && (
          <Dot className="text-green-500 size-10" />
        )}
      </div>
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "saved",
    header: ({ column }) => <DataTableColumnHeader column={column} title="" />,
    cell: ({ row }) => (
      <div className="w-fit flex items-center justify-center">
        {row.getValue("saved") === "saved" && (
          <BookmarkCheck className="text-muted-foreground size-4" />
        )}
      </div>
    ),
    enableSorting: false,
    enableHiding: false,
  },
    {
      id: "actions",
      cell: ({ row }) => <FlagsDataTableRowActions row={row} />,
    },
];
