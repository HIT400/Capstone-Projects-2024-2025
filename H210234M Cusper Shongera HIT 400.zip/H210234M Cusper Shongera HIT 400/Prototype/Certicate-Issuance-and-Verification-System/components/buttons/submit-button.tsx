"use client";

import { Button } from "../ui/button";
import { LoaderCircle } from "lucide-react";

interface SubmitButtonProps {
  isLoading: boolean;
  loadingLabel?: string;
  className?: string;
  disabled?: boolean;
  children: React.ReactNode;
}

const SubmitButton = ({
  isLoading,
  loadingLabel,
  className,
  children,
  disabled,
}: SubmitButtonProps) => {
  return (
    <Button
      type="submit"
      disabled={isLoading || disabled}
      className={className}
    >
      {isLoading ? (
        <div className="flex items-center gap-4">
          <LoaderCircle className="sixe-4 animate-spin" />
          {loadingLabel ? loadingLabel : "Loading ..."}
        </div>
      ) : (
        children
      )}
    </Button>
  );
};

export default SubmitButton;
