"use client";

import React from "react";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { FlagSchema, Reason } from "@/lib/validation";
import CustomFormField from "../custom-form-field";
import { FormFieldType } from "@/lib/constants";
import { Form, FormControl } from "../ui/form";
import SubmitButton from "../buttons/submit-button";
import { Button } from "../ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"; // Import React Query
import { createFlag } from "@/app/lib/actions/flags";
import FileUploader from "../file-uploader";
import { fetchAllReasons } from "@/app/lib/actions/reasons";
import { SelectItem } from "../ui/select";

interface ReportValidCertificateFormProps
  extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  instituition: string;
  certificate: string;
  onClose?: () => void;
}

const ReportValidCertificateForm = ({
  className,
  instituition,
  certificate,
  onClose,
  ...props
}: ReportValidCertificateFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reasons } = useQuery({
    queryKey: ["reasons"],
    queryFn: fetchAllReasons,
  });

  const form = useForm<z.infer<typeof FlagSchema>>({
    resolver: zodResolver(FlagSchema),
    defaultValues: {
      id: "",
      institution: instituition,
      certificate: certificate,
      reason: "",
      description: "",
      image: "",
      read: "unread",
      saved: "unsaved",
      validity: "valid",
      date: new Date(),
    },
  });

  const createMutation = useMutation({
    mutationFn: createFlag,
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Flag Submitted 🎉",
        description: "The flag has been successfully submitted.",
      });
      queryClient.invalidateQueries({ queryKey: ["flags-table"] }); // Refresh the table

      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create flag.",
      });
    },
  });

  console.log(form.formState.errors);

  const onSubmit = (values: z.infer<typeof FlagSchema>) => {
    createMutation.mutate(values);
    console.log("Form submitted:", values);
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="reason"
              label="Reason"
              placeholder="Select Reason"
            >
              {reasons?.map((option: Reason) => (
                <SelectItem key={option.id} value={option.id as string}>
                  {option.label}
                </SelectItem>
              ))}
            </CustomFormField>
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="description"
              label="Please clearly describe the reason for flagging this certificate"
              placeholder="eg. Misrepresentation"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SKELETON}
              control={form.control}
              name="image"
              label="Upload Certificate Image"
              renderSkeleton={(field) => (
                <FormControl>
                  <FileUploader
                    files={field.value ? [field.value] : []}
                    onChange={(files) => {
                      field.onChange(files[0]);
                    }}
                  />
                </FormControl>
              )}
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            {onClose && (
              <Button
                type="button"
                variant="secondary"
                className="w-full"
                onClick={onClose}
              >
                Cancel
              </Button>
            )}
            <SubmitButton
              isLoading={createMutation.isPending}
              loadingLabel="Submitting..."
              className="w-full"
            >
              Submit Flag
            </SubmitButton>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default ReportValidCertificateForm;
