"use client";

import React, { useEffect } from "react";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import CustomFormField from "../custom-form-field";
import { FormFieldType } from "@/lib/constants";
import { Form, FormControl } from "../ui/form";
import SubmitButton from "../buttons/submit-button";
import { Button } from "../ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"; // Import React Query
import FileUploader from "../file-uploader";
import { TemplateSchema } from "@/lib/validation";
import { createTemplate, updateTemplate } from "@/app/lib/actions/templates";
import { getUserDetails } from "@/app/lib/actions/auth";

interface CertificateTemplateFormProps
  extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  defaultValues?: z.infer<typeof TemplateSchema>;
  onClose?: () => void;
}

const CertificateTemplateForm = ({
  className,
  onClose,
  defaultValues,
  ...props
}: CertificateTemplateFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: session } = useQuery({
    queryKey: ["ct-user-details"],
    queryFn: getUserDetails,
  });

  const form = useForm<z.infer<typeof TemplateSchema>>({
    resolver: zodResolver(TemplateSchema),
    defaultValues: defaultValues || {
      id: "",
      name: "",
      templateImage: "",
      institutionId: session?.institutionId || "",
    },
  });

  useEffect(() => {
    if (session?.institutionId) {
      form.reset({
        ...form.getValues(),
        institutionId: session.institutionId,
      });
    }
  }, [session, form]);

  const createMutation = useMutation({
    mutationFn: createTemplate,
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Certificate Template Created 🎉",
        description: "The template has been successfully created.",
      });
      queryClient.invalidateQueries({
        queryKey: ["certificate-templates-table"],
      }); // Refresh the table

      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create template.",
      });
    },
  });

  // Mutation for updating an institution
  const updateMutation = useMutation({
    mutationFn: (values: z.infer<typeof TemplateSchema>) => {
      const { id, ...rest } = values;
      return updateTemplate(id as string, rest);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Certificate Template Updated 🎉",
        description: "The template has been successfully updated.",
      });
      queryClient.invalidateQueries({
        queryKey: ["certificate-templates-table"],
      });
      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to update template.",
      });
    },
  });

  // Combined onSubmit handler
  const onSubmit = (values: z.infer<typeof TemplateSchema>) => {
    if (defaultValues) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="name"
              label="Name"
              placeholder="eg. main"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SKELETON}
              control={form.control}
              name="templateImage"
              label="Upload Template Image"
              renderSkeleton={(field) => (
                <FormControl>
                  <FileUploader
                    files={field.value ? [field.value] : []} // Pass the value as an array
                    onChange={(files) => {
                      field.onChange(files[0]); // Update the form field with the first file
                    }}
                  />
                </FormControl>
              )}
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            {onClose && (
              <Button
                type="button"
                variant="secondary"
                className="w-full"
                onClick={onClose}
              >
                Cancel
              </Button>
            )}
            <SubmitButton
              isLoading={createMutation.isPending || updateMutation.isPending}
              className="w-full"
            >
              {defaultValues
                ? "Update Certificate Template"
                : "Add Certificate Template"}
            </SubmitButton>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default CertificateTemplateForm;
