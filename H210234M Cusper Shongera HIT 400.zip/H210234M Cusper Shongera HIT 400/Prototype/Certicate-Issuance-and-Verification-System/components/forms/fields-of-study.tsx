"use client";

import React, { useEffect } from "react";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import CustomFormField from "../custom-form-field";
import { FormFieldType } from "@/lib/constants";
import { Form } from "../ui/form";
import SubmitButton from "../buttons/submit-button";
import { Button } from "../ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FieldsOfStudySchema } from "@/lib/validation";
import {
  createFieldOfStudy,
  updateFieldOfStudy,
} from "@/app/lib/actions/fields-of-study";
import { getUserDetails } from "@/app/lib/actions/auth";

interface FieldsOfStudyFormProps extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  defaultValues?: z.infer<typeof FieldsOfStudySchema>;
  onClose?: () => void;
}

const FieldsOfStudyForm = ({
  className,
  onClose,
  defaultValues,
  ...props
}: FieldsOfStudyFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: session } = useQuery({
    queryKey: ["fs-user-details"],
    queryFn: getUserDetails,
  });

  const form = useForm<z.infer<typeof FieldsOfStudySchema>>({
    resolver: zodResolver(FieldsOfStudySchema),
    defaultValues: defaultValues || {
      id: "",
      name: "",
      code: "",
      institutionId: session?.institutionId || "",
    },
  });

  useEffect(() => {
    if (session?.institutionId) {
      form.reset({
        ...form.getValues(),
        institutionId: session.institutionId,
      });
    }
  }, [session, form]);
  
  const createMutation = useMutation({
    mutationFn: createFieldOfStudy,
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Fields of Study Created 🎉",
        description: "The field of study has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ["fields-of-study-table"] }); // Refresh the table

      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create field of study.",
      });
    },
  });

  // Mutation for updating an institution
  const updateMutation = useMutation({
    mutationFn: (values: z.infer<typeof FieldsOfStudySchema>) => {
      const { id, ...rest } = values;
      return updateFieldOfStudy(id as string, rest);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Fields of Study Updated 🎉",
        description: "The field of study has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["faculties-table"] });
      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to update field of study.",
      });
    },
  });

  // Combined onSubmit handler
  const onSubmit = (values: z.infer<typeof FieldsOfStudySchema>) => {
    if (defaultValues) {
      updateMutation.mutate(values); // Update existing institution
    } else {
      createMutation.mutate(values); // Create new institution
    }
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="name"
              label="Field Of Study"
              placeholder="eg. Software Engineering"
            />
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="code"
              label="Code"
              placeholder="eg. ISE"
            />
          </div>
          <div className="hidden">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="institutionId"
              label="Institution"
              placeholder="eg. 53859824..."
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            {onClose && (
              <Button type="button" variant="secondary" className="w-full" onClick={onClose}>
                Cancel
              </Button>
            )}
            <SubmitButton
              isLoading={createMutation.isPending || updateMutation.isPending}
              className="w-full"
            >
              {defaultValues ? "Update Field of Study" : "Add Field of Study"}
            </SubmitButton>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default FieldsOfStudyForm;
