"use client";

import React, { useTransition } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ConnectButton, useActiveAccount } from "thirdweb/react";
import { generatePayload, signIn } from "@/app/lib/actions/auth";
import { signLoginPayload } from "thirdweb/auth";
import { LoaderCircle } from "lucide-react";
import { client } from "@/config/thirdweb";

const SignInForm = ({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) => {
  const account = useActiveAccount();
  const [isLoading, startProcess] = useTransition();
  const { toast } = useToast();

  const handleSignIn = () => {
    if (!account) {
      return toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description:
          "Please connect your wallet first and then attempting to sign in.",
      });
    }

    startProcess(async () => {
      const payload = await generatePayload({ address: account.address });

      console.log("payload", payload);

      const signatureResult = await signLoginPayload({
        payload: payload,
        account: account,
      });

      console.log("signatureResult", signatureResult);

      const response = await signIn(signatureResult);

      if (response) {
        toast({
          variant: "destructive",
          title: "Uh oh! Something went wrong.",
          description: response.error,
        });
      }
    });
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-xl">Sign In</CardTitle>
          <CardDescription>Connect your wallet to sign in</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="grid gap-6">
              <ConnectButton client={client} />
              <Button
                disabled={!account || isLoading}
                onClick={handleSignIn}
                className="w-full"
              >
                {isLoading ? (
                  <div className="flex items-center gap-4">
                    <LoaderCircle className="sixe-4 animate-spin" />
                    Signing In
                  </div>
                ) : (
                  <span>Sign In</span>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SignInForm;
