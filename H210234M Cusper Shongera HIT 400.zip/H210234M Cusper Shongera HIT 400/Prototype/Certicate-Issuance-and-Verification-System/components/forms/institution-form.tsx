"use client";

import React from "react";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { InstitutionSchema } from "@/lib/validation";
import CustomFormField from "../custom-form-field";
import { FormFieldType, InstitutionTypes } from "@/lib/constants";
import { Form, FormControl } from "../ui/form";
import { SelectItem } from "../ui/select";
import FileUploader from "../file-uploader";
import SubmitButton from "../buttons/submit-button";
import { Button } from "../ui/button";
import {
  createInstitution,
  updateInstitution
} from "@/app/lib/actions/institutions";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query"; // Import React Query

interface InstitutionFormProps extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  defaultValues?: z.infer<typeof InstitutionSchema>;
  onClose: () => void;
}

const InstitutionForm = ({
  className,
  onClose,
  defaultValues,
  ...props
}: InstitutionFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient(); // Initialize query client

  const form = useForm<z.infer<typeof InstitutionSchema>>({
    resolver: zodResolver(InstitutionSchema),
    defaultValues: defaultValues || {
      id: "",
      walletAddress: "",
      institutionName: "",
      email: "",
      phone: "",
      abbreviation: "",
      institutionType: "",
      registrationNumber: "",
      physicalAddress: "",
      logo: undefined,
    },
  });

  // Mutation for creating an institution
  const createMutation = useMutation({
    mutationFn: createInstitution,
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Institution Created 🎉",
        description: "The institution has been successfully registered.",
      });
      queryClient.invalidateQueries({ queryKey: ["institutions-table"] }); // Refresh the table
      onClose(); // Close the form after successful creation
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create institution.",
      });
    },
  });

  // Mutation for updating an institution
  const updateMutation = useMutation({
    mutationFn: (values: z.infer<typeof InstitutionSchema>) => {
      const { id, ...rest } = values;
      return updateInstitution(id as string, rest);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Institution Updated 🎉",
        description: "The institution has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["institutions-table"] }); // Refresh the table
      onClose(); // Close the form after successful update
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to update institution.",
      });
    },
  });

  // Combined onSubmit handler
  const onSubmit = (values: z.infer<typeof InstitutionSchema>) => {
    if (defaultValues) {
      updateMutation.mutate(values); // Update existing institution
    } else {
      createMutation.mutate(values); // Create new institution
    }
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="institutionName"
              label="Institution Name"
              placeholder="eg. University of Example"
            />

            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="walletAddress"
              label="Wallet Address"
              placeholder="eg. 0x53859824..."
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="abbreviation"
              label="Abbreviation"
              placeholder="eg. UE"
            />

            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="registrationNumber"
              label="Registration Number"
              placeholder="eg. INST-56798"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="institutionType"
              label="Institution Type"
              placeholder="Select Institution Type"
            >
              {InstitutionTypes.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </CustomFormField>

            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="physicalAddress"
              label="Physical Address"
              placeholder="eg. 1111 Area, City"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.PHONE_INPUT}
              control={form.control}
              name="phone"
              label=" Phone Number"
              placeholder="256256256"
            />

            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="email"
              label=" Email"
              placeholder="eg. example@example.com"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SKELETON}
              control={form.control}
              name="logo"
              label="Upload Logo"
              renderSkeleton={(field) => (
                <FormControl>
                  <FileUploader
                    files={field.value ? [field.value] : []} // Pass the value as an array
                    onChange={(files) => {
                      field.onChange(files[0]); // Update the form field with the first file
                    }}
                  />
                </FormControl>
              )}
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <Button type="button" variant="secondary" className="w-full" onClick={onClose}>
              Cancel
            </Button>
            <SubmitButton
              isLoading={createMutation.isPending || updateMutation.isPending}
              className="w-full"
            >
              {defaultValues ? "Update Institution" : "Register Institution"}
            </SubmitButton>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default InstitutionForm;
