"use client";

import { ethers } from "ethers";
import React, { useEffect, useState } from "react";
import { cn, transformSignaturesToOptions } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import CustomFormField from "../custom-form-field";
import QRCode from "qrcode";
import { Form, FormControl } from "../ui/form";
import { SelectItem } from "../ui/select";
import { Button } from "../ui/button";
import {
  Certificate,
  CertificateSchema,
  DegreeTitle,
  Faculty,
  Signature,
} from "@/lib/validation";
import { CertificateStatuses, FormFieldType, Grades } from "@/lib/constants";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createCertificate,
  updateCertificate,
} from "@/app/lib/actions/certificates";
import { getUserDetails } from "@/app/lib/actions/auth";
import { fetchCurrentUserDegreeTitles } from "@/app/lib/actions/degree-titles";
import { fetchCurrentUserFieldsOfStudy } from "@/app/lib/actions/fields-of-study";
import { fetchCurrentUserFaculties } from "@/app/lib/actions/faculties";
import { fetchCurrentUserSignatures } from "@/app/lib/actions/signatures";
import { useToast } from "@/hooks/use-toast";
import { MultiSelect } from "../multi-select";
import { TransactionButton, useActiveAccount } from "thirdweb/react";
import { hashMessage } from "thirdweb/utils";
import { prepareContractCall, PreparedTransaction } from "thirdweb";
import { certificateFactoryContract } from "@/config/thirdweb";

interface CertificateFormProps extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  defaultValues?: Certificate;
  onClose?: () => void;
}

const CertificateForm = ({
  className,
  onClose,
  defaultValues,
  ...props
}: CertificateFormProps) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const account = useActiveAccount();
  const [isloading, setIsloading] = useState(false);

  const { data: session } = useQuery({
    queryKey: ["cert-user-details"],
    queryFn: getUserDetails,
  });

  const { data: degreeTitles } = useQuery({
    queryKey: ["degreeTitles"],
    queryFn: fetchCurrentUserDegreeTitles,
  });

  const { data: fieldsOfStudy } = useQuery({
    queryKey: ["fieldsOfStudy"],
    queryFn: fetchCurrentUserFieldsOfStudy,
  });

  const { data: faculties } = useQuery({
    queryKey: ["faculties"],
    queryFn: fetchCurrentUserFaculties,
  });

  const { data: signatures } = useQuery({
    queryKey: ["signatures"],
    queryFn: fetchCurrentUserSignatures,
  });

  const form = useForm<z.infer<typeof CertificateSchema>>({
    resolver: zodResolver(CertificateSchema),
    defaultValues: defaultValues || {
      id: "",
      institutionId: session?.institutionId ?? "",
      studentId: "",
      studentFullName: "",
      faculty: "",
      degreeTitle: "",
      fieldOfStudy: "",
      grade: "",
      dateOfAward: undefined,
      year: 0,
      signatures: [],
      status: "Valid",
      hash: "",
      digitalSignature: "",
      address: "",
      qrcode: "",
    },
  });

  useEffect(() => {
    if (session?.institutionId) {
      form.reset({
        ...form.getValues(),
        institutionId: session.institutionId,
      });
    }
  }, [session, form]);

  const createMutation = useMutation({
    mutationFn: (certificate: Certificate) => {
      return createCertificate(certificate);
    },
    onSuccess: async () => {
      toast({
        variant: "success",
        title: "Certificate Created 🎉",
        description: "The certificate has been successfully registered.",
      });
      queryClient.invalidateQueries({ queryKey: ["certificates-table"] });
      setIsloading(false);
      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      setIsloading(false);
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create certificate.",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (values: z.infer<typeof CertificateSchema>) => {
      const { id, ...rest } = values;
      return updateCertificate(id as string, rest);
    },
    onSuccess: (record) => {
      console.log(record);
      toast({
        variant: "success",
        title: "Certificate Updated 🎉",
        description: "The certificate has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["certificates-table"] });
      setIsloading(false);
      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      setIsloading(false);
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to update certificate.",
      });
    },
  });

  const onSubmit = async (
    values: z.infer<typeof CertificateSchema>
  ): Promise<PreparedTransaction<any>> => {
    setIsloading(true);
    const {
      id,
      status,
      hash,
      qrcode,
      address,
      year,
      digitalSignature,
      ...valuesWithoutStatus
    } = values;
    console.log(valuesWithoutStatus);
    const message = JSON.stringify(valuesWithoutStatus);
    console.log(message);
    const hashedMessage = hashMessage(message, "hex");

    if (!account) {
      toast({
        variant: "destructive",
        title: "Uh oh! Wallet Not Found.",
        description: "Please connect your wallet to proceed and try again.",
      });
      setIsloading(false);
      throw new Error("Wallet not connected"); // Throwing an error to prevent further execution
    }

    const signature = await account.signMessage({ message: hashedMessage });

    form.setValue("year", new Date(values.dateOfAward).getFullYear());
    form.setValue("hash", hashedMessage);
    form.setValue("digitalSignature", signature);

    if (defaultValues && defaultValues.address) {
      console.log(defaultValues.address);
      return prepareContractCall({
        contract: certificateFactoryContract,
        method:
          "function updateCertificate(address _certificateAddress, string _newHash, string _newDigitalSignature, string _newStatus)",
        params: [defaultValues.address, hashedMessage, signature, status],
      });
    }

    return prepareContractCall({
      contract: certificateFactoryContract,
      method:
        "function createCertificate(string _institutionWalletAddress, string _hash, string _digitalSignature, string _status) returns (address)",
      params: [account.address, hashedMessage, signature, status],
    });
  };

  const manageCertificate = async (
    receipt: any,
    values: z.infer<typeof CertificateSchema>
  ) => {
    if (defaultValues) {
      updateMutation.mutate(values);
    } else {
      const certificateAddress = ethers.getAddress(
        "0x" + receipt.logs[0].topics[1].slice(26)
      );

      const url = `${process.env.NEXT_PUBLIC_APP_DOMAIN}/verification/${certificateAddress}`;

      QRCode.toDataURL(url)
        .then((dataUrl: string) => {
          const certificate = {
            ...values,
            qrcode: dataUrl,
            address: certificateAddress,
          };
          createMutation.mutate(certificate);
        })
        .catch(() => {
          toast({
            variant: "destructive",
            title: "Uh oh! Something went wrong.",
            description: "Failed to generate Quick Response Code",
          });
        });
    }
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="studentFullName"
              label="Student Name"
              placeholder="eg. University of Example"
            />

            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="studentId"
              label="Student ID"
              placeholder="eg. H210234M"
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="faculty"
              label="Faculty"
              placeholder="Select Faculty"
            >
              {faculties?.map((option: Faculty) => (
                <SelectItem key={option.id} value={option.id as string}>
                  {option.name}
                </SelectItem>
              ))}
            </CustomFormField>

            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="degreeTitle"
              label="Degree Title"
              placeholder="Select Degree Title"
            >
              {degreeTitles?.map((option: DegreeTitle) => (
                <SelectItem key={option.id} value={option.id as string}>
                  {option.name}
                </SelectItem>
              ))}
            </CustomFormField>
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="fieldOfStudy"
              label="Field of Study"
              placeholder="Select Field of Study"
            >
              {fieldsOfStudy?.map((option) => (
                <SelectItem key={option.id} value={option.id as string}>
                  {option.name}
                </SelectItem>
              ))}
            </CustomFormField>

            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="grade"
              label="Grade"
              placeholder="eg. Distinction"
            >
              {Grades.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </CustomFormField>
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.DATEPICKER}
              control={form.control}
              name="dateOfAward"
              label="Date of Award"
              placeholder="Pick a Date"
              dateFormat={"dd-MM-yyyy"}
            />
            <CustomFormField
              fieldType={FormFieldType.SELECT}
              control={form.control}
              name="status"
              label="Status"
              placeholder="Select Status"
              disabled={!defaultValues}
            >
              {CertificateStatuses.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </CustomFormField>
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.SKELETON}
              control={form.control}
              name="signatures"
              label="Signatures"
              renderSkeleton={(field) => (
                <FormControl>
                  <MultiSelect
                    options={transformSignaturesToOptions(
                      signatures ? (signatures as Signature[]) : []
                    )}
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    placeholder="Select options"
                    variant="inverted"
                    animation={2}
                    maxCount={2}
                  />
                </FormControl>
              )}
            />
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            <div className="basis-1/2">
              {onClose && (
                <Button
                  type="button"
                  variant="secondary"
                  className="w-full"
                  disabled={isloading}
                  onClick={onClose}
                >
                  Cancel
                </Button>
              )}
            </div>
            <div className="basis-1/2">
              <TransactionButton
                disabled={isloading}
                className="transaction-button"
                type="button"
                transaction={async () => {
                  const transaction = await onSubmit(form.getValues());
                  return transaction;
                }}
                onError={() => {
                  toast({
                    variant: "destructive",
                    title: "Transaction Failed",
                    description:
                      "An error occurred while processing the transaction.",
                  });
                }}
                onTransactionConfirmed={async (receipt) => {
                  await manageCertificate(receipt, form.getValues());
                }}
              >
                {defaultValues ? "Update Certificate" : "Save Certificate"}
              </TransactionButton>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default CertificateForm;
