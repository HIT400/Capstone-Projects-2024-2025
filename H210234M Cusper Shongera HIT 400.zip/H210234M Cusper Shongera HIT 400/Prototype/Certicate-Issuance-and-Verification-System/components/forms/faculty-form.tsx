"use client";

import React, { useEffect } from "react";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { FacultySchema } from "@/lib/validation";
import CustomFormField from "../custom-form-field";
import { FormFieldType } from "@/lib/constants";
import { Form } from "../ui/form";
import SubmitButton from "../buttons/submit-button";
import { Button } from "../ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"; // Import React Query
import { createFaculty, updateFaculty } from "@/app/lib/actions/faculties";
import { getUserDetails } from "@/app/lib/actions/auth";

interface FacultyFormProps extends React.ComponentPropsWithoutRef<"div"> {
  className?: string;
  defaultValues?: z.infer<typeof FacultySchema>;
  onClose?: () => void;
}

const FacultyForm = ({
  className,
  onClose,
  defaultValues,
  ...props
}: FacultyFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: session } = useQuery({
    queryKey: ["fc-user-details"],
    queryFn: getUserDetails,
  });

  const form = useForm<z.infer<typeof FacultySchema>>({
    resolver: zodResolver(FacultySchema),
    defaultValues: defaultValues || {
      id: "",
      name: "",
      institutionId: session?.institutionId || "",
    },
  });

  useEffect(() => {
    if (session?.institutionId) {
      form.reset({
        ...form.getValues(),
        institutionId: session.institutionId,
      });
    }
  }, [session, form]);

  const createMutation = useMutation({
    mutationFn: createFaculty,
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Faculty Created 🎉",
        description: "The faculty has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ["faculties-table"] }); // Refresh the table

      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to create faculty.",
      });
    },
  });

  // Mutation for updating an institution
  const updateMutation = useMutation({
    mutationFn: (values: z.infer<typeof FacultySchema>) => {
      const { id, ...rest } = values;
      return updateFaculty(id as string, rest);
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Faculty Updated 🎉",
        description: "The faculty has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["faculties-table"] });
      if (onClose) {
        onClose();
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "Failed to update faculty.",
      });
    },
  });

  // Combined onSubmit handler
  const onSubmit = (values: z.infer<typeof FacultySchema>) => {
    if (defaultValues) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6 flex-1"
        >
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <CustomFormField
              fieldType={FormFieldType.INPUT}
              control={form.control}
              name="name"
              label="Faculty Name"
              placeholder="eg. Faculty of Arts"
            />
            <div className="hidden">
              <CustomFormField
                fieldType={FormFieldType.INPUT}
                control={form.control}
                name="institutionId"
                label="Institution"
                placeholder="eg. 53859824..."
              />
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6 w-full">
            {onClose && (
              <Button type="button" variant="secondary" className="w-full" onClick={onClose}>
                Cancel
              </Button>
            )}
            <SubmitButton
              isLoading={createMutation.isPending || updateMutation.isPending}
              className="w-full"
            >
              {defaultValues ? "Update Faculty" : "Add Faculty"}
            </SubmitButton>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default FacultyForm;
