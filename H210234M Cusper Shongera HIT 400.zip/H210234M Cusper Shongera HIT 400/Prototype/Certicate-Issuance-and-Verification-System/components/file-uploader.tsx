"use client";

import { convertFileToUrl } from "@/lib/utils";
import { UploadCloud } from "lucide-react";
import Image from "next/image";
import React, { useCallback } from "react";
import { useDropzone } from "react-dropzone";

type FileUploaderProps = {
  files: File[] | string | undefined;
  onChange: (files: File[]) => void;
};

const FileUploader = ({ files, onChange }: FileUploaderProps) => {
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      onChange(acceptedFiles);
    },
    [onChange]
  );

  const { getRootProps, getInputProps } = useDropzone({ onDrop });

  // Safely determine the file URL
  const fileUrl = typeof files === "string" 
    ? files 
    : Array.isArray(files) && files.length > 0 && files[0] instanceof File 
      ? convertFileToUrl(files[0]) 
      : null;

  return (
    <div {...getRootProps()} className="file-upload">
      <input {...getInputProps()} />
      {fileUrl ? (
        <div className="relative w-full h-40">
          <Image
            src={fileUrl}
            fill
            alt="Uploaded image"
            className="object-contain"
            onLoad={() => URL.revokeObjectURL(fileUrl)}
          />
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2 p-4">
          <UploadCloud className="size-8 text-primary" />
          <div className="text-center">
            <p className="text-sm font-medium">Drag & drop or click to upload</p>
            <p className="text-xs text-muted-foreground">
              High-quality image (max. 800x400px)
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUploader;