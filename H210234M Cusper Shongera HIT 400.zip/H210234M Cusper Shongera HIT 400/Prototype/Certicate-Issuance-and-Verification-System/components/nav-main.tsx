"use client"

import { type LucideIcon } from "lucide-react"

import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem
} from "@/components/ui/sidebar"
import { usePathname } from "next/navigation"

export function NavMain({
  sidebarMenuItems,
}: {
  sidebarMenuItems: {
    name: string
    url: string
    icon: LucideIcon
  }[]
}) {
    const path = usePathname();
    
  return (
    <SidebarGroup className="group-data-[collapsible=icon]:hidden">
      <SidebarGroupLabel>Menu</SidebarGroupLabel>
      <SidebarMenu>
        {sidebarMenuItems.map((item) => (
          <SidebarMenuItem key={item.name}>
            <SidebarMenuButton isActive={path === item.url} asChild>
              <a href={item.url}>
                <item.icon />
                <span>{item.name}</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </SidebarGroup>
  )
}
