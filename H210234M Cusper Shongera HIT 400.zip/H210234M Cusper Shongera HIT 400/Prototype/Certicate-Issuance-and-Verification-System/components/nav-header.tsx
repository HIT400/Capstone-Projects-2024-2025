"use client";

import React from "react";
import { ThemeToggle } from "./theme-toggle";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbSeparator,
  BreadcrumbItem,
  BreadcrumbPage,
  BreadcrumbLink,
} from "./ui/breadcrumb";
import { SidebarTrigger } from "./ui/sidebar";
import { usePathname } from "next/navigation";
import { Separator } from "./ui/separator";
import { ConnectButton } from "thirdweb/react";
import { client } from "@/config/thirdweb";

const NavHeader = () => {
  const paths = usePathname();
  const pathNames = paths.split("/").filter((path) => path);

  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-2">
      <div className="flex items-center gap-2 px-4">
        <SidebarTrigger className="-ml-1" />
        <Separator orientation="vertical" className="mr-2 h-4" />
        <Breadcrumb>
          <BreadcrumbList>
            {pathNames.map((link, index) => {
              const href = `/${pathNames.slice(0, index + 1).join("/")}`;
              const isLast = index === pathNames.length - 1;
              const isFirst = index === 0;
              const displayName =
                link[0].toUpperCase() + link.slice(1).replace(/-/g, " ");

              return (
                <React.Fragment key={index}>
                  <BreadcrumbItem>
                    {isLast ? (
                      <BreadcrumbPage>
                        {!isFirst ? displayName : "Home"}
                      </BreadcrumbPage>
                    ) : (
                      <BreadcrumbLink href={href}>
                        {!isFirst ? displayName : "Home"}
                      </BreadcrumbLink>
                    )}
                  </BreadcrumbItem>
                  {!isLast && <BreadcrumbSeparator />}
                </React.Fragment>
              );
            })}
          </BreadcrumbList>
        </Breadcrumb>
      </div>
      <div className="px-4 flex items-center gap-2">
        <ThemeToggle />
        <ConnectButton client={client} />
      </div>
    </header>
  );
};

export default NavHeader;
