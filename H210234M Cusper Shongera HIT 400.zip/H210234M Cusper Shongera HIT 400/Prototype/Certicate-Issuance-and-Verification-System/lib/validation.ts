import { z } from "zod";
import { AccountStatuses, CertificateStatuses, Roles } from "./constants";
import { isValidPhoneNumber } from "libphonenumber-js";

export const CertificateSchema = z.object({
  id: z.string().optional(),

  studentId: z.string().optional(),

  studentFullName: z.string().min(1, "Student full name is required"),

  institutionId: z.string().min(1, "Institution ID is required"),

  degreeTitle: z.string().min(1, "Degree title is required"),

  fieldOfStudy: z.string().min(1, "Field of study is required"),

  grade: z.string().min(1, "Grade is required"),

  signatures: z
    .array(z.string())
    .min(
      1,
      "2 and only signatures required ie. Registrar and either of the Chancellors"
    ),

  dateOfAward: z.union([z.date(), z.string()]),

  year: z.number(),

  faculty: z.string().min(1, "Faculty is required"),

  status: z.enum(
    CertificateStatuses.map((type) => type.value) as [string, ...string[]],
    {
      required_error: "Status is required",
    }
  ),
  hash: z.string().optional(),
  digitalSignature: z.string().optional(),
  qrcode: z.string().optional(),
  address: z.string().optional(),
});

export type Certificate = z.infer<typeof CertificateSchema>;

export const DegreeTitleSchema = z.object({
  id: z.string().optional(),

  code: z.string().min(1, "Code is required"),

  name: z.string().min(1, "Name is required"),

  institutionId: z.string().min(1, "Institution ID is required"),
});

export type DegreeTitle = z.infer<typeof DegreeTitleSchema>;

export const FacultySchema = z.object({
  id: z.string().optional(),

  name: z.string().min(1, "Name is required"),

  institutionId: z.string(),
});

export type Faculty = z.infer<typeof FacultySchema>;

export const FieldsOfStudySchema = z.object({
  id: z.string().optional(),

  code: z.string().min(1, "Code is required"),

  name: z.string().min(1, "Name is required"),

  institutionId: z.string().min(1, "Institution ID is required"),
});

export type FieldOfStudy = z.infer<typeof FieldsOfStudySchema>;

export const InstitutionSchema = z.object({
  id: z.string().optional(),
  walletAddress: z.string().min(1, "Wallet address is required"),
  institutionName: z.string().min(1, "Institution name is required"),
  email: z.string().email("Invalid email format"),
  phone: z
    .string()
    .refine(
      isValidPhoneNumber,
      "Please specify a valid phone number (include the international prefix)."
    ),
  abbreviation: z.string().optional(),
  institutionType: z.string().min(1, "Institution type is required"),
  registrationNumber: z.string(),
  physicalAddress: z.string().min(1, "Physical address is required"),
  logo: z.union([
    z
      .instanceof(File)
      .refine(
        (file) =>
          [
            "image/png",
            "image/jpeg",
            "image/jpg",
            "image/svg+xml",
            "image/gif",
          ].includes(file.type),
        { message: "Invalid file format" }
      ),
    z.string().url("Invalid logo URL"),
  ]),
});

export type Institution = z.infer<typeof InstitutionSchema>;

export const SignatureSchema = z.object({
  id: z.string().optional(),
  position: z.string().min(1, "Position is required"),
  fullName: z.string().min(1, "Full name is required"),
  institutionId: z.string().min(1, "Institution ID is required"),
  signatureImage: z.union([
    z
      .instanceof(File)
      .refine(
        (file) =>
          [
            "image/png",
            "image/jpeg",
            "image/jpg",
            "image/svg+xml",
            "image/gif",
          ].includes(file.type),
        { message: "Invalid file format" }
      ),
    z.string().url("Invalid signature URL"),
  ]),
});

// TypeScript type based on schema
export type Signature = z.infer<typeof SignatureSchema>;

// Define Zod schema for Statement of Award validation
export const StatementOfAwardSchema = z.object({
  id: z.string().optional(),

  name: z.string().min(1, "Name is required"),

  statement: z.string().min(1, "Statement is required"),

  institutionId: z.string().min(1, "Institution ID is required"),
});

// TypeScript type based on schema
export type StatementOfAward = z.infer<typeof StatementOfAwardSchema>;

// Define Zod schema for template validation
export const TemplateSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  institutionId: z.string().min(1, "Institution ID is required"),
  templateImage: z.union([
    z
      .instanceof(File)
      .refine(
        (file) =>
          [
            "image/png",
            "image/jpeg",
            "image/jpg",
            "image/svg+xml",
            "image/gif",
          ].includes(file.type),
        { message: "Invalid file format" }
      ),
    z.string().url("Invalid logo URL"),
  ]),
});

// TypeScript type based on schema
export type Template = z.infer<typeof TemplateSchema>;

// Define Zod schema for user validation
export const UserSchema = z.object({
  id: z.string().optional(),

  walletAddress: z.string().min(1, "Wallet address is required"),

  role: z.enum(Roles.map((type) => type.value) as [string, ...string[]], {
    required_error: "Role is required",
  }),

  status: z.enum(
    AccountStatuses.map((type) => type.value) as [string, ...string[]],
    {
      required_error: "Status is required",
    }
  ),

  institutionId: z.string().min(1, "Institution ID is required"),
});

// TypeScript type based on schema
export type User = z.infer<typeof UserSchema>;

export const UserWithNameSchema = UserSchema.extend({
  institutionName: z.string().min(1, "InstitutionName is required"),
});

export type UserWithName = z.infer<typeof UserWithNameSchema>;

export const AuditTrailSchema = z.object({
  id: z.string().optional(),

  timestamp: z.string().min(1, "TimeStamp is required"),

  details: z.string().min(1, "Details is required"),

  action: z.string().min(1, "Action is required"),

  performedBy: z.string().min(1, "Institution ID is required"),
});

export type AuditTrail = z.infer<typeof AuditTrailSchema>;

export const AuditTrailWithNameSchema = AuditTrailSchema.extend({
  institutionName: z.string().min(1, "InstitutionName is required"),
});

export type AuditTrailWithName = z.infer<typeof AuditTrailWithNameSchema>;

export const CertificateDetailsSchema = CertificateSchema.omit({
  signatures: true,
}).extend({
  signatures: z
    .array(SignatureSchema)
    .min(2, "At least two signatures are required"), // Enforcing minimum of 2 signatures
  institutionName: z.string().min(1, "Institution name is required"),
  institutionLogo: z.union([
    z
      .instanceof(File)
      .refine(
        (file) =>
          [
            "image/png",
            "image/jpeg",
            "image/jpg",
            "image/svg+xml",
            "image/gif",
          ].includes(file.type),
        { message: "Invalid file format" }
      ),
    z.string().url("Invalid institution logo URL"),
  ]),
});

export type CertificateDetails = z.infer<typeof CertificateDetailsSchema>;

export const FlagSchema = z.object({
  id: z.string().optional(),
  institution: z.string().min(1, "Institution ID is required"),
  certificate: z.string().optional(),
  reason: z.string().min(1, "Reason ID is required"),
  description: z.string().min(1, "Description is required"),
  image: z.union([
    z
      .instanceof(File)
      .refine(
        (file) =>
          [
            "image/png",
            "image/jpeg",
            "image/jpg",
            "image/svg+xml",
            "image/gif",
          ].includes(file.type),
        { message: "Invalid file format" }
      ),
    z.string().url("Invalid institution logo URL"),
  ]),
  validity: z.enum(["valid", "invalid"], {
    message: "Validity must be 'valid' or 'invalid'",
  }),
  date: z.union([z.date(), z.string()]),
  read: z.union([
    z.enum(["read", "unread"], {
      message: "Validity must be 'valid' or 'invalid'",
    }),
    z.boolean(),
  ]),
  saved: z.union([
    z.enum(["saved", "unsaved"], {
      message: "Validity must be 'valid' or 'invalid'",
    }),
    z.boolean(),
  ]),
});

export type Flag = z.infer<typeof FlagSchema>;

export const ReasonSchema = z.object({
  id: z.string(),
  value: z.string(),
  label: z.string(),
});

export type Reason = z.infer<typeof ReasonSchema>;
