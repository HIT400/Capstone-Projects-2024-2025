import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { Signature } from "./validation";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const parseStringify = (value: string) =>
  JSON.parse(JSON.stringify(value));

export const convertFileToUrl = (file: File) => URL.createObjectURL(file);

type Option = {
  label: string;

  value: string;

  icon?: React.ComponentType<{ className?: string }>;
};

export function transformSignaturesToOptions(
  signatures: Signature[]
): Option[] {
  return signatures.map((signature) => ({
    label: signature.position, // Use fullName as the label

    value: signature.id!, // Use id or institutionId as the value
  }));
}

export const spaceOutWords = (str: string) => {
  return str
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (match) => match.toUpperCase())
    .trim();
};
