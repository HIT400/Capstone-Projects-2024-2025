// IMPORTS

import {
  AlertTriangle,
  Award,
  BadgeCheck,
  Building2,
  CheckCircle2,
  CircleCheck,
  CircleOff,
  FileCheck,
  FileWarning,
  FlagIcon,
  Globe,
  GraduationCap,
  Layers,
  LayoutDashboard,
  LucideIcon,
  Medal,
  Minus,
  Plus,
  School,
  Shield,
  Signature,
  Star,
  Timer,
  UserRound,
  UserRoundPen,
  Users,
  X,
  XCircle,
} from "lucide-react";
import { cn } from "./utils";

// APP METADATA

export const appName = "Certificate Issuance and Verification System";

export const appNameAbbreviation = "C I & V S";

export const appDescription = "A system for issuing and verifying certificates";

export const AppIcon = ({
  className,
}: React.ComponentPropsWithoutRef<"div">) => {
  return <Award className={cn(className)} />;
};

// OPTIONS

export const Roles = [
  {
    value: "admin",
    label: "Admin",
    icon: UserRoundPen,
  },
  {
    value: "user",
    label: "User",
    icon: UserRound,
  },
];
export const Positions = [
  {
    value: "chancellor",
    label: "Chancellor",
    icon: UserRoundPen,
  },
  {
    value: "vice chancellor",
    label: "Vice Chancellor",
    icon: UserRoundPen,
  },
  {
    value: "registrar",
    label: "Registrar",
    icon: UserRoundPen,
  },
];

export const InstitutionTypes = [
  {
    value: "State",
    label: "State",
    icon: School,
  },
  {
    value: "Private",
    label: "Private",
    icon: Shield,
  },
  {
    value: "Intergovernmental",
    label: "Intergovernmental",
    icon: Globe,
  },
  {
    value: "International",
    label: "International",
    icon: Globe,
  },
  {
    value: "Need Regularization but allowed to operate",
    label: "Need Regularization but allowed to operate",
    icon: AlertTriangle,
  },
  {
    value: "Non-Operating with Provisional Registration",
    label: "Non-Operating with Provisional Registration",
    icon: FileWarning,
  },
];

export const AccountStatuses = [
  {
    value: "Active",
    label: "Active",
    icon: BadgeCheck,
  },
  {
    value: "Suspended",
    label: "Suspended",
    icon: AlertTriangle,
  },
  {
    value: "Banned",
    label: "Banned",
    icon: CircleOff,
  },
];

export const CertificateStatuses = [
  {
    value: "Valid",
    label: "Valid",
    icon: BadgeCheck,
  },
  {
    value: "Held",
    label: "Held",
    icon: Timer,
  },
  {
    value: "Revoked",
    label: "Revoked",
    icon: CircleOff,
  },
];

export const Grades = [
  {
    value: "First Class",
    label: "First Class",
    icon: Award, // Represents top achievement
  },
  {
    value: "Upper Second Class",
    label: "Upper Second Class",
    icon: Star, // Represents high achievement
  },
  {
    value: "Lower Second Class",
    label: "Lower Second Class",
    icon: Medal, // Represents a moderate achievement
  },
  {
    value: "Third Class",
    label: "Third Class",
    icon: BadgeCheck, // Represents a pass, but not excellent
  },
];

export const AdminSidebarItems: MenuItems = [
  {
    name: "Dashboard",
    url: "/admin",
    icon: LayoutDashboard,
  },
  {
    name: "Users",
    url: "/admin/users",
    icon: Users,
  },
  {
    name: "Institutions",
    url: "/admin/institutions",
    icon: Building2,
  },
  {
    name: "Flags",
    url: "/admin/flags",
    icon: FlagIcon,
  },
  // {
  //   name: "Audit Trail",
  //   url: "/admin/audit-trail",
  //   icon: Logs,
  // },
];

export const ValidityStatuses = [
  {
    value: "valid",
    label: "Valid",
    icon: CheckCircle2,
  },
  {
    value: "invalid",
    label: "Invalid",
    icon: XCircle,
  },
];

export const InstitutionSidebarItems: MenuItems = [
  {
    name: "Dashboard",
    url: "/institution",
    icon: LayoutDashboard,
  },
  {
    name: "Certificates",
    url: "/institution/certificates",
    icon: FileCheck,
  },
  {
    name: "Faculties",
    url: "/institution/faculties",
    icon: School,
  },
  {
    name: "Degree Titles",
    url: "/institution/degree-titles",
    icon: GraduationCap,
  },
  {
    name: "Fields of Study",
    url: "/institution/fields-of-study",
    icon: Layers,
  },
  {
    name: "Flags",
    url: "/institution/flags",
    icon: FlagIcon,
  },
  {
    name: "Signatures",
    url: "/institution/signatures",
    icon: Signature,
  },
];

export const AuditTrailActions = [
  {
    value: "create_certificate",
    label: "Create Certificate",
    icon: Plus,
  },
  {
    value: "update_certificate",
    label: "Update Certificate",
    icon: Minus,
  },
  {
    value: "delete_certificate",
    label: "Delete Certificate",
    icon: X,
  },
  {
    value: "verify_certificate",
    label: "Verify Certificate",
    icon: CircleCheck,
  },
  {
    value: "create_template",
    label: "Create Template",
    icon: Plus,
  },
  {
    value: "update_template",
    label: "Update Template",
    icon: Minus,
  },
  {
    value: "delete_template",
    label: "Delete Template",
    icon: X,
  },
  {
    value: "create_program",
    label: "Create Program",
    icon: Plus,
  },
  {
    value: "update_program",
    label: "Update Program",
    icon: Minus,
  },
  {
    value: "delete_program",
    label: "Delete Program",
    icon: X,
  },
];

// TYPES

export type MenuItems = {
  name: string;
  url: string;
  icon: LucideIcon;
}[];

export type CurrentUser = {
  name: string;
  emailAddress: string;
  logo?: string;
  role: string;
};

// ENUMS

export enum FormFieldType {
  INPUT = "input",
  TEXTAREA = "textarea",
  PHONE_INPUT = "phone_input",
  CHECKBOX = "checkbox",
  DATEPICKER = "datepicker",
  SKELETON = "skeleton",
  SELECT = "select",
  PASSWORD = "password",
}
