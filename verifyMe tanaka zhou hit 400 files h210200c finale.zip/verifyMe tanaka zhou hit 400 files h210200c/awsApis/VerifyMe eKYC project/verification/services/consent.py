from algosdk import transaction, encoding
from django.conf import settings

class ConsentManager:
    def grant_consent(self, user, institution_address, permissions):
        sp = settings.ALGOD_CLIENT.suggested_params()
        args = [
            b"grant",
            encoding.decode_address(institution_address),
            permissions
        ]
        
        txn = transaction.ApplicationNoOpTxn(
            sender=user.algorand_address,
            sp=sp,
            index=settings.CONSENT_APP_ID,
            app_args=args
        )
        signed = txn.sign(user.get_private_key())
        return settings.ALGOD_CLIENT.send_transaction(signed)

    def check_consent(self, user_address, institution_address):
        account_info = settings.ALGOD_CLIENT.account_info(user_address)
        for app in account_info.get("apps-local-state", []):
            if app["id"] == settings.CONSENT_APP_ID:
                return any(
                    entry["key"] == encoding.decode_address(institution_address)
                    for entry in app.get("key-value", [])
                )
        return False