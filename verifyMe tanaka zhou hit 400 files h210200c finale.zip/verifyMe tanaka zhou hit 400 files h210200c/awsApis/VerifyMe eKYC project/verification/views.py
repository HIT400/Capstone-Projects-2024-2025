import boto3
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.shortcuts import render, get_object_or_404, redirect
from rest_framework.decorators import api_view
from django.urls import reverse, reverse_lazy
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from .forms import IDUploadForm
from django.conf import settings
import base64
import logging
from botocore.exceptions import ClientError
import uuid
from .models import CustomUser, UserProfile, Document, ProofOfResidence, VerificationLog, Institution, UserAccessPermission
from django.contrib.auth import get_user_model
import json
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import logout
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import CustomUserCreationForm
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils import timezone
from datetime import datetime, timedelta
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.contrib.auth.views import LoginView
from .forms import LoginForm
from django.contrib.auth.views import LoginView as BaseLoginView
from django.db.models import Count

# Define logger
logger = logging.getLogger(__name__)


from django.views.generic import FormView, TemplateView
from .forms import ConsentForm
# Ensure the correct path to ConsentManager is u  # Update the path if consent.py is in a different directory
from verification.services.consent import ConsentManager  # Update the path to reflect the correct location
from django.views.generic import ListView, CreateView
from .models import ConsentTransaction


# views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from datetime import datetime, timedelta
from .models import CustomUser, VerificationLog, UserAccessPermission, Institution, ConsentTransaction
from fuzzywuzzy import fuzz

@login_required
def admin_dashboard(request):
    if not (request.user.is_superuser or request.user.user_type == 'ADMIN'):
        return redirect('login')
    
    # User statistics
    total_users = CustomUser.objects.count()
    user_growth_rate = calculate_growth_rate(CustomUser.objects.filter(
        date_joined__month=datetime.now().month
    ).count(), CustomUser.objects.filter(
        date_joined__month=(datetime.now() - timedelta(days=30)).month
    ).count())
    
    # Verification statistics
    pending_verifications = CustomUser.objects.filter(verification_status='PENDING').count()
    verified_users = CustomUser.objects.filter(verification_status='COMPLETED').count()
    verified_percentage = round((verified_users / total_users) * 100) if total_users > 0 else 0
    
    # Institution statistics
    total_institutions = Institution.objects.count()
    institution_growth = calculate_growth_rate(
        Institution.objects.filter(created_at__month=datetime.now().month).count(),
        Institution.objects.filter(created_at__month=(datetime.now() - timedelta(days=30)).month).count()
    )
    
    # Recent verification logs
    recent_verifications = VerificationLog.objects.order_by('-performed_at')[:5]
    
    # Verification stats for chart
    verification_stats = [
        {'label': 'Pending', 'count': pending_verifications, 'icon': 'watch-time', 'color': 'warning'},
        {'label': 'In Progress', 'count': CustomUser.objects.filter(verification_status='IN_PROGRESS').count(), 'icon': 'progress', 'color': 'info'},
        {'label': 'Completed', 'count': verified_users, 'icon': 'check-bold', 'color': 'success'},
        {'label': 'Failed', 'count': CustomUser.objects.filter(verification_status='FAILED').count(), 'icon': 'fat-remove', 'color': 'danger'},
    ]
    
    # Calculate percentages
    for stat in verification_stats:
        stat['percentage'] = round((stat['count'] / total_users) * 100) if total_users > 0 else 0
    
    # User growth data for chart
    user_growth_data = []
    user_growth_labels = []
    for i in range(6, -1, -1):
        date = datetime.now() - timedelta(days=i)
        user_growth_labels.append(date.strftime("%b %d"))
        user_growth_data.append(CustomUser.objects.filter(
            date_joined__date__lte=date
        ).count())
    
    context = {
        'total_users': total_users,
        'user_growth_rate': user_growth_rate,
        'pending_verifications': pending_verifications,
        'verified_users': verified_users,
        'verified_percentage': verified_percentage,
        'total_institutions': total_institutions,
        'institution_growth': institution_growth,
        'recent_verifications': recent_verifications,
        'verification_stats': verification_stats,
        'user_growth_labels': user_growth_labels,
        'user_growth_data': user_growth_data,
        'verification_data': [
            pending_verifications,
            CustomUser.objects.filter(verification_status='IN_PROGRESS').count(),
            verified_users,
            CustomUser.objects.filter(verification_status='FAILED').count()
        ],
        'verification_growth': calculate_growth_rate(
            VerificationLog.objects.filter(performed_at__month=datetime.now().month).count(),
            VerificationLog.objects.filter(performed_at__month=(datetime.now() - timedelta(days=30)).month).count()
        ),
        'completed_verifications': VerificationLog.objects.filter(
            result='SUCCESS',
            performed_at__month=datetime.now().month
        ).count(),
    }
    return render(request, 'pages/admin_dasboard.html', context)

@login_required
def institution_dashboard(request):
    if request.user.user_type != 'INSTITUTION':
        return redirect('login')
    
    # Get the institution
    institution = Institution.objects.filter(admin_users=request.user).first()
    if not institution:
        return redirect('login')
    
    # Access permissions
    access_permissions = UserAccessPermission.objects.filter(institution=institution).count()
    permission_growth = calculate_growth_rate(
        UserAccessPermission.objects.filter(
            institution=institution,
            granted_at__month=datetime.now().month
        ).count(),
        UserAccessPermission.objects.filter(
            institution=institution,
            granted_at__month=(datetime.now() - timedelta(days=30)).month
        ).count()
    )
    
    # Verification stats
    active_verifications = UserAccessPermission.objects.filter(
        institution=institution,
        is_active=True
    ).count()
    
    # Recent requests
    recent_requests = UserAccessPermission.objects.filter(
        institution=institution
    ).order_by('-granted_at')[:5]
    
    # Consent stats
    consent_stats = [
        {'label': 'Active', 'count': UserAccessPermission.objects.filter(
            institution=institution,
            is_active=True
        ).count(), 'icon': 'check-bold', 'color': 'success'},
        {'label': 'Expired', 'count': UserAccessPermission.objects.filter(
            institution=institution,
            is_active=False,
            expires_at__lt=datetime.now()
        ).count(), 'icon': 'calendar-grid-58', 'color': 'warning'},
        {'label': 'Revoked', 'count': UserAccessPermission.objects.filter(
            institution=institution,
            is_active=False,
            expires_at__isnull=True
        ).count(), 'icon': 'fat-remove', 'color': 'danger'},
    ]
    
    # Calculate percentages
    for stat in consent_stats:
        stat['percentage'] = round((stat['count'] / access_permissions) * 100) if access_permissions > 0 else 0
    
    # Access type distribution
    access_types = UserAccessPermission.objects.filter(
        institution=institution
    ).values('permission_level').annotate(count=Count('id'))
    
    access_type_labels = [x['permission_level'] for x in access_types]
    access_type_data = [x['count'] for x in access_types]
    
    # Consent history data
    consent_history_data = []
    consent_history_labels = []
    for i in range(6, -1, -1):
        date = datetime.now() - timedelta(days=i)
        consent_history_labels.append(date.strftime("%b %d"))
        consent_history_data.append(ConsentTransaction.objects.filter(
            institution=institution,
            timestamp__date=date
        ).count())
    
    context = {
        'institution': institution,
        'access_permissions': access_permissions,
        'permission_growth': permission_growth,
        'active_verifications': active_verifications,
        'pending_requests': UserAccessPermission.objects.filter(
            institution=institution,
            is_active=False
        ).count(),
        'verified_users': UserAccessPermission.objects.filter(
            institution=institution,
            user__verification_status='COMPLETED'
        ).count(),
        'verified_percentage': round((
            UserAccessPermission.objects.filter(
                institution=institution,
                user__verification_status='COMPLETED'
            ).count() / access_permissions
        ) * 100) if access_permissions > 0 else 0,
        'recent_requests': recent_requests,
        'consent_stats': consent_stats,
        'access_type_labels': access_type_labels,
        'access_type_data': access_type_data,
        'consent_history_labels': consent_history_labels,
        'consent_history_data': consent_history_data,
        'consent_growth': calculate_growth_rate(
            ConsentTransaction.objects.filter(
                institution=institution,
                timestamp__month=datetime.now().month
            ).count(),
            ConsentTransaction.objects.filter(
                institution=institution,
                timestamp__month=(datetime.now() - timedelta(days=30)).month
            ).count()
        ),
        'approved_requests': UserAccessPermission.objects.filter(
            institution=institution,
            granted_at__month=datetime.now().month
        ).count(),
        'verification_completion': round((
            UserAccessPermission.objects.filter(
                institution=institution,
                user__verification_status='COMPLETED'
            ).count() / access_permissions
        ) * 100) if access_permissions > 0 else 0,
        'request_growth': calculate_growth_rate(
            UserAccessPermission.objects.filter(
                institution=institution,
                granted_at__month=datetime.now().month
            ).count(),
            UserAccessPermission.objects.filter(
                institution=institution,
                granted_at__month=(datetime.now() - timedelta(days=30)).month
            ).count()
        ),
    }
    return render(request, 'pages/insit_dashborad.html', context)

def calculate_growth_rate(current, previous):
    if previous == 0:
        return 100 if current > 0 else 0
    return round(((current - previous) / previous) * 100)


class WalletView(TemplateView):
    template_name = 'forms/wallet.html'

class ConsentChainView(ListView):
    model = ConsentTransaction
    template_name = 'forms/consent_chain.html'
    ordering = ['-timestamp']
    context_object_name = 'transactions'

    def get_queryset(self):
        return ConsentTransaction.objects.filter(user=self.request.user)

class GrantConsentView(CreateView):
    model = ConsentTransaction
    template_name = 'forms/grant_consent.html'
    success_url = reverse_lazy('consent_chain')
    fields = ['institution']

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        form.fields['institution'].queryset = Institution.objects.all()
        return form

    def form_valid(self, form):
        # Get selected permissions from checkboxes
        permissions = self.request.POST.getlist('permissions')
        
        # Create the consent transaction
        form.instance.user = self.request.user
        form.instance.action = 'GRANT'
        form.instance.permissions = permissions
        
        # Handle previous hash for first transaction
        last_transaction = ConsentTransaction.objects.filter(user=self.request.user).last()
        form.instance.previous_hash = last_transaction.tx_hash if last_transaction else '0'*64  # Genesis block hash
        
        response = super().form_valid(form)
        
        # Create/update the access permission
        self.update_access_permissions(permissions)
        
        messages.success(self.request, 'Consent granted successfully!')
        return response

    def update_access_permissions(self, permissions):
        institution = self.object.institution
        UserAccessPermission.objects.update_or_create(
            user=self.request.user,
            institution=institution,
            defaults={
                'permission_level': 'CUSTOM' if 'CUSTOM' in permissions else 'BASIC',
                'can_view_personal_info': 'BASIC' in permissions or 'FULL' in permissions,
                'can_view_contact_info': 'FULL' in permissions,
                'can_view_id_documents': 'DOCUMENTS' in permissions or 'FULL' in permissions,
                'can_view_proof_of_residence': 'FULL' in permissions,
                'can_view_verification_status': 'BASIC' in permissions or 'FULL' in permissions,
                'is_active': True
            }
        )

@api_view(['POST'])
def analyze_id(request):
    try:
        if 'id_document' not in request.FILES:
            return Response({'status': 'error', 'message': 'No file provided'}, 
                          status=status.HTTP_400_BAD_REQUEST)

        # Process with Textract
        textract = boto3.client('textract', region_name='eu-west-2')
        image_bytes = request.FILES['id_document'].read()
        
        response = textract.analyze_id(DocumentPages=[{'Bytes': image_bytes}])
        
        # Extract and filter results
        results = {}
        confidence_scores = {}
        for doc in response.get('IdentityDocuments', []):
            for field in doc.get('IdentityDocumentFields', []):
                field_type = field.get('Type', {}).get('Text', 'Unknown').upper().replace(' ', '_')
                field_value = field.get('ValueDetection', {}).get('Text', '')
                confidence = field.get('ValueDetection', {}).get('Confidence', 0)
                if field_value:
                    results[field_type] = field_value
                    confidence_scores[field_type] = confidence

        def parse_date(date_str):
                    if not date_str:
                        return None
                    
                    # Try different date formats
                    formats = [
                        '%d/%m/%Y',    # 01/03/2025
                        '%d %b %Y',    # 12 Feb 2014
                        '%d %B %Y',    # 11 April 2014
                        '%d %b',       # 12 Feb (current year assumed)
                    ]
                    
                    for fmt in formats:
                        try:
                            parsed_date = datetime.strptime(date_str, fmt).date()
                            # For dates without year (like "12 Feb"), assume current year
                            if fmt == '%d %b' and parsed_date.year == 1900:
                                parsed_date = parsed_date.replace(year=datetime.now().year)
                            return parsed_date
                        except ValueError:
                            continue
                    
                    logger.warning(f"Failed to parse date: {date_str}")
                    return None

        user = request.user if request.user.is_authenticated else None
        user_first_name = user.first_name
        user_last_name = user.last_name
        
        doc_first_name= results.get('FIRST_NAME', '')
        doc_last_name = results.get('LAST_NAME', '')
        
        # Fuzzy matching with a threshold (e.g., 85% similarity)
        THRESHOLD = 85

        user_doc_match = (
            fuzz.ratio(user_first_name.lower(), doc_first_name.lower()) >= THRESHOLD if doc_first_name else False,
            fuzz.ratio(user_last_name.lower(), doc_last_name.lower()) >= THRESHOLD if doc_last_name else False
        )
        if user :
            print("Full name matches!")
            # Update or create ID document
            id_doc, created = Document.objects.update_or_create(
                user=user,
                document_type='ID_FRONT',
                defaults={
                    'file': request.FILES['id_document'],
                    'extracted_data': results,
                    'verified': True
                }
            )
            
            # Parse dates
            dob = parse_date(results.get('DATE_OF_BIRTH'))
            id_issue_date = parse_date(results.get('DATE_OF_ISSUE'))
            id_expiry_date = parse_date(results.get('EXPIRATION_DATE'))
            
            # Update or create user profile
            UserProfile.objects.update_or_create(
                user=user,
                defaults={
                    'first_name': results.get('FIRST_NAME', ''),
                    'middle_name': results.get('MIDDLE_NAME', ''),
                    'last_name': results.get('LAST_NAME', ''),
                    'date_of_birth': dob,
                    'place_of_birth': results.get('PLACE_OF_BIRTH', ''),
                    'address': results.get('ADDRESS', ''),
                    'id_type': results.get('ID_TYPE', 'NATIONAL_ID'),
                    'id_number': results.get('DOCUMENT_NUMBER', ''),
                    'id_issue_date': id_issue_date,
                    'id_expiry_date': id_expiry_date,
                    'id_issuing_authority': results.get('ISSUING_AUTHORITY', ''),
                }
            )
            
            VerificationLog.objects.create(
                user=user,
                verification_type='ID_VERIFICATION',
                result='SUCCESS' if results else 'FAILURE',
                details=response
            )
        print("ID verification results:", results)
        print("Confidence scores:", confidence_scores)
        return Response({
            'status': 'success',
            'data': results,
            'confidence_scores': confidence_scores
        })

    except Exception as e:
        if request.user.is_authenticated:
            VerificationLog.objects.create(
                user=request.user,
                verification_type='ID_VERIFICATION',
                result='ERROR',
                details={'error': str(e)}
            )
        return Response({'status': 'error', 'message': str(e)}, 
                      status=status.HTTP_400_BAD_REQUEST)
        
        
        
@api_view(['POST'])
def compare_faces(request):
    try:
        # Get uploaded files
        source_image = request.FILES['source_image']
        target_image = request.FILES['target_image']
        
        # Process with Rekognition
        rekognition = boto3.client('rekognition')
        response = rekognition.compare_faces(
            SourceImage={'Bytes': source_image.read()},
            TargetImage={'Bytes': target_image.read()},
            SimilarityThreshold=90.0
        )
        
        if response['FaceMatches']:
            result = {
                'match': True,
                'similarity': response['FaceMatches'][0]['Similarity'],
                'confidence': response['FaceMatches'][0]['Face']['Confidence']
            }
            
            # Save to database if user is authenticated
            user = request.user if request.user.is_authenticated else None
            if user:
                
                
                # Update user profile with face match results
                UserProfile.objects.update_or_create(
                    user=user,
                    defaults={
                        'face_match_verified': True,
                        'face_match_similarity': result['similarity'],
                        'face_match_verified_at': timezone.now()
                    }
                )
                
                # Log the verification
                VerificationLog.objects.create(
                    user=user,
                    verification_type='FACE_MATCH',
                    result='SUCCESS',
                    details=response
                )
        else:
            result = {'match': False}
            
            if request.user.is_authenticated:
                VerificationLog.objects.create(
                    user=request.user,
                    verification_type='FACE_MATCH',
                    result='FAILURE',
                    details=response
                )
            
        return Response({'status': 'success', 'data': result})
        
    except Exception as e:
        if request.user.is_authenticated:
            VerificationLog.objects.create(
                user=request.user,
                verification_type='FACE_MATCH',
                result='ERROR',
                details={'error': str(e)}
            )
        return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)


def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Manually set the backend before login
            user.backend = 'django.contrib.auth.backends.ModelBackend'
            
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('profile')  # Redirect to a profile page or dashboard
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'accounts/register.html', {'form': form})

class LoginView(BaseLoginView):
    template_name = 'accounts/login.html'
    form_class = LoginForm
    redirect_authenticated_user = True
    
    def form_valid(self, form):
        """Security check complete. Log the user in."""
        remember_me = form.cleaned_data.get('remember_me')
        
        if not remember_me:
            # Set session to expire when browser closes
            self.request.session.set_expiry(0)
        
        # Get the user from the form
        user = form.get_user()
        
        # Explicitly specify the backend to use
        user.backend = 'verification.auth_backends.IDNumberBackend'
        
        # Perform the login
        login(self.request, user)
        
        return super().form_valid(form)
    
    
def logout_view(request):
    logout(request)
    return redirect(reverse('login')) 


        
# The API view will handle the actual processing
# This view just renders the template     
def id_verification_view(request):
    if request.method == 'POST':
        form = IDUploadForm(request.POST, request.FILES)
        if form.is_valid():
            
            return render(request, 'forms/upload_id.html', {
                'form': form
            })
    else:
        form = IDUploadForm()
    
    return render(request, 'forms/upload_id.html', {
        'form': form
    })
    
    
    

@csrf_exempt
def create_liveness_session(request):
    try:
        client = boto3.client(
            'rekognition',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name='ap-northeast-1'
        )
        
        response = client.create_face_liveness_session(
            ClientRequestToken=f"session-{uuid.uuid4()}",
            Settings={
                "OutputConfig": {
                    "S3Bucket": "allsoafricatechbucket",
                    "S3KeyPrefix": "liveness-sessions/"
                },
                "AuditImagesLimit": 1 
            }
        )
        
        return JsonResponse({
            "SessionId": response["SessionId"],
            "status": "success"
        })
        
    except Exception as e:
        logger.error(f"Error creating session: {str(e)}")
        return JsonResponse({
            "status": "error",
            "message": str(e)
        }, status=500)

import logging
import boto3
import base64
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from PIL import Image
import io

logger = logging.getLogger(__name__)

def validate_image_bytes(image_bytes):
    """Validate image meets AWS requirements"""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        if img.width < 80 or img.height < 80:
            raise ValueError("Image dimensions too small (min 80x80 pixels)")
        return True
    except Exception as e:
        logger.error(f"Image validation failed: {str(e)}")
        raise

def get_rekognition_client():
    return boto3.client(
        'rekognition',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name = settings.AWS_REGION
    )

def get_textract_client():
    return boto3.client(
        'textract',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=settings.AWS_REGION
    )

def liveness_result_view(request):
    session_id = request.GET.get('session_id')
    if not session_id:
        logger.error("Missing session ID in liveness result request")
        return render(request, 'forms/error.html', {
            'error': 'Missing session ID'
        })
    
    try:
        logger.info(f"Processing liveness results for session: {session_id}")
        client = get_rekognition_client()
        
        response = client.get_face_liveness_session_results(SessionId=session_id)
        session_status = response.get('Status')
        
        if session_status != 'SUCCEEDED':
            logger.error(f"Liveness session not succeeded. Status: {session_status}")
            return render(request, 'forms/error.html', {
                'error': f'Liveness session {session_status.lower()}. Please retry.'
            })
        
        # Initialize reference image
        reference_image_bytes = None

        # Try to get reference image
        if 'ReferenceImage' in response and 'Bytes' in response['ReferenceImage']:
            reference_image_bytes = response['ReferenceImage']['Bytes']
        elif 'ReferenceImage' in response and 'S3Object' in response['ReferenceImage']:
            try:
                s3 = boto3.client('s3')
                s3_obj = response['ReferenceImage']['S3Object']
                s3_response = s3.get_object(Bucket=s3_obj['Bucket'], Key=s3_obj['Name'])
                reference_image_bytes = s3_response['Body'].read()
            except Exception as s3_error:
                logger.error(f"S3 fallback failed: {str(s3_error)}")

        if not reference_image_bytes and 'AuditImages' in response:
            for audit_image in response['AuditImages']:
                if 'Bytes' in audit_image:
                    reference_image_bytes = audit_image['Bytes']
                    break

        if not reference_image_bytes:
            logger.error("No reference image available in any form")
            return render(request, 'forms/error.html', {
                'error': 'Could not retrieve reference image. Please retry the liveness check.'
            })

        confidence = response.get('Confidence', 0)
        reference_image = base64.b64encode(reference_image_bytes).decode('utf-8')
        
        user = request.user if request.user.is_authenticated else None
        if user:
            # Update or create liveness document
            liveness_doc, created = Document.objects.update_or_create(
                user=user,
                document_type='LIVENESS',
                defaults={
                    'extracted_data': {
                        'confidence': confidence,
                        'session_id': session_id
                    },
                    'verified': True,
                    'file': reference_image
                }
            )
            
            UserProfile.objects.update_or_create(
                user=user,
                defaults={
                    'liveness_verified': True,
                    'liveness_confidence': confidence,
                    'liveness_verified_at': timezone.now()
                }
            )
            
            VerificationLog.objects.create(
                user=user,
                verification_type='LIVENESS_CHECK',
                result='SUCCESS',
                details={
                    'confidence': confidence,
                    'session_id': session_id
                }
            )
        
        return render(request, 'forms/result.html', {
            'session_id': session_id,
            'confidence': confidence,
            'status': 'SUCCEEDED',
            'reference_image': reference_image
        })
        
    except Exception as e:
        if request.user.is_authenticated:
            VerificationLog.objects.create(
                user=request.user,
                verification_type='LIVENESS_CHECK',
                result='ERROR',
                details={'error': str(e)}
            )
        logger.error(f"Liveness processing failed: {str(e)}", exc_info=True)
        return render(request, 'forms/error.html', {
            'error': 'Failed to process liveness results'
        })

@csrf_exempt
def process_id_verification(request):
    if request.method != 'POST':
        logger.warning("Invalid request method for ID verification")
        return JsonResponse({
            'status': 'error',
            'message': 'Invalid request method'
        }, status=405)
    
    try:
        logger.info("Starting ID verification process")
        
        # Get files and session data
        id_image = request.FILES.get('id_image')
        session_id = request.POST.get('session_id')
        
        if not id_image or not session_id:
            logger.error("Missing required parameters in ID verification")
            return JsonResponse({
                'status': 'error',
                'message': 'Missing ID image or session ID'
            }, status=400)
        
        # Validate ID image
        try:
            id_image_bytes = id_image.read()
            validate_image_bytes(id_image_bytes)
            logger.debug(f"ID image validated successfully. Size: {len(id_image_bytes)} bytes")
        except Exception as e:
            logger.error(f"ID image validation failed: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': f'Invalid ID image: {str(e)}'
            }, status=400)
        
        # Get reference image from liveness session
        try:
            rekognition = boto3.client(
                'rekognition',
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                region_name=settings.AWS_REGION
            )
            
            liveness_response = rekognition.get_face_liveness_session_results(
                SessionId=session_id
            )
            
            if liveness_response.get('Status') != 'SUCCEEDED':
                logger.error(f"Liveness session failed with status: {liveness_response.get('Status')}")
                return JsonResponse({
                    'status': 'error',
                    'message': f'Liveness session {liveness_response.get("Status").lower()}'
                }, status=400)

            # Get reference image
            reference_image = None
            if 'ReferenceImage' in liveness_response and 'Bytes' in liveness_response['ReferenceImage']:
                reference_image = liveness_response['ReferenceImage']['Bytes']
            elif 'ReferenceImage' in liveness_response and 'S3Object' in liveness_response['ReferenceImage']:
                try:
                    s3 = boto3.client('s3')
                    s3_obj = liveness_response['ReferenceImage']['S3Object']
                    s3_response = s3.get_object(
                        Bucket=s3_obj['Bucket'],
                        Key=s3_obj['Name']
                    )
                    reference_image = s3_response['Body'].read()
                except Exception as s3_error:
                    logger.warning(f"S3 fallback failed: {str(s3_error)}")

            if not reference_image and 'AuditImages' in liveness_response:
                for audit_img in liveness_response['AuditImages']:
                    if 'Bytes' in audit_img:
                        reference_image = audit_img['Bytes']
                        break

            if not reference_image:
                logger.error("No reference image available in any format")
                return JsonResponse({
                    'status': 'error',
                    'message': 'Technical error: No reference image available'
                }, status=400)
            
            validate_image_bytes(reference_image)

        except Exception as e:
            logger.error(f"Failed to get reference image: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': 'Failed to retrieve reference image'
            }, status=400)
        
        # Compare faces only (first step)
        try:
            compare_response = rekognition.compare_faces(
                SourceImage={'Bytes': reference_image},
                TargetImage={'Bytes': id_image_bytes},
                SimilarityThreshold=85.0
            )
            
            face_match = {
                'match': bool(compare_response.get('FaceMatches')),
                'similarity': compare_response['FaceMatches'][0]['Similarity'] if compare_response.get('FaceMatches') else 0
            }
            
            logger.info(f"Face match result: {face_match}")
            
            # If similarity is above 90%, return with continue flag
            if face_match['similarity'] > 90:
                
                return JsonResponse({
                    'status': 'continue_verification',
                    'face_match': face_match,
                    'redirect_url': '/id-verification/'  # URL to the ID verification view
                })
            
            # Otherwise return the face match result
            return JsonResponse({
                'status': 'success',
                'face_match': face_match,
                'message': 'Face verification complete'
            })
            
        except Exception as e:
            logger.error(f"Face comparison failed: {str(e)}", exc_info=True)
            return JsonResponse({
                'status': 'error',
                'message': 'Failed to compare faces'
            }, status=500)
        
    except Exception as e:
        logger.error(f"Unexpected error in ID verification: {str(e)}", exc_info=True)
        return JsonResponse({
            'status': 'error',
            'message': 'An unexpected error occurred'
        }, status=500)
        
        
        
@login_required
def verification_status(request):
    user = request.user
    profile = getattr(user, 'profile', None)
    documents = user.documents.all()
    proof_of_residence = getattr(user, 'proof_of_residence', None)
    verification_logs = user.verification_logs.order_by('-performed_at')
    
    context = {
        'user': user,
        'profile': profile,
        'documents': documents,
        'proof_of_residence': proof_of_residence,
        'verification_logs': verification_logs,
        'verification_complete': user.verification_status == 'COMPLETED'
    }
    
    return render(request, 'verification/status.html', context)

@login_required
def manage_institution_access(request):
    if request.method == 'POST':
        institution_id = request.POST.get('institution_id')
        permission_level = request.POST.get('permission_level')
        expires_at = request.POST.get('expires_at')
        
        try:
            institution = Institution.objects.get(id=institution_id)
            
            # Create or update permission
            UserAccessPermission.objects.update_or_create(
                user=request.user,
                institution=institution,
                defaults={
                    'permission_level': permission_level,
                    'expires_at': expires_at if expires_at else None,
                    'is_active': True
                }
            )
            
            messages.success(request, 'Access permission updated successfully')
        except Institution.DoesNotExist:
            messages.error(request, 'Institution not found')
    
    # Get all institutions and current permissions
    institutions = Institution.objects.all()
    current_permissions = {
        perm.institution.id: perm 
        for perm in request.user.access_permissions.filter(is_active=True)
    }
    
    return render(request, 'forms/institution_access.html', {
        'institutions': institutions,
        'current_permissions': current_permissions
    })
    
    
@login_required
def manage_access_requests(request):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    # Get all access requests for this institution
    access_requests = UserAccessPermission.objects.filter(
        institution=institution
    ).order_by('-granted_at')
    
    # Filter by status if requested
    status_filter = request.GET.get('status')
    if status_filter:
        if status_filter == 'active':
            access_requests = access_requests.filter(is_active=True)
        elif status_filter == 'pending':
            access_requests = access_requests.filter(is_active=False)
    
    # Pagination
    paginator = Paginator(access_requests, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
        'institution': institution,
    }
    
    return render(request, 'forms/manage_access_requests.html', context)

@login_required
def update_access_request(request, pk):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    access_request = get_object_or_404(UserAccessPermission, pk=pk)
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    if access_request.institution != institution:
        return redirect('home')
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'approve':
            access_request.is_active = True
            access_request.save()
            
            # Create a consent transaction
            ConsentTransaction.objects.create(
                user=access_request.user,
                institution=institution,
                action='GRANT',
                permissions={
                    'permission_level': access_request.permission_level,
                    'can_view_personal_info': access_request.can_view_personal_info,
                    'can_view_contact_info': access_request.can_view_contact_info,
                    'can_view_id_documents': access_request.can_view_id_documents,
                    'can_view_proof_of_residence': access_request.can_view_proof_of_residence,
                    'can_view_verification_status': access_request.can_view_verification_status,
                }
            )
            
        elif action == 'reject':
            # Create a consent transaction for revocation
            ConsentTransaction.objects.create(
                user=access_request.user,
                institution=institution,
                action='REVOKE',
                permissions={
                    'permission_level': access_request.permission_level,
                }
            )
            access_request.delete()
        
        return redirect('manage_access_requests')
    
    context = {
        'access_request': access_request,
        'institution': institution,
    }
    
    return render(request, 'forms/update_access_request.html', context)

@login_required
def user_verification_status(request):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    # Get users with access permissions for this institution
    user_ids = UserAccessPermission.objects.filter(
        institution=institution,
        is_active=True
    ).values_list('user_id', flat=True)
    
    users = CustomUser.objects.filter(id__in=user_ids)
    
    # Filter by verification status if requested
    status_filter = request.GET.get('status')
    if status_filter:
        users = users.filter(verification_status=status_filter)
    
    # Search functionality
    search_query = request.GET.get('search')
    if search_query:
        users = users.filter(
            Q(email__icontains=search_query) |
            Q(id_number__icontains=search_query) |
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(users, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
        'search_query': search_query or '',
        'institution': institution,
    }
    
    return render(request, 'forms/user_verification_status.html', context)

@login_required
def user_detail(request, user_id):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    user = get_object_or_404(CustomUser, pk=user_id)
    
    # Check if the institution has permission to view this user
    access_permission = UserAccessPermission.objects.filter(
        user=user,
        institution=institution,
        is_active=True
    ).first()
    
    if not access_permission:
        return redirect('home')
    
    # Get what data the institution is allowed to see
    can_view_personal_info = access_permission.permission_level == 'FULL' or access_permission.can_view_personal_info
    can_view_contact_info = access_permission.permission_level == 'FULL' or access_permission.can_view_contact_info
    can_view_id_documents = access_permission.permission_level == 'FULL' or access_permission.can_view_id_documents
    can_view_proof_of_residence = access_permission.permission_level == 'FULL' or access_permission.can_view_proof_of_residence
    can_view_verification_status = access_permission.permission_level == 'FULL' or access_permission.can_view_verification_status
    
    verification_logs = VerificationLog.objects.filter(user=user).order_by('-performed_at')[:5]
    
    context = {
        'user': user,
        'institution': institution,
        'access_permission': access_permission,
        'can_view_personal_info': can_view_personal_info,
        'can_view_contact_info': can_view_contact_info,
        'can_view_id_documents': can_view_id_documents,
        'can_view_proof_of_residence': can_view_proof_of_residence,
        'can_view_verification_status': can_view_verification_status,
        'verification_logs': verification_logs,
    }
    
    return render(request, 'forms/user_detail.html', context)

@login_required
def consent_history(request):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    consents = ConsentTransaction.objects.filter(
        institution=institution
    ).order_by('-timestamp')
    
    # Filter by action if requested
    action_filter = request.GET.get('action')
    if action_filter in ['GRANT', 'REVOKE']:
        consents = consents.filter(action=action_filter)
    
    # Search functionality
    search_query = request.GET.get('search')
    if search_query:
        consents = consents.filter(
            Q(user__email__icontains=search_query) |
            Q(user__id_number__icontains=search_query) |
            Q(user__first_name__icontains=search_query) |
            Q(user__last_name__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(consents, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'action_filter': action_filter,
        'search_query': search_query or '',
        'institution': institution,
    }
    
    return render(request, 'forms/consent_history.html', context)

@login_required
def institution_settings(request):
    if not request.user.user_type == 'INSTITUTION':
        return redirect('home')
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    if request.method == 'POST':
        # Handle form submission for updating institution details
        name = request.POST.get('name')
        description = request.POST.get('description')
        
        institution.name = name
        institution.description = description
        institution.save()
        
        return redirect('institution_settings')
    
    context = {
        'institution': institution,
    }
    
    return render(request, 'forms/settings.html', context)

@login_required
def get_consent_chart_data(request):
    if not request.user.user_type == 'INSTITUTION':
        return JsonResponse({'error': 'Unauthorized'}, status=401)
    
    institution = get_object_or_404(Institution, admin_users=request.user)
    
    # Get data for the last 30 days
    labels = []
    grant_data = []
    revoke_data = []
    
    for i in range(29, -1, -1):
        date = timezone.now() - timedelta(days=i)
        labels.append(date.strftime('%b %d'))
        
        grant_count = ConsentTransaction.objects.filter(
            institution=institution,
            action='GRANT',
            timestamp__date=date.date()
        ).count()
        grant_data.append(grant_count)
        
        revoke_count = ConsentTransaction.objects.filter(
            institution=institution,
            action='REVOKE',
            timestamp__date=date.date()
        ).count()
        revoke_data.append(revoke_count)
    
    return JsonResponse({
        'labels': labels,
        'grant_data': grant_data,
        'revoke_data': revoke_data,
    })


from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils import timezone
from datetime import timedelta
from .models import CustomUser, Institution, UserAccessPermission, VerificationLog

def admin_required(view_func):
    return user_passes_test(
        lambda u: u.is_superuser or u.user_type == 'ADMIN',
        login_url='home'
    )(view_func)


  
@login_required
@admin_required
def verification_requests(request):
    verifications = CustomUser.objects.exclude(verification_status='COMPLETED').order_by('-verification_started_at')
    
    # Filter by status
    status_filter = request.GET.get('status')
    if status_filter and status_filter != 'all':
        verifications = verifications.filter(verification_status=status_filter.upper())
    
    # Pagination
    paginator = Paginator(verifications, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'verifications': page_obj,
        'status_filter': status_filter,
    }
    return render(request, 'forms/verification_requests.html', context)

@login_required
@admin_required
def verify_user(request, user_id):
    # Implementation for verifying a user
    pass

from django.db.models import Count
from django.db.models.functions import TruncDay

@login_required
@admin_required
def reports(request):
    period = request.GET.get('period', '30')
    
    # User registrations data
    if period == 'all':
        registrations = CustomUser.objects.annotate(
            day=TruncDay('date_joined')
        ).values('day').annotate(count=Count('id')).order_by('day')
    else:
        registrations = CustomUser.objects.filter(
            date_joined__gte=timezone.now() - timedelta(days=int(period))
        ).annotate(
            day=TruncDay('date_joined')
        ).values('day').annotate(count=Count('id')).order_by('day')
    
    registration_labels = [r['day'].strftime('%b %d') for r in registrations]
    registration_data = [r['count'] for r in registrations]
    
    # Verification stats
    verification_stats = {
        'pending': CustomUser.objects.filter(verification_status='PENDING').count(),
        'in_progress': CustomUser.objects.filter(verification_status='IN_PROGRESS').count(),
        'completed': CustomUser.objects.filter(verification_status='COMPLETED').count(),
        'failed': CustomUser.objects.filter(verification_status__in=['FAILED', 'CANCELLED']).count(),
    }
    
    # Institution activity
    institutions = Institution.objects.annotate(
        user_count=Count('user_access')
    ).order_by('-user_count')[:5]
    
    institution_labels = [i.name for i in institutions]
    institution_data = [i.user_count for i in institutions]
    
    # Consent changes
    if period == 'all':
        consents = UserAccessPermission.objects.annotate(
            day=TruncDay('granted_at')
        ).values('day').annotate(
            grants=Count('id', filter=Q(is_active=True)),
            revokes=Count('id', filter=Q(is_active=False))
        ).order_by('day')
    else:
        consents = UserAccessPermission.objects.filter(
            granted_at__gte=timezone.now() - timedelta(days=int(period))
        ).annotate(
            day=TruncDay('granted_at')
        ).values('day').annotate(
            grants=Count('id', filter=Q(is_active=True)),
            revokes=Count('id', filter=Q(is_active=False))
        ).order_by('day')
    
    consent_labels = [c['day'].strftime('%b %d') for c in consents]
    consent_grants = [c['grants'] for c in consents]
    consent_revokes = [c['revokes'] for c in consents]
    
    context = {
        'period': period,
        'registration_labels': registration_labels,
        'registration_data': registration_data,
        'verification_stats': verification_stats,
        'institution_labels': institution_labels,
        'institution_data': institution_data,
        'consent_labels': consent_labels,
        'consent_grants': consent_grants,
        'consent_revokes': consent_revokes,
    }
    
    return render(request, 'forms/reports.html', context)



@login_required
@admin_required
def institutions(request):
    institutions_list = Institution.objects.all().order_by('-created_at')
    
    # Pagination
    paginator = Paginator(institutions_list, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'institutions': page_obj,
    }
    return render(request, 'forms/institutions.html', context)

@login_required
@admin_required
def view_institution(request, institution_id):
    institution = get_object_or_404(Institution, pk=institution_id)
    return render(request, 'forms/view_institution.html', {'institution': institution})

@login_required
@admin_required
def create_institution(request):
    # Implementation for creating an institution
    pass

@login_required
@admin_required
def edit_institution(request, institution_id):
    # Implementation for editing an institution
    pass

@login_required
@admin_required
def delete_institution(request, institution_id):
    # Implementation for deleting an institution
    pass


from django.core.paginator import Paginator
from django.db.models import Q

@login_required
@admin_required
def user_management(request):
    users = CustomUser.objects.all().order_by('-date_joined')
    
    # Search functionality
    search_query = request.GET.get('search')
    if search_query:
        users = users.filter(
            Q(email__icontains=search_query) |
            Q(id_number__icontains=search_query) |
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(users, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'users': page_obj,
        'search_query': search_query or '',
    }
    return render(request, 'forms/user_management.html', context)

@login_required
@admin_required
def view_user(request, user_id):
    user = get_object_or_404(CustomUser, pk=user_id)
    return render(request, 'forms/view_user.html', {'user': user})

@login_required
@admin_required
def create_user(request):
    # Implementation for creating a user
    pass

@login_required
@admin_required
def edit_user(request, user_id):
    # Implementation for editing a user
    pass

@login_required
@admin_required
def delete_user(request, user_id):
    # Implementation for deleting a user
    pass