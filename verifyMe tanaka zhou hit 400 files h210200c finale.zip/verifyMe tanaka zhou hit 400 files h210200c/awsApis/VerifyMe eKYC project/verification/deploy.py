import base64
from algosdk import transaction, account, encoding
from algosdk.v2client import algod
from pyteal import compileTeal, Mode
from Contracts.consent_manager import approval_program, clear_program
from algosdk import kmd
from algosdk.wallet import Wallet

# Add this function
def fund_account(address):
    algod_client = algod.AlgodClient(algod_token, algod_address)
    wallet = Wallet("unencrypted-default-wallet", "", kmd.KMDClient(kmd_token="a"*64, kmd_address="http://localhost:4002"))
    
    # Get the default account from LocalNet
    default_account = wallet.list_keys()[0]
    
    # Send 10 ALGO
    sp = algod_client.suggested_params()
    txn = transaction.PaymentTxn(
        sender=default_account,
        sp=sp,
        receiver=address,
        amt=10_000_000  # 10 ALGO
    )
    signed = wallet.sign_transaction(txn)
    algod_client.send_transaction(signed)
    
    
# Initialize client
algod_address = "http://localhost:4001"
algod_token = "a" * 64
client = algod.AlgodClient(algod_token, algod_address)

def deploy_contract():
    # Generate deployer account
    private_key, address = account.generate_account()
    print(f"Fund this address: {address}")
    fund_account(address)
    print("Waiting for funding...")

    # Compile programs
    approval_teal = compileTeal(approval_program(), mode=Mode.Application, version=6)
    clear_teal = compileTeal(clear_program(), mode=Mode.Application, version=6)

    # Compile to bytes
    approval_result = client.compile(approval_teal)
    approval_binary = base64.b64decode(approval_result["result"])
    clear_result = client.compile(clear_teal)
    clear_binary = base64.b64decode(clear_result["result"])

    # Create transaction
    sp = client.suggested_params()
    txn = transaction.ApplicationCreateTxn(
        address,
        sp,
        transaction.OnComplete.NoOpOC,
        approval_binary,
        clear_binary,
        transaction.StateSchema(1, 1),  # Local storage
        transaction.StateSchema(1, 0)   # Global storage
    )

    # Sign and send
    signed = txn.sign(private_key)
    tx_id = client.send_transaction(signed)
    result = transaction.wait_for_confirmation(client, tx_id, 4)
    
    app_id = result["application-index"]
    print(f"Deployed app ID: {app_id}")
    return app_id

if __name__ == "__main__":
    deploy_contract()