from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser, UserProfile
from django.core.validators import validate_email
import re
from django import forms
from .models import Institution

class ConsentForm(forms.Form):
    ACTION_CHOICES = [
        ('grant', 'Grant Access'),
        ('revoke', 'Revoke Access')
    ]
    
    PERMISSION_CHOICES = [
        ('basic_info', 'Basic Personal Information'),
        ('contact', 'Contact Details'),
        ('documents', 'Identity Documents'),
        ('verification', 'Verification Status')
    ]

    institution = forms.ModelChoiceField(
        queryset=Institution.objects.all(),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    action = forms.ChoiceField(
        choices=ACTION_CHOICES,
        widget=forms.RadioSelect
    )
    permissions = forms.MultipleChoiceField(
        choices=PERMISSION_CHOICES,
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    def clean_permissions(self):
        # Convert permissions to bitmask
        permissions = self.cleaned_data.get('permissions', [])
        bitmask = 0
        for perm in permissions:
            bitmask |= 1 << self.PERMISSION_CHOICES.index((perm, ''))
        return bitmask
    
    
class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email',
            'autocomplete': 'email'
        }),
        validators=[validate_email]
    )
    id_number = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'National ID/Passport Number'
        }),
        max_length=50,
        help_text="Your government-issued ID number"
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Password',
            'autocomplete': 'new-password'
        }),
        min_length=8
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Confirm Password',
            'autocomplete': 'new-password'
        })
    )
    phone_number = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        }),
        max_length=20
    )
    first_name = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'First Name'
        }),
        max_length=100
    )
    last_name = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Last Name'
        }),
        max_length=100
    )

    class Meta:
        model = CustomUser
        fields = ('email', 'id_number', 'first_name', 'last_name', 'phone_number', 'password1', 'password2')

    def clean_id_number(self):
        id_number = self.cleaned_data.get('id_number')
        if CustomUser.objects.filter(id_number=id_number).exists():
            raise forms.ValidationError("This ID number is already registered.")
        return id_number

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        if not re.match(r'^\+?[\d\s-]+$', phone_number):
            raise forms.ValidationError("Enter a valid phone number.")
        return phone_number

class LoginForm(AuthenticationForm):
    username = forms.CharField(
        label="ID Number",
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'ID Number',
            'autocomplete': 'username'
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Password',
            'autocomplete': 'current-password'
        })
    )
    remember_me = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        })
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].label = 'ID Number'


class IDUploadForm(forms.Form):
    id_document = forms.ImageField(
        label="Upload ID Document",
        widget=forms.ClearableFileInput(attrs={
            'class': 'form-control',
            'accept': 'image/*',
            'capture': 'environment'  # For mobile camera access (use 'environment' for rear camera)
        }),
        help_text="Upload a clear photo of your ID (front side)",
        required=True
    )