from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
from django.core.validators import FileExtensionValidator
import uuid
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models
from cryptography.fernet import Fernet
from django.conf import settings
from django.contrib.auth.models import BaseUserManager
import hashlib
import time

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('user_type', 'ADMIN')  # Set default user_type for superuser
        
        # Ensure required fields are set
        if extra_fields.get('id_number') is None:
            raise ValueError('Superuser must have an id_number')
        if extra_fields.get('first_name') is None:
            raise ValueError('Superuser must have a first_name')
        if extra_fields.get('last_name') is None:
            raise ValueError('Superuser must have a last_name')
        if extra_fields.get('phone_number') is None:
            raise ValueError('Superuser must have a phone_number')

        return self.create_user(email, password, **extra_fields)
    
    
    
class CustomUser(AbstractUser):
    
    
    VERIFICATION_STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('IN_PROGRESS', 'In Progress'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
        ('FAILED', 'Failed'),
    ]
    USER_TYPE_CHOICES = [
        ('NORMAL', 'Normal User'),
        ('ADMIN', 'Admin'),
        ('INSTITUTION', 'Institution'),
    ]
    
    # Remove username field since we're using email
    username = None
    email = models.EmailField(_('email address'), unique=True)
    id_number = models.CharField(max_length=50, unique=True, verbose_name='ID Number')
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, default='NORMAL')
    
    verification_status = models.CharField(
        max_length=20, 
        choices=VERIFICATION_STATUS_CHOICES, 
        default='PENDING'
    )
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    
    # Verification timestamps
    verification_started_at = models.DateTimeField(null=True, blank=True)
    verification_completed_at = models.DateTimeField(null=True, blank=True)
    
    # Central registry verification
    central_registry_verified = models.BooleanField(default=False)
    central_registry_verified_at = models.DateTimeField(null=True, blank=True)
    
    # Police verification
    police_verified = models.BooleanField(default=False)
    police_verified_at = models.DateTimeField(null=True, blank=True)
    
    # AML/Sanctions verification
    aml_verified = models.BooleanField(default=False)
    aml_verified_at = models.DateTimeField(null=True, blank=True)
    sanctions_verified = models.BooleanField(default=False)
    sanctions_verified_at = models.DateTimeField(null=True, blank=True)
    
    # Additional fields for institutions
    institution_name = models.CharField(max_length=255, blank=True, null=True)
    institution_description = models.TextField(blank=True, null=True)
    groups = models.ManyToManyField(
        Group,
        verbose_name=_('groups'),
        blank=True,
        help_text=_('The groups this user belongs to.'),
        related_name='customuser_set',
        related_query_name='customuser',
    )
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('user permissions'),
        blank=True,
        help_text=_('Specific permissions for this user.'),
        related_name='customuser_set',
        related_query_name='customuser',
    )
    objects = CustomUserManager()  # Add this line
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['id_number', 'first_name', 'last_name', 'phone_number']
    algorand_address = models.CharField(max_length=58, unique=True, blank=True, null=True)
    # Encrypted private key for Algorand account    
    encrypted_pk = models.BinaryField(null=True, blank=True)

    def get_private_key(self):
        cipher = Fernet(settings.SECRET_KEY)
        return cipher.decrypt(self.encrypted_pk).decode()
    
    def __str__(self):
        return f"{self.email} ({self.get_full_name()})"
    
    @property
    def wallet_address(self):
        return hashlib.sha256(self.email.encode()).hexdigest()[:40]
    
    def consent_history(self):
        return ConsentTransaction.objects.filter(user=self).order_by('-timestamp')
    
    

class UserProfile(models.Model):
    ID_TYPE_CHOICES = [
        ('NATIONAL_ID', 'National ID'),
        ('PASSPORT', 'Passport'),
        ('DRIVING_LICENSE', 'Driving License'),
        ('VOTER_ID', 'Voter ID'),
        ('OTHER', 'Other'),
    ]
    
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='profile')
    first_name = models.CharField(max_length=100,null=True, blank=True)
    middle_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100,null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    place_of_birth = models.CharField(max_length=255,null=True, blank=True)
    address = models.TextField()  # Single field as requested
    
    # ID document information
    id_type = models.CharField(max_length=20, choices=ID_TYPE_CHOICES, blank=True, null=True)
    id_number = models.CharField(max_length=100, blank=True, null=True)
    id_issue_date = models.DateField(null=True, blank=True)
    id_expiry_date = models.DateField(null=True, blank=True)
    id_issuing_authority = models.CharField(max_length=255, blank=True, null=True)
    
    # Liveness verification
    liveness_verified = models.BooleanField(default=False)
    liveness_confidence = models.FloatField(null=True, blank=True)
    liveness_verified_at = models.DateTimeField(null=True, blank=True)
    
    # Face match verification
    face_match_verified = models.BooleanField(default=False)
    face_match_similarity = models.FloatField(null=True, blank=True)
    face_match_verified_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Profile for {self.user.username}"

class Document(models.Model):
    DOCUMENT_TYPE_CHOICES = [
        ('ID_FRONT', 'ID Front'),
        ('ID_BACK', 'ID Back'),
        ('SELFIE', 'Selfie'),
        ('LIVENESS', 'Liveness Check'),
        ('PROOF_OF_RESIDENCE', 'Proof of Residence'),
        ('LEASE_AGREEMENT', 'Lease Agreement'),
        ('UTILITY_BILL', 'Utility Bill'),
        ('OTHER', 'Other'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='documents')
    document_type = models.CharField(max_length=20, choices=DOCUMENT_TYPE_CHOICES)
    file = models.FileField(
        upload_to='user_documents/',
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'jpg', 'jpeg', 'png'])],
        null=True,
        blank=True  
    )
    extracted_data = models.JSONField(null=True, blank=True)  # Store extracted data from Textract
    uploaded_at = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    verified = models.BooleanField(default=False)
    verification_notes = models.TextField(blank=True, null=True)
    
    class Meta:
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"{self.get_document_type_display()} for {self.user.username}"

class ProofOfResidence(models.Model):
    RESIDENCE_TYPE_CHOICES = [
        ('LEASE', 'Lease Agreement'),
        ('UTILITY', 'Utility Bill'),
        ('GOVERNMENT', 'Government Letter'),
        ('BANK', 'Bank Statement'),
        ('OTHER', 'Other'),
    ]
    
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='proof_of_residence')
    residence_type = models.CharField(max_length=20, choices=RESIDENCE_TYPE_CHOICES)
    document = models.ForeignKey(Document, on_delete=models.SET_NULL, null=True, blank=True)
    address = models.TextField(null= True, blank = True)  # Extracted address from the document
    issue_date = models.DateField(null= True, blank = True)
    expiry_date = models.DateField(null=True, blank=True)  # For lease agreements
    verified = models.BooleanField(default=False)
    verified_at = models.DateTimeField(null=True, blank=True)
    
    # Additional lease-specific fields
    landlord_name = models.CharField(max_length=255, blank=True, null=True)
    landlord_contact = models.CharField(max_length=100, blank=True, null=True)
    lease_start_date = models.DateField(null=True, blank=True)
    lease_end_date = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"Proof of Residence for {self.user.username}"

class Institution(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    admin_users = models.ManyToManyField(CustomUser, related_name='administered_institutions')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    algorand_address = models.CharField(max_length=58, unique=True, blank=True, null=True)
    # Encrypted private key for Algorand account    
    encrypted_pk = models.BinaryField(null=True, blank=True)
    
    def __str__(self):
        return self.name

class UserAccessPermission(models.Model):
    PERMISSION_LEVEL_CHOICES = [
        ('BASIC', 'Basic Information'),
        ('FULL', 'Full Information'),
        ('CUSTOM', 'Custom Level'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='access_permissions')
    institution = models.ForeignKey(Institution, on_delete=models.CASCADE, related_name='user_access')
    permission_level = models.CharField(max_length=20, choices=PERMISSION_LEVEL_CHOICES, default='BASIC')
    granted_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    
    # Custom permissions (if permission_level is 'CUSTOM')
    can_view_personal_info = models.BooleanField(default=False)
    can_view_contact_info = models.BooleanField(default=False)
    can_view_id_documents = models.BooleanField(default=False)
    can_view_proof_of_residence = models.BooleanField(default=False)
    can_view_verification_status = models.BooleanField(default=False)
    
    
    transaction_id = models.CharField(max_length=52, null=True)  # Store Algorand tx ID
    is_on_chain = models.BooleanField(default=False, null=True)  # Track if the permission is on-chain
    
    class Meta:
        unique_together = ('user', 'institution')
    
    def __str__(self):
        return f"{self.institution.name} access to {self.user.username}"

class VerificationLog(models.Model):
    VERIFICATION_TYPE_CHOICES = [
        ('ID_VERIFICATION', 'ID Verification'),
        ('LIVENESS_CHECK', 'Liveness Check'),
        ('FACE_MATCH', 'Face Match'),
        ('PROOF_OF_RESIDENCE', 'Proof of Residence'),
        ('CENTRAL_REGISTRY', 'Central Registry Check'),
        ('POLICE_CHECK', 'Police Clearance Check'),
        ('AML_CHECK', 'AML Check'),
        ('SANCTIONS_CHECK', 'Sanctions Check'),
    ]
    
    RESULT_CHOICES = [
        ('SUCCESS', 'Success'),
        ('FAILURE', 'Failure'),
        ('PENDING', 'Pending'),
        ('ERROR', 'Error'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='verification_logs')
    verification_type = models.CharField(max_length=20, choices=VERIFICATION_TYPE_CHOICES)
    result = models.CharField(max_length=20, choices=RESULT_CHOICES)
    details = models.JSONField(null=True, blank=True)  # Store API responses or processing details
    performed_at = models.DateTimeField(auto_now_add=True)
    performed_by = models.ForeignKey(
        CustomUser, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='performed_verifications'
    )
    
    class Meta:
        ordering = ['-performed_at']
    
    def __str__(self):
        return f"{self.verification_type} for {self.user.username} - {self.result}"
    
class ConsentTransaction(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    institution = models.ForeignKey(Institution, on_delete=models.CASCADE)
    action = models.CharField(max_length=10, choices=[('GRANT', 'Grant'), ('REVOKE', 'Revoke')])
    permissions = models.JSONField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    tx_hash = models.CharField(max_length=64, blank=True)
    previous_hash = models.CharField(max_length=64, blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.tx_hash:
            self.tx_hash = hashlib.sha256(
                f"{self.user.id}{self.institution.id}{time.time()}".encode()
            ).hexdigest()
        
        # Ensure previous_hash is never empty
        if not self.previous_hash:
            self.previous_hash = '0' * 64  # Genesis block hash
        
        super().save(*args, **kwargs)