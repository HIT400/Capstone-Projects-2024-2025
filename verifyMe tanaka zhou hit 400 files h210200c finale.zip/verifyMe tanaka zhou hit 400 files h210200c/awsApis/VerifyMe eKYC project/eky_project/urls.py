"""
URL configuration for eky_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from verification.views import *
from residence.views import *
from verification import views
from admin_soft.views import *

urlpatterns = [
    path('', include('admin_soft.urls')),
    path('admin/', admin.site.urls),
    path('id-verification/', id_verification_view, name='id_verification'),
    path('api/analyze-id/', analyze_id, name='analyze_id'),
    path('api/compare-faces/', compare_faces, name='compare_faces'),
    path('api/auth/register/', register_view, name='register'),
    path('api/auth/login/', LoginView.as_view(), name='login'),
    path('api/auth/logout/',logout_view, name='logout'),
    
    
    path('create-liveness-session/', views.create_liveness_session, name='create_liveness_session'),
    path('verification/result/', views.liveness_result_view, name='liveness_result'),
    path('process_id_verification/', views.process_id_verification, name='process_id_verification'),
    
    ####
    
    path('document-upload/', document_upload, name='document_upload'),
    path('process-documents/', process_documents, name='process_documents'),
    
    path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),
    path('institution-dashboard/', institution_dashboard, name='institution_dashboard'),
    
    path('consent-chain/', ConsentChainView.as_view(), name='consent_chain'),
    path('grant-consent/', GrantConsentView.as_view(), name='grant_consent'),
    path('wallet/', WalletView.as_view(), name='wallet'),
    
    
    
    
    path('institution/access-requests/', manage_access_requests, name='manage_access_requests'),
    path('institution/access-requests/<int:pk>/', update_access_request, name='update_access_request'),
    path('institution/verification-status/', user_verification_status, name='user_verification_status'),
    path('institution/users/<int:user_id>/', user_detail, name='user_detail'),
    path('institution/consent-history/', consent_history, name='consent_history'),
    path('institution/settings/', institution_settings, name='institution_settings'),
    path('institution/consent-chart-data/', get_consent_chart_data, name='get_consent_chart_data'),
    
    
    # Admin Dashboard
    
    
    # User Management
    path('users/', user_management, name='user_management'),
    path('users/<int:user_id>/', view_user, name='view_user'),
    path('users/create/', create_user, name='create_user'),
    path('users/<int:user_id>/edit/', edit_user, name='edit_user'),
    path('users/<int:user_id>/delete/', delete_user, name='delete_user'),
    
    # Verification Requests
    path('verifications/', verification_requests, name='verification_requests'),
    path('verifications/<int:user_id>/', verify_user, name='verify_user'),
    
    # Institutions
    path('institutions/', institutions, name='institutions'),
    path('institutions/<int:institution_id>/', view_institution, name='view_institution'),
    path('institutions/create/', create_institution, name='create_institution'),
    path('institutions/<int:institution_id>/edit/', edit_institution, name='edit_institution'),
    path('institutions/<int:institution_id>/delete/', delete_institution, name='delete_institution'),
    
    # Reports
    path('reports/', reports, name='reports'),
    
]
