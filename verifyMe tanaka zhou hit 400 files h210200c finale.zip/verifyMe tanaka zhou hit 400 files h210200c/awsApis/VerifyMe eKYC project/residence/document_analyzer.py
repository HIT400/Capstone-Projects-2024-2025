import boto3
import json
from datetime import datetime
import os
from django.conf import settings

class DocumentAnalyzer:
    def __init__(self):
        self.textract = boto3.client(
            'textract', 
            region_name='ca-central-1',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
        )
        self.s3 = boto3.client(
            's3',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
        )

    def analyze_document_with_queries(self, bucket_name, document_key, is_lease=False, is_utility=False):
        """
        Analyze document with proper query response parsing based on AWS Textract response structure
        Returns a tuple of (extracted_data, confidence_scores)
        """
        queries = []
        
        if is_lease:
            queries.extend([
                {"Text": "What is the tenant's full name?", "Alias": "TENANT_NAME"},
                {"Text": "What is the tenant's ID number?", "Alias": "TENANT_ID"},
                {"Text": "What is the property address?", "Alias": "PROPERTY_ADDRESS"},
                {"Text": "What is the landlord's or owners full name?", "Alias": "OWNER_NAME"},
                
                {"Text": "What is the lease start date?", "Alias": "LEASE_START_DATE"},
                {"Text": "What is the lease end date?", "Alias": "LEASE_END_DATE"},
                {"Text": "What is the monthly rent amount?", "Alias": "RENT_AMOUNT"},
                {"Text": "What is the security deposit amount?", "Alias": "DEPOSIT_AMOUNT"}
            ])
        
        if is_utility:
            queries.extend([
                {"Text": "What is the account holder's name?", "Alias": "ACCOUNT_HOLDER_NAME"},
                {"Text": "What is the account holder's ID number?", "Alias": "ACCOUNT_HOLDER_ID"},
                {"Text": "What is the billing  address?", "Alias": "ADDRESS"},
                {"Text": "What is the utility type (electricity, water, etc.)?", "Alias": "UTILITY_TYPE"},
                {"Text": "What is the billing period start date?", "Alias": "BILL_START_DATE"},
                {"Text": "What is the billing period end date?", "Alias": "BILL_END_DATE"},
                {"Text": "What is the total amount due?", "Alias": "TOTAL_AMOUNT"},
                {"Text": "What is the account number?", "Alias": "ACCOUNT_NUMBER"},
                {"Text": "What is the property address?", "Alias": "PROPERTY_ADDRESS"}
            ])

        try:
            response = self.textract.analyze_document(
                Document={'S3Object': {'Bucket': bucket_name, 'Name': document_key}},
                FeatureTypes=['QUERIES', 'FORMS', 'TABLES', 'LAYOUT'],
                QueriesConfig={'Queries': queries}
            )

            # Create a mapping of block IDs to blocks for easy lookup
            block_map = {block['Id']: block for block in response.get('Blocks', [])}
            
            extracted_data = {}
            confidence_scores = {}
            
            # First pass: Find all QUERY blocks and their corresponding QUERY_RESULT blocks
            for block in response.get('Blocks', []):
                if block.get('BlockType') == 'QUERY':
                    query_alias = block.get('Query', {}).get('Alias')
                    if not query_alias:
                        continue
                        
                    # Find relationships of type 'ANSWER'
                    for relationship in block.get('Relationships', []):
                        if relationship.get('Type') == 'ANSWER':
                            for answer_id in relationship.get('Ids', []):
                                answer_block = block_map.get(answer_id)
                                if answer_block and answer_block.get('BlockType') == 'QUERY_RESULT':
                                    extracted_data[query_alias] = answer_block.get('Text', '').strip()
                                    confidence_scores[query_alias] = answer_block.get('Confidence', 0)
                                    break
            
            # Second pass: Directly check for QUERY_RESULT blocks with text
            for block in response.get('Blocks', []):
                if block.get('BlockType') == 'QUERY_RESULT':
                    query_alias = block.get('Query', {}).get('Alias')
                    if query_alias and block.get('Text'):
                        extracted_data[query_alias] = block.get('Text').strip()
                        confidence_scores[query_alias] = block.get('Confidence', 0)
            
            return extracted_data, confidence_scores

        except Exception as e:
            print(f"Error processing document: {str(e)}")
            return {}, {}

    def upload_to_s3(self, file_path, bucket_name, s3_key):
        """Upload a document to S3 for Textract processing"""
        try:
            self.s3.upload_file(file_path, bucket_name, s3_key)
            print(f"Uploaded {file_path} to s3://{bucket_name}/{s3_key}")
            return True
        except Exception as e:
            print(f"Failed to upload to S3: {str(e)}")
            return False

    def process_tenant_documents(self, bucket_name, lease_path=None, utility_path=None):
        """Process tenant documents
        Returns a dictionary with 'lease_data', 'utility_data', and their confidence scores"""
        result = {
            'lease_data': {},
            'utility_data': {},
            'lease_confidence': {},
            'utility_confidence': {}
        }
        
        if lease_path:
            lease_key = f"leases/{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.path.basename(lease_path)}"
            if self.upload_to_s3(lease_path, bucket_name, lease_key):
                lease_data, lease_confidence = self.analyze_document_with_queries(bucket_name, lease_key, is_lease=True)
                result['lease_data'] = lease_data
                result['lease_confidence'] = lease_confidence
        
        if utility_path:
            utility_key = f"bills/{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.path.basename(utility_path)}"
            if self.upload_to_s3(utility_path, bucket_name, utility_key):
                utility_data, utility_confidence = self.analyze_document_with_queries(bucket_name, utility_key, is_utility=True)
                result['utility_data'] = utility_data
                result['utility_confidence'] = utility_confidence
        
        return result

    def process_owner_documents(self, bucket_name, utility_path=None):
        """Process owner documents with consistent return structure"""
        result = {
            'utility_data': {},
            'utility_confidence': {}
        }
        
        if utility_path:
            utility_key = f"bills/{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.path.basename(utility_path)}"
            if self.upload_to_s3(utility_path, bucket_name, utility_key):
                utility_data, utility_confidence = self.analyze_document_with_queries(
                    bucket_name, utility_key, is_utility=True
                )
                result['utility_data'] = utility_data
                result['utility_confidence'] = utility_confidence
        
        return result