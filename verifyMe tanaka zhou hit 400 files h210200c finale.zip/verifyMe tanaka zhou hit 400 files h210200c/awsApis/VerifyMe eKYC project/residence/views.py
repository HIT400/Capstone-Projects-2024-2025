import os
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from .document_analyzer import DocumentAnalyzer
from datetime import datetime,date, timedelta
from verification.models import  Document, ProofOfResidence, UserProfile
from django.contrib.auth import get_user_model
import json
import logging
from django.contrib.auth.decorators import login_required
from fuzzywuzzy import fuzz


def document_upload(request):
    return render(request, 'forms/document_upload.html')

logger = logging.getLogger(__name__)

@csrf_exempt
@login_required
def process_documents(request):
    if request.method == 'POST':
        user_type = request.POST.get('user_type')
        lease_file = request.FILES.get('lease_document')
        utility_file = request.FILES.get('utility_document')
        
        # Validate file types
        allowed_extensions = ['.pdf', '.jpg', '.jpeg', '.png']
        
        if lease_file:
            ext = os.path.splitext(lease_file.name)[1].lower()
            if ext not in allowed_extensions:
                return JsonResponse({'status': 'error', 'message': 'Invalid lease document format'})
        
        if utility_file:
            ext = os.path.splitext(utility_file.name)[1].lower()
            if ext not in allowed_extensions:
                return JsonResponse({'status': 'error', 'message': 'Invalid utility document format'})
        
        analyzer = DocumentAnalyzer()
        BUCKET_NAME = settings.AWS_STORAGE_BUCKET_NAME_TEXTRACT
        
        try:
            user = request.user if request.user.is_authenticated else None
            try:
                profile = user.profile
                user_full_name = f"{profile.first_name} {profile.middle_name or ''} {profile.last_name}".strip().lower()
                user_id_number = profile.id_number
            except UserProfile.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'User profile not found'})
            
            if user_type == 'tenant':
                if not lease_file or not utility_file:
                    return JsonResponse({'status': 'error', 'message': 'Both lease and utility documents are required for tenants'})
                
                # Save files temporarily
                lease_path = os.path.join(settings.MEDIA_ROOT, 'temp', lease_file.name)
                utility_path = os.path.join(settings.MEDIA_ROOT, 'temp', utility_file.name)
                
                with open(lease_path, 'wb+') as f:
                    for chunk in lease_file.chunks():
                        f.write(chunk)
                
                with open(utility_path, 'wb+') as f:
                    for chunk in utility_file.chunks():
                        f.write(chunk)
                
                # Process documents - get both data and confidence
                result = analyzer.process_tenant_documents(
                    bucket_name=BUCKET_NAME,
                    lease_path=lease_path,
                    utility_path=utility_path
                )
                
                # Extract the data (maintaining original structure)
                tenant_data = {**result['lease_data'], **result['utility_data']}
                lease_confidence = result['lease_confidence']
                utility_confidence = result['utility_confidence']
                
                # Convert date formats and map fields
                def parse_date(date_str):
                    if not date_str:
                        return None
                    
                    # Try different date formats
                    formats = [
                        '%d/%m/%Y',    # 01/03/2025
                        '%d %b %Y',    # 12 Feb 2014
                        '%d %B %Y',    # 11 April 2014
                        '%d %b',       # 12 Feb (current year assumed)
                    ]
                    
                    for fmt in formats:
                        try:
                            parsed_date = datetime.strptime(date_str, fmt).date()
                            # For dates without year (like "12 Feb"), assume current year
                            if fmt == '%d %b' and parsed_date.year == 1900:
                                parsed_date = parsed_date.replace(year=datetime.now().year)
                            return parsed_date
                        except ValueError:
                            continue
                    
                    logger.warning(f"Failed to parse date: {date_str}")
                    return None

                def check_dates(issue_date, expiry_date=None):
                    today = date.today()
                    
                    # Check if issue date is too old (more than 2 months)
                    if issue_date:
                        max_utility_age = date.today() - timedelta(days=190)
                        if issue_date < max_utility_age:
                            return False, "Utility bill is too old (more than 2 months). Please provide a recent document."
                    
                    # Check if lease has expired
                    if expiry_date and expiry_date < today:
                        return False, "Lease agreement has expired. Please provide a current lease."
                    
                    return True, "Dates are valid"
                
                # Map extracted data to model fields
                lease_data = {
                    'address': tenant_data.get('PROPERTY_ADDRESS', ''),
                    'landlord_name': tenant_data.get('OWNER_NAME', ''),
                    'lease_start_date': parse_date(tenant_data.get('LEASE_START_DATE')),
                    'lease_end_date': parse_date(tenant_data.get('LEASE_END_DATE')),
                    'issue_date': parse_date(tenant_data.get('BILL_START_DATE')),
                }
                
                if not lease_data['lease_start_date'] or not lease_data['lease_end_date']:
                    return JsonResponse({
                        'status': 'manual_review',
                        'message': 'Could not extract all required dates from lease document. Manual review required.',
                        'redirect': False
                    })
                
                # Check dates validity
                dates_valid, date_message = check_dates(
                    lease_data['issue_date'],
                    lease_data['lease_end_date']
                )
                if not dates_valid:
                    return JsonResponse({
                        'status': 'error',
                        'message': date_message,
                        'redirect': False
                    })
                
                lease_tenant_name = tenant_data.get('TENANT_NAME', '')
                name_similarity = fuzz.token_sort_ratio(user_full_name, lease_tenant_name)
                if name_similarity < 90:
                    return JsonResponse({
                        'status': 'error',
                        'message': f"Name does not match. Expected: {user_full_name}, Found: {lease_tenant_name}",
                        'similarity': name_similarity
                    })
                
                utility_account_holder = tenant_data.get('ACCOUNT_HOLDER_NAME', '')
                property_owner_name = tenant_data.get('OWNER_NAME', '')
                account_similarity = fuzz.token_sort_ratio(property_owner_name, utility_account_holder)
                if account_similarity < 90:
                    return JsonResponse({
                        'status': 'error',
                        'message': "Account holder name does not match Property Owner name",
                        'details': {
                            'expected': user_full_name,
                            'found': utility_account_holder,
                            'similarity': account_similarity
                        }
                    })
                
                # Save documents and data to database
                if user:
                    # Include confidence scores in extracted data
                    full_extracted_data = {
                        'data': tenant_data,
                        'confidence': {
                            'lease': lease_confidence,
                            'utility': utility_confidence
                        }
                    }
                    
                    # Save lease document
                    lease_doc = Document.objects.create(
                        user=request.user,
                        document_type='LEASE_AGREEMENT',
                        file=lease_file,
                        extracted_data=json.dumps(full_extracted_data),
                        verified=False if account_similarity < 90 and name_similarity < 90 else True
                    )
                    
                    # Save utility document
                    utility_doc = Document.objects.create(
                        user=request.user,
                        document_type='UTILITY_BILL',
                        file=utility_file,
                        extracted_data=json.dumps(full_extracted_data),
                        verified=False if account_similarity < 90 and name_similarity < 90 else True
                    )
                    
                    # Create or update proof of residence
                    por, created = ProofOfResidence.objects.update_or_create(
                        user=user,
                        defaults={
                            'residence_type': 'LEASE',
                            'document': lease_doc,
                            'address': lease_data['address'],
                            'issue_date': lease_data['issue_date'],
                            'expiry_date': lease_data['lease_end_date'],
                            'landlord_name': lease_data['landlord_name'],
                            'lease_start_date': lease_data['lease_start_date'],
                            'lease_end_date': lease_data['lease_end_date'],
                            'verified_at': datetime.now(),
                            'verified': False if account_similarity < 90 and name_similarity < 90 else True
                        }
                    )
                
                # Clean up temp files
                os.remove(lease_path)
                os.remove(utility_path)
                print(lease_confidence)
                print(utility_confidence)
                
                return JsonResponse({
                    'status': 'success',
                    'data': tenant_data,  # Maintain same response structure
                    'redirect': True,
                    'lease_confidence': lease_confidence,
                    'utility_confidence': utility_confidence,
                    'redirect_url': '/accounts/profile/'
                })
            
            elif user_type == 'owner':
                if not utility_file:
                    return JsonResponse({'status': 'error', 'message': 'Utility document is required for owners'})
                
                # Save file temporarily
                utility_path = os.path.join(settings.MEDIA_ROOT, 'temp', utility_file.name)
                
                with open(utility_path, 'wb+') as f:
                    for chunk in utility_file.chunks():
                        f.write(chunk)
                
                # Process document
                utility_data, utility_confidence = analyzer.process_owner_documents(
                    bucket_name=BUCKET_NAME,
                    utility_path=utility_path
                )
                
                # Map extracted data for owner
                utility_info = {
                    'address': utility_data.get('PROPERTY_ADDRESS', ''),
                    'issue_date': parse_date(utility_data.get('BILL_START_DATE')),
                }
                
                utility_account_holder = utility_data.get('ACCOUNT_HOLDER_NAME', '').lower().strip()
                name_similarity = fuzz.token_sort_ratio(user_full_name, utility_account_holder)
                
                if name_similarity < 95:  # Very strict threshold for owners
                    return JsonResponse({
                        'status': 'error',
                        'message': "Account holder name does not match owner name",
                        'details': {
                            'expected': user_full_name,
                            'found': utility_account_holder,
                            'similarity': name_similarity
                        }
                    })
                
                # Save to database
                if user:
                    full_extracted_data = {
                        'data': utility_data,
                        'confidence': utility_confidence
                    }
                    
                    utility_doc = Document.objects.create(
                        user=user,
                        document_type='UTILITY_BILL',
                        file=utility_file,
                        extracted_data=json.dumps(full_extracted_data),
                        verified=True if name_similarity >= 95 else False
                    )
                    
                    ProofOfResidence.objects.update_or_create(
                        user=user,
                        defaults={
                            'residence_type': 'UTILITY',
                            'document': utility_doc,
                            'address': utility_info['address'],
                            'issue_date': utility_info['issue_date'],
                            'verified': True if name_similarity >= 95 else False
                        }
                    )
                
                # Clean up temp file
                os.remove(utility_path)
                
                return JsonResponse({
                    'status': 'success',
                    'data': utility_data,  # Maintain same response structure
                    'redirect': True,
        
                    'utility_confidence': utility_confidence,
                    'redirect_url': '/accounts/profile/'
                })
            
            else:
                return JsonResponse({'status': 'error', 'message': 'Invalid user type'})
        
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})